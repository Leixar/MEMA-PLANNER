﻿namespace Calendar_App
{
    partial class Calendar2018
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calendar2018));
            this.bottomborder = new System.Windows.Forms.Label();
            this.topborder = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label137 = new System.Windows.Forms.Label();
            this.Dashbord = new System.Windows.Forms.Button();
            this.BorderRight = new System.Windows.Forms.Label();
            this.BorderLeft = new System.Windows.Forms.Label();
            this.January = new System.Windows.Forms.Panel();
            this.jan = new System.Windows.Forms.Button();
            this.datepanel = new System.Windows.Forms.Panel();
            this.button49 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label36 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.RightButton = new System.Windows.Forms.Button();
            this.heading1 = new Calendar_App.Heading();
            this.February = new System.Windows.Forms.Panel();
            this.Feb = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button83 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.heading2 = new Calendar_App.Heading();
            this.March = new System.Windows.Forms.Panel();
            this.Mar = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.heading3 = new Calendar_App.Heading();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button86 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.label92 = new System.Windows.Forms.Label();
            this.button85 = new System.Windows.Forms.Button();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.April = new System.Windows.Forms.Panel();
            this.Apr = new System.Windows.Forms.Button();
            this.panel4 = new System.Windows.Forms.Panel();
            this.button172 = new System.Windows.Forms.Button();
            this.button173 = new System.Windows.Forms.Button();
            this.button171 = new System.Windows.Forms.Button();
            this.button165 = new System.Windows.Forms.Button();
            this.button166 = new System.Windows.Forms.Button();
            this.button167 = new System.Windows.Forms.Button();
            this.button168 = new System.Windows.Forms.Button();
            this.button169 = new System.Windows.Forms.Button();
            this.button170 = new System.Windows.Forms.Button();
            this.button164 = new System.Windows.Forms.Button();
            this.button161 = new System.Windows.Forms.Button();
            this.button162 = new System.Windows.Forms.Button();
            this.button158 = new System.Windows.Forms.Button();
            this.button163 = new System.Windows.Forms.Button();
            this.button159 = new System.Windows.Forms.Button();
            this.button154 = new System.Windows.Forms.Button();
            this.button160 = new System.Windows.Forms.Button();
            this.button155 = new System.Windows.Forms.Button();
            this.button151 = new System.Windows.Forms.Button();
            this.button156 = new System.Windows.Forms.Button();
            this.button147 = new System.Windows.Forms.Button();
            this.button157 = new System.Windows.Forms.Button();
            this.button152 = new System.Windows.Forms.Button();
            this.button153 = new System.Windows.Forms.Button();
            this.button148 = new System.Windows.Forms.Button();
            this.button144 = new System.Windows.Forms.Button();
            this.button149 = new System.Windows.Forms.Button();
            this.button145 = new System.Windows.Forms.Button();
            this.button150 = new System.Windows.Forms.Button();
            this.label89 = new System.Windows.Forms.Label();
            this.button146 = new System.Windows.Forms.Button();
            this.label136 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.button12 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.heading4 = new Calendar_App.Heading();
            this.May = new System.Windows.Forms.Panel();
            this.Ma = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.button139 = new System.Windows.Forms.Button();
            this.button138 = new System.Windows.Forms.Button();
            this.button140 = new System.Windows.Forms.Button();
            this.button141 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.button142 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button133 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button134 = new System.Windows.Forms.Button();
            this.button135 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button136 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button137 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.button17 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.heading5 = new Calendar_App.Heading();
            this.June = new System.Windows.Forms.Panel();
            this.Jun = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.button200 = new System.Windows.Forms.Button();
            this.button195 = new System.Windows.Forms.Button();
            this.button201 = new System.Windows.Forms.Button();
            this.button202 = new System.Windows.Forms.Button();
            this.button198 = new System.Windows.Forms.Button();
            this.button203 = new System.Windows.Forms.Button();
            this.button194 = new System.Windows.Forms.Button();
            this.button199 = new System.Windows.Forms.Button();
            this.button196 = new System.Windows.Forms.Button();
            this.button197 = new System.Windows.Forms.Button();
            this.button191 = new System.Windows.Forms.Button();
            this.button190 = new System.Windows.Forms.Button();
            this.button192 = new System.Windows.Forms.Button();
            this.button193 = new System.Windows.Forms.Button();
            this.button184 = new System.Windows.Forms.Button();
            this.button183 = new System.Windows.Forms.Button();
            this.button185 = new System.Windows.Forms.Button();
            this.button186 = new System.Windows.Forms.Button();
            this.button177 = new System.Windows.Forms.Button();
            this.button187 = new System.Windows.Forms.Button();
            this.button176 = new System.Windows.Forms.Button();
            this.button188 = new System.Windows.Forms.Button();
            this.button178 = new System.Windows.Forms.Button();
            this.button189 = new System.Windows.Forms.Button();
            this.button174 = new System.Windows.Forms.Button();
            this.button179 = new System.Windows.Forms.Button();
            this.button175 = new System.Windows.Forms.Button();
            this.button180 = new System.Windows.Forms.Button();
            this.button181 = new System.Windows.Forms.Button();
            this.label229 = new System.Windows.Forms.Label();
            this.button182 = new System.Windows.Forms.Button();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label233 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.label250 = new System.Windows.Forms.Label();
            this.label252 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.label270 = new System.Windows.Forms.Label();
            this.heading6 = new Calendar_App.Heading();
            this.July = new System.Windows.Forms.Panel();
            this.Jul = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.button232 = new System.Windows.Forms.Button();
            this.button231 = new System.Windows.Forms.Button();
            this.button233 = new System.Windows.Forms.Button();
            this.button234 = new System.Windows.Forms.Button();
            this.button225 = new System.Windows.Forms.Button();
            this.button224 = new System.Windows.Forms.Button();
            this.button226 = new System.Windows.Forms.Button();
            this.button227 = new System.Windows.Forms.Button();
            this.button221 = new System.Windows.Forms.Button();
            this.button228 = new System.Windows.Forms.Button();
            this.button222 = new System.Windows.Forms.Button();
            this.button229 = new System.Windows.Forms.Button();
            this.button218 = new System.Windows.Forms.Button();
            this.button230 = new System.Windows.Forms.Button();
            this.button223 = new System.Windows.Forms.Button();
            this.button219 = new System.Windows.Forms.Button();
            this.button214 = new System.Windows.Forms.Button();
            this.button220 = new System.Windows.Forms.Button();
            this.button215 = new System.Windows.Forms.Button();
            this.button211 = new System.Windows.Forms.Button();
            this.button216 = new System.Windows.Forms.Button();
            this.button212 = new System.Windows.Forms.Button();
            this.button217 = new System.Windows.Forms.Button();
            this.button213 = new System.Windows.Forms.Button();
            this.button207 = new System.Windows.Forms.Button();
            this.button204 = new System.Windows.Forms.Button();
            this.button208 = new System.Windows.Forms.Button();
            this.button209 = new System.Windows.Forms.Button();
            this.button205 = new System.Windows.Forms.Button();
            this.button210 = new System.Windows.Forms.Button();
            this.button206 = new System.Windows.Forms.Button();
            this.label273 = new System.Windows.Forms.Label();
            this.label275 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.label281 = new System.Windows.Forms.Label();
            this.label283 = new System.Windows.Forms.Label();
            this.label285 = new System.Windows.Forms.Label();
            this.label287 = new System.Windows.Forms.Label();
            this.label289 = new System.Windows.Forms.Label();
            this.label292 = new System.Windows.Forms.Label();
            this.label300 = new System.Windows.Forms.Label();
            this.heading7 = new Calendar_App.Heading();
            this.August = new System.Windows.Forms.Panel();
            this.Aug = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.button262 = new System.Windows.Forms.Button();
            this.button263 = new System.Windows.Forms.Button();
            this.button264 = new System.Windows.Forms.Button();
            this.button265 = new System.Windows.Forms.Button();
            this.button260 = new System.Windows.Forms.Button();
            this.button261 = new System.Windows.Forms.Button();
            this.button255 = new System.Windows.Forms.Button();
            this.button253 = new System.Windows.Forms.Button();
            this.button256 = new System.Windows.Forms.Button();
            this.button257 = new System.Windows.Forms.Button();
            this.button254 = new System.Windows.Forms.Button();
            this.button258 = new System.Windows.Forms.Button();
            this.button252 = new System.Windows.Forms.Button();
            this.button259 = new System.Windows.Forms.Button();
            this.button246 = new System.Windows.Forms.Button();
            this.button245 = new System.Windows.Forms.Button();
            this.button247 = new System.Windows.Forms.Button();
            this.button248 = new System.Windows.Forms.Button();
            this.button239 = new System.Windows.Forms.Button();
            this.button249 = new System.Windows.Forms.Button();
            this.button238 = new System.Windows.Forms.Button();
            this.button250 = new System.Windows.Forms.Button();
            this.button240 = new System.Windows.Forms.Button();
            this.button251 = new System.Windows.Forms.Button();
            this.button235 = new System.Windows.Forms.Button();
            this.button241 = new System.Windows.Forms.Button();
            this.button236 = new System.Windows.Forms.Button();
            this.button242 = new System.Windows.Forms.Button();
            this.label321 = new System.Windows.Forms.Label();
            this.button243 = new System.Windows.Forms.Button();
            this.button237 = new System.Windows.Forms.Button();
            this.button244 = new System.Windows.Forms.Button();
            this.label323 = new System.Windows.Forms.Label();
            this.label325 = new System.Windows.Forms.Label();
            this.label327 = new System.Windows.Forms.Label();
            this.label329 = new System.Windows.Forms.Label();
            this.label331 = new System.Windows.Forms.Label();
            this.label333 = new System.Windows.Forms.Label();
            this.label343 = new System.Windows.Forms.Label();
            this.label344 = new System.Windows.Forms.Label();
            this.label338 = new System.Windows.Forms.Label();
            this.label361 = new System.Windows.Forms.Label();
            this.label362 = new System.Windows.Forms.Label();
            this.heading8 = new Calendar_App.Heading();
            this.September = new System.Windows.Forms.Panel();
            this.Sep = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.button296 = new System.Windows.Forms.Button();
            this.button293 = new System.Windows.Forms.Button();
            this.button290 = new System.Windows.Forms.Button();
            this.button294 = new System.Windows.Forms.Button();
            this.button291 = new System.Windows.Forms.Button();
            this.button286 = new System.Windows.Forms.Button();
            this.button292 = new System.Windows.Forms.Button();
            this.button283 = new System.Windows.Forms.Button();
            this.button289 = new System.Windows.Forms.Button();
            this.button287 = new System.Windows.Forms.Button();
            this.button281 = new System.Windows.Forms.Button();
            this.button288 = new System.Windows.Forms.Button();
            this.button284 = new System.Windows.Forms.Button();
            this.button285 = new System.Windows.Forms.Button();
            this.button282 = new System.Windows.Forms.Button();
            this.button276 = new System.Windows.Forms.Button();
            this.button274 = new System.Windows.Forms.Button();
            this.button277 = new System.Windows.Forms.Button();
            this.button278 = new System.Windows.Forms.Button();
            this.button275 = new System.Windows.Forms.Button();
            this.button279 = new System.Windows.Forms.Button();
            this.button269 = new System.Windows.Forms.Button();
            this.button280 = new System.Windows.Forms.Button();
            this.button267 = new System.Windows.Forms.Button();
            this.button270 = new System.Windows.Forms.Button();
            this.button268 = new System.Windows.Forms.Button();
            this.button271 = new System.Windows.Forms.Button();
            this.button266 = new System.Windows.Forms.Button();
            this.button272 = new System.Windows.Forms.Button();
            this.button273 = new System.Windows.Forms.Button();
            this.label365 = new System.Windows.Forms.Label();
            this.label368 = new System.Windows.Forms.Label();
            this.label384 = new System.Windows.Forms.Label();
            this.label388 = new System.Windows.Forms.Label();
            this.label389 = new System.Windows.Forms.Label();
            this.label391 = new System.Windows.Forms.Label();
            this.label411 = new System.Windows.Forms.Label();
            this.label369 = new System.Windows.Forms.Label();
            this.label375 = new System.Windows.Forms.Label();
            this.label379 = new System.Windows.Forms.Label();
            this.label381 = new System.Windows.Forms.Label();
            this.label383 = new System.Windows.Forms.Label();
            this.label385 = new System.Windows.Forms.Label();
            this.label408 = new System.Windows.Forms.Label();
            this.heading9 = new Calendar_App.Heading();
            this.October = new System.Windows.Forms.Panel();
            this.Oct = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.panel10 = new System.Windows.Forms.Panel();
            this.button323 = new System.Windows.Forms.Button();
            this.button316 = new System.Windows.Forms.Button();
            this.button324 = new System.Windows.Forms.Button();
            this.button325 = new System.Windows.Forms.Button();
            this.button317 = new System.Windows.Forms.Button();
            this.button326 = new System.Windows.Forms.Button();
            this.button318 = new System.Windows.Forms.Button();
            this.button319 = new System.Windows.Forms.Button();
            this.button320 = new System.Windows.Forms.Button();
            this.button321 = new System.Windows.Forms.Button();
            this.button322 = new System.Windows.Forms.Button();
            this.button313 = new System.Windows.Forms.Button();
            this.button314 = new System.Windows.Forms.Button();
            this.button315 = new System.Windows.Forms.Button();
            this.button309 = new System.Windows.Forms.Button();
            this.button306 = new System.Windows.Forms.Button();
            this.button310 = new System.Windows.Forms.Button();
            this.button311 = new System.Windows.Forms.Button();
            this.button307 = new System.Windows.Forms.Button();
            this.button312 = new System.Windows.Forms.Button();
            this.button302 = new System.Windows.Forms.Button();
            this.button308 = new System.Windows.Forms.Button();
            this.button299 = new System.Windows.Forms.Button();
            this.button303 = new System.Windows.Forms.Button();
            this.button304 = new System.Windows.Forms.Button();
            this.button300 = new System.Windows.Forms.Button();
            this.button305 = new System.Windows.Forms.Button();
            this.button295 = new System.Windows.Forms.Button();
            this.button301 = new System.Windows.Forms.Button();
            this.label414 = new System.Windows.Forms.Label();
            this.button297 = new System.Windows.Forms.Button();
            this.button298 = new System.Windows.Forms.Button();
            this.label428 = new System.Windows.Forms.Label();
            this.label429 = new System.Windows.Forms.Label();
            this.label430 = new System.Windows.Forms.Label();
            this.label432 = new System.Windows.Forms.Label();
            this.label434 = new System.Windows.Forms.Label();
            this.label435 = new System.Windows.Forms.Label();
            this.label436 = new System.Windows.Forms.Label();
            this.label437 = new System.Windows.Forms.Label();
            this.label438 = new System.Windows.Forms.Label();
            this.label439 = new System.Windows.Forms.Label();
            this.heading10 = new Calendar_App.Heading();
            this.November = new System.Windows.Forms.Panel();
            this.Nov = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.panel11 = new System.Windows.Forms.Panel();
            this.button354 = new System.Windows.Forms.Button();
            this.button351 = new System.Windows.Forms.Button();
            this.button355 = new System.Windows.Forms.Button();
            this.button356 = new System.Windows.Forms.Button();
            this.button347 = new System.Windows.Forms.Button();
            this.button352 = new System.Windows.Forms.Button();
            this.button353 = new System.Windows.Forms.Button();
            this.button344 = new System.Windows.Forms.Button();
            this.button348 = new System.Windows.Forms.Button();
            this.button349 = new System.Windows.Forms.Button();
            this.button345 = new System.Windows.Forms.Button();
            this.button350 = new System.Windows.Forms.Button();
            this.button337 = new System.Windows.Forms.Button();
            this.button346 = new System.Windows.Forms.Button();
            this.button338 = new System.Windows.Forms.Button();
            this.button339 = new System.Windows.Forms.Button();
            this.button340 = new System.Windows.Forms.Button();
            this.button341 = new System.Windows.Forms.Button();
            this.button342 = new System.Windows.Forms.Button();
            this.button343 = new System.Windows.Forms.Button();
            this.button330 = new System.Windows.Forms.Button();
            this.button327 = new System.Windows.Forms.Button();
            this.button331 = new System.Windows.Forms.Button();
            this.button328 = new System.Windows.Forms.Button();
            this.button332 = new System.Windows.Forms.Button();
            this.button329 = new System.Windows.Forms.Button();
            this.button333 = new System.Windows.Forms.Button();
            this.label470 = new System.Windows.Forms.Label();
            this.button334 = new System.Windows.Forms.Button();
            this.label471 = new System.Windows.Forms.Label();
            this.button335 = new System.Windows.Forms.Button();
            this.button336 = new System.Windows.Forms.Button();
            this.label472 = new System.Windows.Forms.Label();
            this.label504 = new System.Windows.Forms.Label();
            this.label474 = new System.Windows.Forms.Label();
            this.label475 = new System.Windows.Forms.Label();
            this.label477 = new System.Windows.Forms.Label();
            this.label479 = new System.Windows.Forms.Label();
            this.label480 = new System.Windows.Forms.Label();
            this.label481 = new System.Windows.Forms.Label();
            this.label482 = new System.Windows.Forms.Label();
            this.label484 = new System.Windows.Forms.Label();
            this.heading11 = new Calendar_App.Heading();
            this.December = new System.Windows.Forms.Panel();
            this.Dec = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.panel12 = new System.Windows.Forms.Panel();
            this.button386 = new System.Windows.Forms.Button();
            this.button387 = new System.Windows.Forms.Button();
            this.button382 = new System.Windows.Forms.Button();
            this.button383 = new System.Windows.Forms.Button();
            this.button384 = new System.Windows.Forms.Button();
            this.button385 = new System.Windows.Forms.Button();
            this.button379 = new System.Windows.Forms.Button();
            this.button380 = new System.Windows.Forms.Button();
            this.button375 = new System.Windows.Forms.Button();
            this.button381 = new System.Windows.Forms.Button();
            this.button372 = new System.Windows.Forms.Button();
            this.button376 = new System.Windows.Forms.Button();
            this.button377 = new System.Windows.Forms.Button();
            this.button373 = new System.Windows.Forms.Button();
            this.button378 = new System.Windows.Forms.Button();
            this.button365 = new System.Windows.Forms.Button();
            this.button374 = new System.Windows.Forms.Button();
            this.button366 = new System.Windows.Forms.Button();
            this.button367 = new System.Windows.Forms.Button();
            this.button368 = new System.Windows.Forms.Button();
            this.button369 = new System.Windows.Forms.Button();
            this.button370 = new System.Windows.Forms.Button();
            this.button371 = new System.Windows.Forms.Button();
            this.button360 = new System.Windows.Forms.Button();
            this.button361 = new System.Windows.Forms.Button();
            this.button362 = new System.Windows.Forms.Button();
            this.button363 = new System.Windows.Forms.Button();
            this.button364 = new System.Windows.Forms.Button();
            this.button358 = new System.Windows.Forms.Button();
            this.button357 = new System.Windows.Forms.Button();
            this.button359 = new System.Windows.Forms.Button();
            this.label506 = new System.Windows.Forms.Label();
            this.label514 = new System.Windows.Forms.Label();
            this.label516 = new System.Windows.Forms.Label();
            this.label517 = new System.Windows.Forms.Label();
            this.label518 = new System.Windows.Forms.Label();
            this.label519 = new System.Windows.Forms.Label();
            this.label522 = new System.Windows.Forms.Label();
            this.label527 = new System.Windows.Forms.Label();
            this.label528 = new System.Windows.Forms.Label();
            this.label529 = new System.Windows.Forms.Label();
            this.label530 = new System.Windows.Forms.Label();
            this.heading12 = new Calendar_App.Heading();
            this.Monsec = new System.Windows.Forms.Panel();
            this.mon1 = new System.Windows.Forms.Button();
            this.mon12 = new System.Windows.Forms.Button();
            this.mon11 = new System.Windows.Forms.Button();
            this.mon10 = new System.Windows.Forms.Button();
            this.mon9 = new System.Windows.Forms.Button();
            this.mon8 = new System.Windows.Forms.Button();
            this.mon7 = new System.Windows.Forms.Button();
            this.mon6 = new System.Windows.Forms.Button();
            this.mon5 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.mon2 = new System.Windows.Forms.Button();
            this.mon3 = new System.Windows.Forms.Button();
            this.mon4 = new System.Windows.Forms.Button();
            this.EventPanel = new System.Windows.Forms.Panel();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonEnd = new System.Windows.Forms.Button();
            this.label135 = new System.Windows.Forms.Label();
            this.dashbordgrow = new System.Windows.Forms.Timer(this.components);
            this.dashbordshrink = new System.Windows.Forms.Timer(this.components);
            this.Monsecgrow = new System.Windows.Forms.Timer(this.components);
            this.Monsecshrink = new System.Windows.Forms.Timer(this.components);
            this.JanuaryGrow = new System.Windows.Forms.Timer(this.components);
            this.JanuaryShrink = new System.Windows.Forms.Timer(this.components);
            this.FebruaryGrow = new System.Windows.Forms.Timer(this.components);
            this.FebruaryShrink = new System.Windows.Forms.Timer(this.components);
            this.MarchGrow = new System.Windows.Forms.Timer(this.components);
            this.MarchShrink = new System.Windows.Forms.Timer(this.components);
            this.AprilGrow = new System.Windows.Forms.Timer(this.components);
            this.AprilShrink = new System.Windows.Forms.Timer(this.components);
            this.MayGrow = new System.Windows.Forms.Timer(this.components);
            this.MayShrink = new System.Windows.Forms.Timer(this.components);
            this.JuneGrow = new System.Windows.Forms.Timer(this.components);
            this.JuneShrink = new System.Windows.Forms.Timer(this.components);
            this.JulyGrow = new System.Windows.Forms.Timer(this.components);
            this.JulyShrink = new System.Windows.Forms.Timer(this.components);
            this.OctoberShrink = new System.Windows.Forms.Timer(this.components);
            this.AugustGrow = new System.Windows.Forms.Timer(this.components);
            this.AugustShrink = new System.Windows.Forms.Timer(this.components);
            this.SeptemberGrow = new System.Windows.Forms.Timer(this.components);
            this.SeptemberShrink = new System.Windows.Forms.Timer(this.components);
            this.OctoberGrow = new System.Windows.Forms.Timer(this.components);
            this.NovemberGrow = new System.Windows.Forms.Timer(this.components);
            this.NovemberShrink = new System.Windows.Forms.Timer(this.components);
            this.Minimize = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.dashbord1 = new Calendar_App.Dashbord();
            this.panel2.SuspendLayout();
            this.January.SuspendLayout();
            this.datepanel.SuspendLayout();
            this.February.SuspendLayout();
            this.panel1.SuspendLayout();
            this.March.SuspendLayout();
            this.panel3.SuspendLayout();
            this.April.SuspendLayout();
            this.panel4.SuspendLayout();
            this.May.SuspendLayout();
            this.panel5.SuspendLayout();
            this.June.SuspendLayout();
            this.panel6.SuspendLayout();
            this.July.SuspendLayout();
            this.panel7.SuspendLayout();
            this.August.SuspendLayout();
            this.panel8.SuspendLayout();
            this.September.SuspendLayout();
            this.panel9.SuspendLayout();
            this.October.SuspendLayout();
            this.panel10.SuspendLayout();
            this.November.SuspendLayout();
            this.panel11.SuspendLayout();
            this.December.SuspendLayout();
            this.panel12.SuspendLayout();
            this.Monsec.SuspendLayout();
            this.EventPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // bottomborder
            // 
            this.bottomborder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.bottomborder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomborder.Location = new System.Drawing.Point(3, 423);
            this.bottomborder.Name = "bottomborder";
            this.bottomborder.Size = new System.Drawing.Size(482, 10);
            this.bottomborder.TabIndex = 125;
            // 
            // topborder
            // 
            this.topborder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.topborder.Dock = System.Windows.Forms.DockStyle.Top;
            this.topborder.ForeColor = System.Drawing.Color.Transparent;
            this.topborder.Location = new System.Drawing.Point(0, 0);
            this.topborder.Name = "topborder";
            this.topborder.Size = new System.Drawing.Size(488, 32);
            this.topborder.TabIndex = 124;
            this.topborder.MouseDown += new System.Windows.Forms.MouseEventHandler(this.topborder_MouseDown);
            this.topborder.MouseMove += new System.Windows.Forms.MouseEventHandler(this.topborder_MouseMove);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(413, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 34);
            this.label9.TabIndex = 10;
            this.label9.Text = "2018";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label137);
            this.panel2.Controls.Add(this.Dashbord);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Location = new System.Drawing.Point(2, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(484, 40);
            this.panel2.TabIndex = 228;
            // 
            // label137
            // 
            this.label137.BackColor = System.Drawing.Color.Black;
            this.label137.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label137.Location = new System.Drawing.Point(0, 39);
            this.label137.Name = "label137";
            this.label137.Size = new System.Drawing.Size(484, 1);
            this.label137.TabIndex = 135;
            this.label137.Text = "label137";
            // 
            // Dashbord
            // 
            this.Dashbord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dashbord.BackgroundImage")));
            this.Dashbord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Dashbord.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dashbord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Dashbord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Dashbord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dashbord.Location = new System.Drawing.Point(8, 5);
            this.Dashbord.Name = "Dashbord";
            this.Dashbord.Size = new System.Drawing.Size(29, 29);
            this.Dashbord.TabIndex = 134;
            this.Dashbord.TabStop = false;
            this.Dashbord.UseVisualStyleBackColor = true;
            this.Dashbord.Click += new System.EventHandler(this.Dashbord_Click);
            // 
            // BorderRight
            // 
            this.BorderRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.BorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.BorderRight.Location = new System.Drawing.Point(485, 32);
            this.BorderRight.Name = "BorderRight";
            this.BorderRight.Size = new System.Drawing.Size(3, 401);
            this.BorderRight.TabIndex = 126;
            // 
            // BorderLeft
            // 
            this.BorderLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.BorderLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.BorderLeft.Location = new System.Drawing.Point(0, 32);
            this.BorderLeft.Name = "BorderLeft";
            this.BorderLeft.Size = new System.Drawing.Size(3, 401);
            this.BorderLeft.TabIndex = 126;
            this.BorderLeft.Text = "label4";
            this.BorderLeft.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // January
            // 
            this.January.Controls.Add(this.jan);
            this.January.Controls.Add(this.datepanel);
            this.January.Controls.Add(this.RightButton);
            this.January.Controls.Add(this.heading1);
            this.January.Location = new System.Drawing.Point(1, 70);
            this.January.Name = "January";
            this.January.Size = new System.Drawing.Size(486, 353);
            this.January.TabIndex = 229;
            this.January.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // jan
            // 
            this.jan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.jan.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jan.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.jan.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.jan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jan.Font = new System.Drawing.Font("Impact", 20.25F);
            this.jan.Location = new System.Drawing.Point(139, 0);
            this.jan.Name = "jan";
            this.jan.Size = new System.Drawing.Size(208, 39);
            this.jan.TabIndex = 155;
            this.jan.TabStop = false;
            this.jan.Text = "January";
            this.jan.UseVisualStyleBackColor = false;
            this.jan.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // datepanel
            // 
            this.datepanel.Controls.Add(this.button49);
            this.datepanel.Controls.Add(this.button51);
            this.datepanel.Controls.Add(this.button52);
            this.datepanel.Controls.Add(this.button53);
            this.datepanel.Controls.Add(this.button38);
            this.datepanel.Controls.Add(this.button39);
            this.datepanel.Controls.Add(this.button41);
            this.datepanel.Controls.Add(this.button43);
            this.datepanel.Controls.Add(this.button44);
            this.datepanel.Controls.Add(this.button46);
            this.datepanel.Controls.Add(this.button48);
            this.datepanel.Controls.Add(this.button26);
            this.datepanel.Controls.Add(this.button28);
            this.datepanel.Controls.Add(this.button29);
            this.datepanel.Controls.Add(this.button31);
            this.datepanel.Controls.Add(this.button33);
            this.datepanel.Controls.Add(this.button34);
            this.datepanel.Controls.Add(this.button36);
            this.datepanel.Controls.Add(this.button24);
            this.datepanel.Controls.Add(this.button14);
            this.datepanel.Controls.Add(this.button16);
            this.datepanel.Controls.Add(this.button18);
            this.datepanel.Controls.Add(this.button19);
            this.datepanel.Controls.Add(this.button21);
            this.datepanel.Controls.Add(this.button23);
            this.datepanel.Controls.Add(this.button6);
            this.datepanel.Controls.Add(this.button11);
            this.datepanel.Controls.Add(this.button13);
            this.datepanel.Controls.Add(this.button4);
            this.datepanel.Controls.Add(this.button3);
            this.datepanel.Controls.Add(this.button1);
            this.datepanel.Controls.Add(this.label36);
            this.datepanel.Controls.Add(this.label55);
            this.datepanel.Controls.Add(this.label12);
            this.datepanel.Controls.Add(this.label56);
            this.datepanel.Controls.Add(this.label10);
            this.datepanel.Controls.Add(this.label57);
            this.datepanel.Controls.Add(this.label11);
            this.datepanel.Controls.Add(this.label15);
            this.datepanel.Controls.Add(this.label35);
            this.datepanel.Controls.Add(this.label14);
            this.datepanel.Controls.Add(this.label41);
            this.datepanel.Location = new System.Drawing.Point(1, 58);
            this.datepanel.Name = "datepanel";
            this.datepanel.Size = new System.Drawing.Size(484, 295);
            this.datepanel.TabIndex = 135;
            // 
            // button49
            // 
            this.button49.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button49.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button49.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button49.Location = new System.Drawing.Point(0, 245);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(70, 50);
            this.button49.TabIndex = 185;
            this.button49.TabStop = false;
            this.button49.Text = "28";
            this.button49.UseCompatibleTextRendering = true;
            this.button49.UseVisualStyleBackColor = true;
            this.button49.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button51
            // 
            this.button51.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button51.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button51.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button51.Location = new System.Drawing.Point(207, 245);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(70, 50);
            this.button51.TabIndex = 184;
            this.button51.TabStop = false;
            this.button51.Text = "31";
            this.button51.UseCompatibleTextRendering = true;
            this.button51.UseVisualStyleBackColor = true;
            this.button51.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button52
            // 
            this.button52.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button52.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button52.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button52.Location = new System.Drawing.Point(138, 245);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(70, 50);
            this.button52.TabIndex = 183;
            this.button52.TabStop = false;
            this.button52.Text = "30";
            this.button52.UseCompatibleTextRendering = true;
            this.button52.UseVisualStyleBackColor = true;
            this.button52.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button53
            // 
            this.button53.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button53.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button53.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button53.Location = new System.Drawing.Point(69, 245);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(70, 50);
            this.button53.TabIndex = 182;
            this.button53.TabStop = false;
            this.button53.Text = "29";
            this.button53.UseCompatibleTextRendering = true;
            this.button53.UseVisualStyleBackColor = true;
            this.button53.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button38
            // 
            this.button38.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button38.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button38.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button38.Location = new System.Drawing.Point(0, 196);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(70, 50);
            this.button38.TabIndex = 181;
            this.button38.TabStop = false;
            this.button38.Text = "21";
            this.button38.UseCompatibleTextRendering = true;
            this.button38.UseVisualStyleBackColor = true;
            this.button38.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button39
            // 
            this.button39.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button39.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button39.Location = new System.Drawing.Point(414, 196);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(70, 50);
            this.button39.TabIndex = 180;
            this.button39.TabStop = false;
            this.button39.Text = "27";
            this.button39.UseCompatibleTextRendering = true;
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button41
            // 
            this.button41.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button41.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button41.Location = new System.Drawing.Point(345, 196);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(70, 50);
            this.button41.TabIndex = 179;
            this.button41.TabStop = false;
            this.button41.Text = "26";
            this.button41.UseCompatibleTextRendering = true;
            this.button41.UseVisualStyleBackColor = true;
            this.button41.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button43
            // 
            this.button43.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button43.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button43.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button43.Location = new System.Drawing.Point(276, 196);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(70, 50);
            this.button43.TabIndex = 178;
            this.button43.TabStop = false;
            this.button43.Text = "25";
            this.button43.UseCompatibleTextRendering = true;
            this.button43.UseVisualStyleBackColor = true;
            this.button43.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button44
            // 
            this.button44.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button44.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button44.Location = new System.Drawing.Point(207, 196);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(70, 50);
            this.button44.TabIndex = 177;
            this.button44.TabStop = false;
            this.button44.Text = "24";
            this.button44.UseCompatibleTextRendering = true;
            this.button44.UseVisualStyleBackColor = true;
            this.button44.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button46
            // 
            this.button46.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button46.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button46.Location = new System.Drawing.Point(138, 196);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(70, 50);
            this.button46.TabIndex = 176;
            this.button46.TabStop = false;
            this.button46.Text = "23";
            this.button46.UseCompatibleTextRendering = true;
            this.button46.UseVisualStyleBackColor = true;
            this.button46.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button48
            // 
            this.button48.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button48.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button48.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button48.Location = new System.Drawing.Point(69, 196);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(70, 50);
            this.button48.TabIndex = 175;
            this.button48.TabStop = false;
            this.button48.Text = "22";
            this.button48.UseCompatibleTextRendering = true;
            this.button48.UseVisualStyleBackColor = true;
            this.button48.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button26
            // 
            this.button26.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button26.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button26.Location = new System.Drawing.Point(0, 147);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(70, 50);
            this.button26.TabIndex = 174;
            this.button26.TabStop = false;
            this.button26.Text = "14";
            this.button26.UseCompatibleTextRendering = true;
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button28
            // 
            this.button28.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button28.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button28.Location = new System.Drawing.Point(414, 147);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(70, 50);
            this.button28.TabIndex = 173;
            this.button28.TabStop = false;
            this.button28.Text = "20";
            this.button28.UseCompatibleTextRendering = true;
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button29
            // 
            this.button29.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button29.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button29.Location = new System.Drawing.Point(345, 147);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(70, 50);
            this.button29.TabIndex = 172;
            this.button29.TabStop = false;
            this.button29.Text = "19";
            this.button29.UseCompatibleTextRendering = true;
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button31
            // 
            this.button31.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button31.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button31.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button31.Location = new System.Drawing.Point(276, 147);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(70, 50);
            this.button31.TabIndex = 171;
            this.button31.TabStop = false;
            this.button31.Text = "18";
            this.button31.UseCompatibleTextRendering = true;
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button33
            // 
            this.button33.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button33.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button33.Location = new System.Drawing.Point(207, 147);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(70, 50);
            this.button33.TabIndex = 170;
            this.button33.TabStop = false;
            this.button33.Text = "17";
            this.button33.UseCompatibleTextRendering = true;
            this.button33.UseVisualStyleBackColor = true;
            this.button33.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button34
            // 
            this.button34.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button34.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button34.Location = new System.Drawing.Point(138, 147);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(70, 50);
            this.button34.TabIndex = 169;
            this.button34.TabStop = false;
            this.button34.Text = "16";
            this.button34.UseCompatibleTextRendering = true;
            this.button34.UseVisualStyleBackColor = true;
            this.button34.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button36
            // 
            this.button36.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button36.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button36.Location = new System.Drawing.Point(69, 147);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(70, 50);
            this.button36.TabIndex = 168;
            this.button36.TabStop = false;
            this.button36.Text = "15";
            this.button36.UseCompatibleTextRendering = true;
            this.button36.UseVisualStyleBackColor = true;
            this.button36.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button24
            // 
            this.button24.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button24.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button24.Location = new System.Drawing.Point(0, 98);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(70, 50);
            this.button24.TabIndex = 167;
            this.button24.TabStop = false;
            this.button24.Text = "7";
            this.button24.UseCompatibleTextRendering = true;
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button14
            // 
            this.button14.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button14.Location = new System.Drawing.Point(414, 98);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(70, 50);
            this.button14.TabIndex = 166;
            this.button14.TabStop = false;
            this.button14.Text = "13";
            this.button14.UseCompatibleTextRendering = true;
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button16
            // 
            this.button16.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button16.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button16.Location = new System.Drawing.Point(345, 98);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(70, 50);
            this.button16.TabIndex = 165;
            this.button16.TabStop = false;
            this.button16.Text = "12";
            this.button16.UseCompatibleTextRendering = true;
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button18
            // 
            this.button18.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button18.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button18.Location = new System.Drawing.Point(276, 98);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(70, 50);
            this.button18.TabIndex = 164;
            this.button18.TabStop = false;
            this.button18.Text = "11";
            this.button18.UseCompatibleTextRendering = true;
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button19
            // 
            this.button19.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button19.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button19.Location = new System.Drawing.Point(207, 98);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(70, 50);
            this.button19.TabIndex = 163;
            this.button19.TabStop = false;
            this.button19.Text = "10";
            this.button19.UseCompatibleTextRendering = true;
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button21
            // 
            this.button21.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button21.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button21.Location = new System.Drawing.Point(138, 98);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(70, 50);
            this.button21.TabIndex = 162;
            this.button21.TabStop = false;
            this.button21.Text = "9";
            this.button21.UseCompatibleTextRendering = true;
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button23
            // 
            this.button23.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button23.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button23.Location = new System.Drawing.Point(69, 98);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(70, 50);
            this.button23.TabIndex = 161;
            this.button23.TabStop = false;
            this.button23.Text = "8";
            this.button23.UseCompatibleTextRendering = true;
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button6
            // 
            this.button6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button6.Location = new System.Drawing.Point(414, 49);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(70, 50);
            this.button6.TabIndex = 160;
            this.button6.TabStop = false;
            this.button6.Text = "6";
            this.button6.UseCompatibleTextRendering = true;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button11
            // 
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button11.Location = new System.Drawing.Point(345, 49);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(70, 50);
            this.button11.TabIndex = 159;
            this.button11.TabStop = false;
            this.button11.Text = "5";
            this.button11.UseCompatibleTextRendering = true;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button13
            // 
            this.button13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button13.Location = new System.Drawing.Point(276, 49);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(70, 50);
            this.button13.TabIndex = 158;
            this.button13.TabStop = false;
            this.button13.Text = "4";
            this.button13.UseCompatibleTextRendering = true;
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button4
            // 
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button4.Location = new System.Drawing.Point(207, 49);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(70, 50);
            this.button4.TabIndex = 157;
            this.button4.TabStop = false;
            this.button4.Text = "3";
            this.button4.UseCompatibleTextRendering = true;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button3
            // 
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button3.Location = new System.Drawing.Point(138, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(70, 50);
            this.button3.TabIndex = 156;
            this.button3.TabStop = false;
            this.button3.Text = "2";
            this.button3.UseCompatibleTextRendering = true;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button1
            // 
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button1.Location = new System.Drawing.Point(69, 49);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 50);
            this.button1.TabIndex = 155;
            this.button1.TabStop = false;
            this.button1.Text = "1";
            this.button1.UseCompatibleTextRendering = true;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label36
            // 
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Gray;
            this.label36.Location = new System.Drawing.Point(69, 0);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(70, 50);
            this.label36.TabIndex = 142;
            this.label36.Text = "25";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Gray;
            this.label55.Location = new System.Drawing.Point(345, 245);
            this.label55.Name = "label55";
            this.label55.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label55.Size = new System.Drawing.Size(70, 50);
            this.label55.TabIndex = 148;
            this.label55.Text = "2";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(414, 0);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(70, 50);
            this.label12.TabIndex = 115;
            this.label12.Text = "30";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.Gray;
            this.label56.Location = new System.Drawing.Point(276, 245);
            this.label56.Name = "label56";
            this.label56.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label56.Size = new System.Drawing.Size(70, 50);
            this.label56.TabIndex = 147;
            this.label56.Text = "1";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(276, 0);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(70, 50);
            this.label10.TabIndex = 113;
            this.label10.Text = "28";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.Gray;
            this.label57.Location = new System.Drawing.Point(414, 245);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(70, 50);
            this.label57.TabIndex = 149;
            this.label57.Text = "3";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(345, 0);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(70, 50);
            this.label11.TabIndex = 114;
            this.label11.Text = "29";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gray;
            this.label15.Location = new System.Drawing.Point(0, 49);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(70, 50);
            this.label15.TabIndex = 117;
            this.label15.Text = "31";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Gray;
            this.label35.Location = new System.Drawing.Point(138, 0);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(70, 50);
            this.label35.TabIndex = 141;
            this.label35.Text = "26";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(207, 0);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(70, 50);
            this.label14.TabIndex = 140;
            this.label14.Text = "27";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Gray;
            this.label41.Location = new System.Drawing.Point(0, 0);
            this.label41.Name = "label41";
            this.label41.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label41.Size = new System.Drawing.Size(70, 50);
            this.label41.TabIndex = 143;
            this.label41.Text = "24";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // RightButton
            // 
            this.RightButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.RightButton.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.RightButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RightButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RightButton.FlatAppearance.BorderSize = 0;
            this.RightButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.RightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RightButton.Location = new System.Drawing.Point(452, 4);
            this.RightButton.Name = "RightButton";
            this.RightButton.Size = new System.Drawing.Size(30, 30);
            this.RightButton.TabIndex = 133;
            this.RightButton.TabStop = false;
            this.RightButton.UseVisualStyleBackColor = false;
            this.RightButton.Click += new System.EventHandler(this.RightButton_Click);
            // 
            // heading1
            // 
            this.heading1.Location = new System.Drawing.Point(1, 1);
            this.heading1.Name = "heading1";
            this.heading1.Size = new System.Drawing.Size(484, 58);
            this.heading1.TabIndex = 137;
            // 
            // February
            // 
            this.February.Controls.Add(this.Feb);
            this.February.Controls.Add(this.panel1);
            this.February.Controls.Add(this.button2);
            this.February.Controls.Add(this.button5);
            this.February.Controls.Add(this.heading2);
            this.February.Location = new System.Drawing.Point(2, 70);
            this.February.Name = "February";
            this.February.Size = new System.Drawing.Size(486, 353);
            this.February.TabIndex = 230;
            // 
            // Feb
            // 
            this.Feb.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Feb.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Feb.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Feb.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Feb.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Feb.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Feb.Location = new System.Drawing.Point(139, 0);
            this.Feb.Name = "Feb";
            this.Feb.Size = new System.Drawing.Size(208, 39);
            this.Feb.TabIndex = 156;
            this.Feb.TabStop = false;
            this.Feb.Text = "February";
            this.Feb.UseVisualStyleBackColor = false;
            this.Feb.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button83);
            this.panel1.Controls.Add(this.button80);
            this.panel1.Controls.Add(this.button76);
            this.panel1.Controls.Add(this.button81);
            this.panel1.Controls.Add(this.button82);
            this.panel1.Controls.Add(this.button77);
            this.panel1.Controls.Add(this.button78);
            this.panel1.Controls.Add(this.button79);
            this.panel1.Controls.Add(this.button73);
            this.panel1.Controls.Add(this.button66);
            this.panel1.Controls.Add(this.button74);
            this.panel1.Controls.Add(this.button75);
            this.panel1.Controls.Add(this.button67);
            this.panel1.Controls.Add(this.button68);
            this.panel1.Controls.Add(this.button69);
            this.panel1.Controls.Add(this.button70);
            this.panel1.Controls.Add(this.button71);
            this.panel1.Controls.Add(this.button72);
            this.panel1.Controls.Add(this.button62);
            this.panel1.Controls.Add(this.button56);
            this.panel1.Controls.Add(this.button63);
            this.panel1.Controls.Add(this.button60);
            this.panel1.Controls.Add(this.button64);
            this.panel1.Controls.Add(this.button65);
            this.panel1.Controls.Add(this.button61);
            this.panel1.Controls.Add(this.button57);
            this.panel1.Controls.Add(this.button58);
            this.panel1.Controls.Add(this.button59);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label86);
            this.panel1.Location = new System.Drawing.Point(1, 58);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(484, 295);
            this.panel1.TabIndex = 124;
            // 
            // button83
            // 
            this.button83.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button83.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button83.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button83.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button83.Location = new System.Drawing.Point(206, 196);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(70, 50);
            this.button83.TabIndex = 200;
            this.button83.TabStop = false;
            this.button83.Text = "28";
            this.button83.UseCompatibleTextRendering = true;
            this.button83.UseVisualStyleBackColor = true;
            this.button83.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button80
            // 
            this.button80.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button80.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button80.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button80.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button80.Location = new System.Drawing.Point(137, 196);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(70, 50);
            this.button80.TabIndex = 246;
            this.button80.TabStop = false;
            this.button80.Text = "27";
            this.button80.UseCompatibleTextRendering = true;
            this.button80.UseVisualStyleBackColor = true;
            this.button80.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button76
            // 
            this.button76.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button76.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button76.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button76.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button76.Location = new System.Drawing.Point(206, 147);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(70, 50);
            this.button76.TabIndex = 250;
            this.button76.TabStop = false;
            this.button76.Text = "21";
            this.button76.UseCompatibleTextRendering = true;
            this.button76.UseVisualStyleBackColor = true;
            this.button76.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button81
            // 
            this.button81.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button81.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button81.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button81.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button81.Location = new System.Drawing.Point(68, 196);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(70, 50);
            this.button81.TabIndex = 245;
            this.button81.TabStop = false;
            this.button81.Text = "26";
            this.button81.UseCompatibleTextRendering = true;
            this.button81.UseVisualStyleBackColor = true;
            this.button81.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button82
            // 
            this.button82.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button82.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button82.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button82.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button82.Location = new System.Drawing.Point(-1, 196);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(70, 50);
            this.button82.TabIndex = 244;
            this.button82.TabStop = false;
            this.button82.Text = "25";
            this.button82.UseCompatibleTextRendering = true;
            this.button82.UseVisualStyleBackColor = true;
            this.button82.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button77
            // 
            this.button77.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button77.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button77.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button77.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button77.Location = new System.Drawing.Point(413, 147);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(70, 50);
            this.button77.TabIndex = 249;
            this.button77.TabStop = false;
            this.button77.Text = "24";
            this.button77.UseCompatibleTextRendering = true;
            this.button77.UseVisualStyleBackColor = true;
            this.button77.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button78
            // 
            this.button78.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button78.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button78.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button78.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button78.Location = new System.Drawing.Point(344, 147);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(70, 50);
            this.button78.TabIndex = 248;
            this.button78.TabStop = false;
            this.button78.Text = "23";
            this.button78.UseCompatibleTextRendering = true;
            this.button78.UseVisualStyleBackColor = true;
            this.button78.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button79
            // 
            this.button79.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button79.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button79.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button79.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button79.Location = new System.Drawing.Point(275, 147);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(70, 50);
            this.button79.TabIndex = 247;
            this.button79.TabStop = false;
            this.button79.Text = "22";
            this.button79.UseCompatibleTextRendering = true;
            this.button79.UseVisualStyleBackColor = true;
            this.button79.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button73
            // 
            this.button73.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button73.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button73.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button73.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button73.Location = new System.Drawing.Point(137, 147);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(70, 50);
            this.button73.TabIndex = 246;
            this.button73.TabStop = false;
            this.button73.Text = "20";
            this.button73.UseCompatibleTextRendering = true;
            this.button73.UseVisualStyleBackColor = true;
            this.button73.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button66
            // 
            this.button66.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button66.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button66.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button66.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button66.Location = new System.Drawing.Point(206, 98);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(70, 50);
            this.button66.TabIndex = 181;
            this.button66.TabStop = false;
            this.button66.Text = "14";
            this.button66.UseCompatibleTextRendering = true;
            this.button66.UseVisualStyleBackColor = true;
            this.button66.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button74
            // 
            this.button74.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button74.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button74.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button74.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button74.Location = new System.Drawing.Point(68, 147);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(70, 50);
            this.button74.TabIndex = 245;
            this.button74.TabStop = false;
            this.button74.Text = "19";
            this.button74.UseCompatibleTextRendering = true;
            this.button74.UseVisualStyleBackColor = true;
            this.button74.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button75
            // 
            this.button75.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button75.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button75.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button75.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button75.Location = new System.Drawing.Point(-1, 147);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(70, 50);
            this.button75.TabIndex = 244;
            this.button75.TabStop = false;
            this.button75.Text = "18";
            this.button75.UseCompatibleTextRendering = true;
            this.button75.UseVisualStyleBackColor = true;
            this.button75.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button67
            // 
            this.button67.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button67.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button67.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button67.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button67.Location = new System.Drawing.Point(413, 98);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(70, 50);
            this.button67.TabIndex = 180;
            this.button67.TabStop = false;
            this.button67.Text = "17";
            this.button67.UseCompatibleTextRendering = true;
            this.button67.UseVisualStyleBackColor = true;
            this.button67.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button68
            // 
            this.button68.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button68.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button68.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button68.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button68.Location = new System.Drawing.Point(344, 98);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(70, 50);
            this.button68.TabIndex = 179;
            this.button68.TabStop = false;
            this.button68.Text = "16";
            this.button68.UseCompatibleTextRendering = true;
            this.button68.UseVisualStyleBackColor = true;
            this.button68.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button69
            // 
            this.button69.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button69.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button69.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button69.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button69.Location = new System.Drawing.Point(275, 98);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(70, 50);
            this.button69.TabIndex = 178;
            this.button69.TabStop = false;
            this.button69.Text = "15";
            this.button69.UseCompatibleTextRendering = true;
            this.button69.UseVisualStyleBackColor = true;
            this.button69.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button70
            // 
            this.button70.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button70.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button70.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button70.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button70.Location = new System.Drawing.Point(137, 98);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(70, 50);
            this.button70.TabIndex = 177;
            this.button70.TabStop = false;
            this.button70.Text = "13";
            this.button70.UseCompatibleTextRendering = true;
            this.button70.UseVisualStyleBackColor = true;
            this.button70.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button71
            // 
            this.button71.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button71.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button71.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button71.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button71.Location = new System.Drawing.Point(68, 98);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(70, 50);
            this.button71.TabIndex = 176;
            this.button71.TabStop = false;
            this.button71.Text = "12";
            this.button71.UseCompatibleTextRendering = true;
            this.button71.UseVisualStyleBackColor = true;
            this.button71.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button72
            // 
            this.button72.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button72.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button72.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button72.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button72.Location = new System.Drawing.Point(-1, 98);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(70, 50);
            this.button72.TabIndex = 175;
            this.button72.TabStop = false;
            this.button72.Text = "11";
            this.button72.UseCompatibleTextRendering = true;
            this.button72.UseVisualStyleBackColor = true;
            this.button72.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button62
            // 
            this.button62.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button62.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button62.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button62.Location = new System.Drawing.Point(206, 49);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(70, 50);
            this.button62.TabIndex = 171;
            this.button62.TabStop = false;
            this.button62.Text = "7";
            this.button62.UseCompatibleTextRendering = true;
            this.button62.UseVisualStyleBackColor = true;
            this.button62.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button56
            // 
            this.button56.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button56.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button56.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button56.Location = new System.Drawing.Point(137, 49);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(70, 50);
            this.button56.TabIndex = 164;
            this.button56.TabStop = false;
            this.button56.Text = "6";
            this.button56.UseCompatibleTextRendering = true;
            this.button56.UseVisualStyleBackColor = true;
            this.button56.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button63
            // 
            this.button63.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button63.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button63.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button63.Location = new System.Drawing.Point(413, 49);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(70, 50);
            this.button63.TabIndex = 170;
            this.button63.TabStop = false;
            this.button63.Text = "10";
            this.button63.UseCompatibleTextRendering = true;
            this.button63.UseVisualStyleBackColor = true;
            this.button63.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button60
            // 
            this.button60.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button60.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button60.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button60.Location = new System.Drawing.Point(68, 49);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(70, 50);
            this.button60.TabIndex = 163;
            this.button60.TabStop = false;
            this.button60.Text = "5";
            this.button60.UseCompatibleTextRendering = true;
            this.button60.UseVisualStyleBackColor = true;
            this.button60.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button64
            // 
            this.button64.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button64.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button64.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button64.Location = new System.Drawing.Point(344, 49);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(70, 50);
            this.button64.TabIndex = 169;
            this.button64.TabStop = false;
            this.button64.Text = "9";
            this.button64.UseCompatibleTextRendering = true;
            this.button64.UseVisualStyleBackColor = true;
            this.button64.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button65
            // 
            this.button65.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button65.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button65.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button65.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button65.Location = new System.Drawing.Point(275, 49);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(70, 50);
            this.button65.TabIndex = 168;
            this.button65.TabStop = false;
            this.button65.Text = "8";
            this.button65.UseCompatibleTextRendering = true;
            this.button65.UseVisualStyleBackColor = true;
            this.button65.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button61
            // 
            this.button61.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button61.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button61.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button61.Location = new System.Drawing.Point(-1, 49);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(70, 50);
            this.button61.TabIndex = 162;
            this.button61.TabStop = false;
            this.button61.Text = "4";
            this.button61.UseCompatibleTextRendering = true;
            this.button61.UseVisualStyleBackColor = true;
            this.button61.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button57
            // 
            this.button57.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button57.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button57.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button57.Location = new System.Drawing.Point(413, 0);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(70, 50);
            this.button57.TabIndex = 161;
            this.button57.TabStop = false;
            this.button57.Text = "3";
            this.button57.UseCompatibleTextRendering = true;
            this.button57.UseVisualStyleBackColor = true;
            this.button57.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button58
            // 
            this.button58.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button58.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button58.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button58.Location = new System.Drawing.Point(344, 0);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(70, 50);
            this.button58.TabIndex = 160;
            this.button58.TabStop = false;
            this.button58.Text = "2";
            this.button58.UseCompatibleTextRendering = true;
            this.button58.UseVisualStyleBackColor = true;
            this.button58.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button59
            // 
            this.button59.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button59.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button59.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button59.Location = new System.Drawing.Point(275, 0);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(70, 50);
            this.button59.TabIndex = 159;
            this.button59.TabStop = false;
            this.button59.Text = "1";
            this.button59.UseCompatibleTextRendering = true;
            this.button59.UseVisualStyleBackColor = true;
            this.button59.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label1
            // 
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Gray;
            this.label1.Location = new System.Drawing.Point(275, 196);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label1.Size = new System.Drawing.Size(70, 50);
            this.label1.TabIndex = 154;
            this.label1.Text = "1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label4.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(206, 245);
            this.label4.Name = "label4";
            this.label4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label4.Size = new System.Drawing.Size(70, 50);
            this.label4.TabIndex = 153;
            this.label4.Text = "7";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Gray;
            this.label5.Location = new System.Drawing.Point(68, 0);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(70, 50);
            this.label5.TabIndex = 142;
            this.label5.Text = "29";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label6
            // 
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label6.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Gray;
            this.label6.Location = new System.Drawing.Point(-1, 245);
            this.label6.Name = "label6";
            this.label6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label6.Size = new System.Drawing.Size(70, 50);
            this.label6.TabIndex = 152;
            this.label6.Text = "4";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label8
            // 
            this.label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label8.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Gray;
            this.label8.Location = new System.Drawing.Point(68, 245);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label8.Size = new System.Drawing.Size(70, 50);
            this.label8.TabIndex = 151;
            this.label8.Text = "5";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label43
            // 
            this.label43.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label43.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.Gray;
            this.label43.Location = new System.Drawing.Point(137, 245);
            this.label43.Name = "label43";
            this.label43.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label43.Size = new System.Drawing.Size(70, 50);
            this.label43.TabIndex = 150;
            this.label43.Text = "6";
            this.label43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label45
            // 
            this.label45.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label45.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.ForeColor = System.Drawing.Color.Gray;
            this.label45.Location = new System.Drawing.Point(344, 245);
            this.label45.Name = "label45";
            this.label45.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label45.Size = new System.Drawing.Size(70, 50);
            this.label45.TabIndex = 148;
            this.label45.Text = "9";
            this.label45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label46
            // 
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label46.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.ForeColor = System.Drawing.Color.Gray;
            this.label46.Location = new System.Drawing.Point(275, 245);
            this.label46.Name = "label46";
            this.label46.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label46.Size = new System.Drawing.Size(70, 50);
            this.label46.TabIndex = 147;
            this.label46.Text = "8";
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label48
            // 
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.ForeColor = System.Drawing.Color.Gray;
            this.label48.Location = new System.Drawing.Point(413, 245);
            this.label48.Name = "label48";
            this.label48.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label48.Size = new System.Drawing.Size(70, 50);
            this.label48.TabIndex = 149;
            this.label48.Text = "10";
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label51
            // 
            this.label51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label51.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.ForeColor = System.Drawing.Color.Gray;
            this.label51.Location = new System.Drawing.Point(344, 196);
            this.label51.Name = "label51";
            this.label51.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label51.Size = new System.Drawing.Size(70, 50);
            this.label51.TabIndex = 145;
            this.label51.Text = "2";
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label63
            // 
            this.label63.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label63.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label63.ForeColor = System.Drawing.Color.Gray;
            this.label63.Location = new System.Drawing.Point(413, 196);
            this.label63.Name = "label63";
            this.label63.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label63.Size = new System.Drawing.Size(70, 50);
            this.label63.TabIndex = 146;
            this.label63.Text = "3";
            this.label63.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label67
            // 
            this.label67.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label67.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label67.ForeColor = System.Drawing.Color.Gray;
            this.label67.Location = new System.Drawing.Point(137, 0);
            this.label67.Name = "label67";
            this.label67.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label67.Size = new System.Drawing.Size(70, 50);
            this.label67.TabIndex = 141;
            this.label67.Text = "30";
            this.label67.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label69
            // 
            this.label69.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label69.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label69.ForeColor = System.Drawing.Color.Gray;
            this.label69.Location = new System.Drawing.Point(206, 0);
            this.label69.Name = "label69";
            this.label69.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label69.Size = new System.Drawing.Size(70, 50);
            this.label69.TabIndex = 140;
            this.label69.Text = "31";
            this.label69.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label86
            // 
            this.label86.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label86.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label86.ForeColor = System.Drawing.Color.Gray;
            this.label86.Location = new System.Drawing.Point(-1, 0);
            this.label86.Name = "label86";
            this.label86.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label86.Size = new System.Drawing.Size(70, 50);
            this.label86.TabIndex = 143;
            this.label86.Text = "28";
            this.label86.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button2.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderSize = 0;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(451, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(30, 30);
            this.button2.TabIndex = 122;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button5.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderSize = 0;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(4, 4);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(30, 30);
            this.button5.TabIndex = 121;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // heading2
            // 
            this.heading2.Location = new System.Drawing.Point(0, 1);
            this.heading2.Name = "heading2";
            this.heading2.Size = new System.Drawing.Size(484, 58);
            this.heading2.TabIndex = 138;
            // 
            // March
            // 
            this.March.Controls.Add(this.Mar);
            this.March.Controls.Add(this.button7);
            this.March.Controls.Add(this.button10);
            this.March.Controls.Add(this.heading3);
            this.March.Controls.Add(this.panel3);
            this.March.Location = new System.Drawing.Point(1, 70);
            this.March.Name = "March";
            this.March.Size = new System.Drawing.Size(486, 353);
            this.March.TabIndex = 231;
            // 
            // Mar
            // 
            this.Mar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Mar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Mar.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Mar.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Mar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Mar.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Mar.Location = new System.Drawing.Point(139, 0);
            this.Mar.Name = "Mar";
            this.Mar.Size = new System.Drawing.Size(208, 39);
            this.Mar.TabIndex = 156;
            this.Mar.TabStop = false;
            this.Mar.Text = "March";
            this.Mar.UseVisualStyleBackColor = false;
            this.Mar.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button7.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button7.FlatAppearance.BorderSize = 0;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(452, 4);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(30, 30);
            this.button7.TabIndex = 122;
            this.button7.TabStop = false;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button10.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(5, 4);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 30);
            this.button10.TabIndex = 121;
            this.button10.TabStop = false;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // heading3
            // 
            this.heading3.Location = new System.Drawing.Point(1, 1);
            this.heading3.Name = "heading3";
            this.heading3.Size = new System.Drawing.Size(484, 58);
            this.heading3.TabIndex = 139;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button86);
            this.panel3.Controls.Add(this.button110);
            this.panel3.Controls.Add(this.button87);
            this.panel3.Controls.Add(this.button107);
            this.panel3.Controls.Add(this.button88);
            this.panel3.Controls.Add(this.button111);
            this.panel3.Controls.Add(this.button89);
            this.panel3.Controls.Add(this.button112);
            this.panel3.Controls.Add(this.button90);
            this.panel3.Controls.Add(this.button108);
            this.panel3.Controls.Add(this.button91);
            this.panel3.Controls.Add(this.button113);
            this.panel3.Controls.Add(this.button92);
            this.panel3.Controls.Add(this.button103);
            this.panel3.Controls.Add(this.button93);
            this.panel3.Controls.Add(this.button109);
            this.panel3.Controls.Add(this.button94);
            this.panel3.Controls.Add(this.button100);
            this.panel3.Controls.Add(this.button95);
            this.panel3.Controls.Add(this.button104);
            this.panel3.Controls.Add(this.button96);
            this.panel3.Controls.Add(this.button105);
            this.panel3.Controls.Add(this.button97);
            this.panel3.Controls.Add(this.button101);
            this.panel3.Controls.Add(this.button98);
            this.panel3.Controls.Add(this.button99);
            this.panel3.Controls.Add(this.button106);
            this.panel3.Controls.Add(this.button54);
            this.panel3.Controls.Add(this.button102);
            this.panel3.Controls.Add(this.button84);
            this.panel3.Controls.Add(this.label92);
            this.panel3.Controls.Add(this.button85);
            this.panel3.Controls.Add(this.label93);
            this.panel3.Controls.Add(this.label94);
            this.panel3.Controls.Add(this.label96);
            this.panel3.Controls.Add(this.label98);
            this.panel3.Controls.Add(this.label100);
            this.panel3.Controls.Add(this.label102);
            this.panel3.Controls.Add(this.label104);
            this.panel3.Controls.Add(this.label113);
            this.panel3.Controls.Add(this.label115);
            this.panel3.Controls.Add(this.label132);
            this.panel3.Location = new System.Drawing.Point(1, 58);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(484, 295);
            this.panel3.TabIndex = 124;
            // 
            // button86
            // 
            this.button86.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button86.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button86.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button86.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button86.Location = new System.Drawing.Point(207, 98);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(70, 50);
            this.button86.TabIndex = 257;
            this.button86.TabStop = false;
            this.button86.Text = "14";
            this.button86.UseCompatibleTextRendering = true;
            this.button86.UseVisualStyleBackColor = true;
            // 
            // button110
            // 
            this.button110.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button110.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button110.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button110.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button110.Location = new System.Drawing.Point(207, 196);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(70, 50);
            this.button110.TabIndex = 261;
            this.button110.TabStop = false;
            this.button110.Text = "28";
            this.button110.UseCompatibleTextRendering = true;
            this.button110.UseVisualStyleBackColor = true;
            this.button110.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button87
            // 
            this.button87.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button87.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button87.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button87.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button87.Location = new System.Drawing.Point(414, 98);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(70, 50);
            this.button87.TabIndex = 256;
            this.button87.TabStop = false;
            this.button87.Text = "17";
            this.button87.UseCompatibleTextRendering = true;
            this.button87.UseVisualStyleBackColor = true;
            // 
            // button107
            // 
            this.button107.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button107.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button107.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button107.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button107.Location = new System.Drawing.Point(138, 196);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(70, 50);
            this.button107.TabIndex = 260;
            this.button107.TabStop = false;
            this.button107.Text = "27";
            this.button107.UseCompatibleTextRendering = true;
            this.button107.UseVisualStyleBackColor = true;
            this.button107.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button88
            // 
            this.button88.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button88.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button88.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button88.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button88.Location = new System.Drawing.Point(345, 98);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(70, 50);
            this.button88.TabIndex = 255;
            this.button88.TabStop = false;
            this.button88.Text = "16";
            this.button88.UseCompatibleTextRendering = true;
            this.button88.UseVisualStyleBackColor = true;
            // 
            // button111
            // 
            this.button111.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button111.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button111.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button111.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button111.Location = new System.Drawing.Point(414, 196);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(70, 50);
            this.button111.TabIndex = 260;
            this.button111.TabStop = false;
            this.button111.Text = "31";
            this.button111.UseCompatibleTextRendering = true;
            this.button111.UseVisualStyleBackColor = true;
            this.button111.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button89
            // 
            this.button89.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button89.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button89.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button89.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button89.Location = new System.Drawing.Point(276, 98);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(70, 50);
            this.button89.TabIndex = 254;
            this.button89.TabStop = false;
            this.button89.Text = "15";
            this.button89.UseCompatibleTextRendering = true;
            this.button89.UseVisualStyleBackColor = true;
            // 
            // button112
            // 
            this.button112.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button112.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button112.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button112.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button112.Location = new System.Drawing.Point(345, 196);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(70, 50);
            this.button112.TabIndex = 259;
            this.button112.TabStop = false;
            this.button112.Text = "30";
            this.button112.UseCompatibleTextRendering = true;
            this.button112.UseVisualStyleBackColor = true;
            this.button112.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button90
            // 
            this.button90.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button90.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button90.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button90.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button90.Location = new System.Drawing.Point(138, 98);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(70, 50);
            this.button90.TabIndex = 253;
            this.button90.TabStop = false;
            this.button90.Text = "13";
            this.button90.UseCompatibleTextRendering = true;
            this.button90.UseVisualStyleBackColor = true;
            // 
            // button108
            // 
            this.button108.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button108.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button108.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button108.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button108.Location = new System.Drawing.Point(69, 196);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(70, 50);
            this.button108.TabIndex = 259;
            this.button108.TabStop = false;
            this.button108.Text = "26";
            this.button108.UseCompatibleTextRendering = true;
            this.button108.UseVisualStyleBackColor = true;
            this.button108.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button91
            // 
            this.button91.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button91.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button91.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button91.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button91.Location = new System.Drawing.Point(69, 98);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(70, 50);
            this.button91.TabIndex = 252;
            this.button91.TabStop = false;
            this.button91.Text = "12";
            this.button91.UseCompatibleTextRendering = true;
            this.button91.UseVisualStyleBackColor = true;
            // 
            // button113
            // 
            this.button113.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button113.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button113.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button113.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button113.Location = new System.Drawing.Point(276, 196);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(70, 50);
            this.button113.TabIndex = 258;
            this.button113.TabStop = false;
            this.button113.Text = "29";
            this.button113.UseCompatibleTextRendering = true;
            this.button113.UseVisualStyleBackColor = true;
            this.button113.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button92
            // 
            this.button92.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button92.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button92.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button92.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button92.Location = new System.Drawing.Point(0, 98);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(70, 50);
            this.button92.TabIndex = 251;
            this.button92.TabStop = false;
            this.button92.Text = "11";
            this.button92.UseCompatibleTextRendering = true;
            this.button92.UseVisualStyleBackColor = true;
            // 
            // button103
            // 
            this.button103.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button103.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button103.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button103.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button103.Location = new System.Drawing.Point(207, 147);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(70, 50);
            this.button103.TabIndex = 261;
            this.button103.TabStop = false;
            this.button103.Text = "21";
            this.button103.UseCompatibleTextRendering = true;
            this.button103.UseVisualStyleBackColor = true;
            this.button103.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button93
            // 
            this.button93.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button93.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button93.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button93.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button93.Location = new System.Drawing.Point(207, 49);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(70, 50);
            this.button93.TabIndex = 250;
            this.button93.TabStop = false;
            this.button93.Text = "7";
            this.button93.UseCompatibleTextRendering = true;
            this.button93.UseVisualStyleBackColor = true;
            // 
            // button109
            // 
            this.button109.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button109.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button109.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button109.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button109.Location = new System.Drawing.Point(0, 196);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(70, 50);
            this.button109.TabIndex = 258;
            this.button109.TabStop = false;
            this.button109.Text = "25";
            this.button109.UseCompatibleTextRendering = true;
            this.button109.UseVisualStyleBackColor = true;
            this.button109.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button94
            // 
            this.button94.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button94.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button94.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button94.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button94.Location = new System.Drawing.Point(138, 49);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(70, 50);
            this.button94.TabIndex = 246;
            this.button94.TabStop = false;
            this.button94.Text = "6";
            this.button94.UseCompatibleTextRendering = true;
            this.button94.UseVisualStyleBackColor = true;
            // 
            // button100
            // 
            this.button100.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button100.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button100.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button100.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button100.Location = new System.Drawing.Point(138, 147);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(70, 50);
            this.button100.TabIndex = 260;
            this.button100.TabStop = false;
            this.button100.Text = "20";
            this.button100.UseCompatibleTextRendering = true;
            this.button100.UseVisualStyleBackColor = true;
            this.button100.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button95
            // 
            this.button95.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button95.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button95.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button95.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button95.Location = new System.Drawing.Point(414, 49);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(70, 50);
            this.button95.TabIndex = 249;
            this.button95.TabStop = false;
            this.button95.Text = "10";
            this.button95.UseCompatibleTextRendering = true;
            this.button95.UseVisualStyleBackColor = true;
            // 
            // button104
            // 
            this.button104.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button104.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button104.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button104.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button104.Location = new System.Drawing.Point(414, 147);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(70, 50);
            this.button104.TabIndex = 260;
            this.button104.TabStop = false;
            this.button104.Text = "24";
            this.button104.UseCompatibleTextRendering = true;
            this.button104.UseVisualStyleBackColor = true;
            this.button104.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button96
            // 
            this.button96.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button96.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button96.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button96.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button96.Location = new System.Drawing.Point(69, 49);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(70, 50);
            this.button96.TabIndex = 245;
            this.button96.TabStop = false;
            this.button96.Text = "5";
            this.button96.UseCompatibleTextRendering = true;
            this.button96.UseVisualStyleBackColor = true;
            // 
            // button105
            // 
            this.button105.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button105.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button105.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button105.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button105.Location = new System.Drawing.Point(345, 147);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(70, 50);
            this.button105.TabIndex = 259;
            this.button105.TabStop = false;
            this.button105.Text = "23";
            this.button105.UseCompatibleTextRendering = true;
            this.button105.UseVisualStyleBackColor = true;
            this.button105.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button97
            // 
            this.button97.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button97.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button97.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button97.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button97.Location = new System.Drawing.Point(345, 49);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(70, 50);
            this.button97.TabIndex = 248;
            this.button97.TabStop = false;
            this.button97.Text = "9";
            this.button97.UseCompatibleTextRendering = true;
            this.button97.UseVisualStyleBackColor = true;
            // 
            // button101
            // 
            this.button101.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button101.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button101.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button101.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button101.Location = new System.Drawing.Point(69, 147);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(70, 50);
            this.button101.TabIndex = 259;
            this.button101.TabStop = false;
            this.button101.Text = "19";
            this.button101.UseCompatibleTextRendering = true;
            this.button101.UseVisualStyleBackColor = true;
            this.button101.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button98
            // 
            this.button98.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button98.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button98.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button98.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button98.Location = new System.Drawing.Point(276, 49);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(70, 50);
            this.button98.TabIndex = 247;
            this.button98.TabStop = false;
            this.button98.Text = "8";
            this.button98.UseCompatibleTextRendering = true;
            this.button98.UseVisualStyleBackColor = true;
            // 
            // button99
            // 
            this.button99.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button99.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button99.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button99.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button99.Location = new System.Drawing.Point(0, 49);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(70, 50);
            this.button99.TabIndex = 244;
            this.button99.TabStop = false;
            this.button99.Text = "4";
            this.button99.UseCompatibleTextRendering = true;
            this.button99.UseVisualStyleBackColor = true;
            // 
            // button106
            // 
            this.button106.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button106.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button106.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button106.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button106.Location = new System.Drawing.Point(276, 147);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(70, 50);
            this.button106.TabIndex = 258;
            this.button106.TabStop = false;
            this.button106.Text = "22";
            this.button106.UseCompatibleTextRendering = true;
            this.button106.UseVisualStyleBackColor = true;
            this.button106.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button54
            // 
            this.button54.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button54.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button54.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button54.Location = new System.Drawing.Point(414, 0);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(70, 50);
            this.button54.TabIndex = 205;
            this.button54.TabStop = false;
            this.button54.Text = "3";
            this.button54.UseCompatibleTextRendering = true;
            this.button54.UseVisualStyleBackColor = true;
            this.button54.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button102
            // 
            this.button102.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button102.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button102.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button102.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button102.Location = new System.Drawing.Point(0, 147);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(70, 50);
            this.button102.TabIndex = 258;
            this.button102.TabStop = false;
            this.button102.Text = "18";
            this.button102.UseCompatibleTextRendering = true;
            this.button102.UseVisualStyleBackColor = true;
            this.button102.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button84
            // 
            this.button84.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button84.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button84.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button84.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button84.Location = new System.Drawing.Point(345, 0);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(70, 50);
            this.button84.TabIndex = 204;
            this.button84.TabStop = false;
            this.button84.Text = "2";
            this.button84.UseCompatibleTextRendering = true;
            this.button84.UseVisualStyleBackColor = true;
            this.button84.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label92
            // 
            this.label92.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label92.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label92.ForeColor = System.Drawing.Color.Gray;
            this.label92.Location = new System.Drawing.Point(207, 245);
            this.label92.Name = "label92";
            this.label92.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label92.Size = new System.Drawing.Size(70, 50);
            this.label92.TabIndex = 153;
            this.label92.Text = "4";
            this.label92.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button85
            // 
            this.button85.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button85.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button85.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button85.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button85.Location = new System.Drawing.Point(276, 0);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(70, 50);
            this.button85.TabIndex = 203;
            this.button85.TabStop = false;
            this.button85.Text = "1";
            this.button85.UseCompatibleTextRendering = true;
            this.button85.UseVisualStyleBackColor = true;
            this.button85.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label93
            // 
            this.label93.BackColor = System.Drawing.Color.Transparent;
            this.label93.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label93.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label93.ForeColor = System.Drawing.Color.Gray;
            this.label93.Location = new System.Drawing.Point(69, 0);
            this.label93.Name = "label93";
            this.label93.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label93.Size = new System.Drawing.Size(70, 50);
            this.label93.TabIndex = 142;
            this.label93.Text = "26";
            this.label93.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label94
            // 
            this.label94.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label94.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label94.ForeColor = System.Drawing.Color.Gray;
            this.label94.Location = new System.Drawing.Point(0, 245);
            this.label94.Name = "label94";
            this.label94.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label94.Size = new System.Drawing.Size(70, 50);
            this.label94.TabIndex = 152;
            this.label94.Text = "1";
            this.label94.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label96
            // 
            this.label96.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label96.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label96.ForeColor = System.Drawing.Color.Gray;
            this.label96.Location = new System.Drawing.Point(69, 245);
            this.label96.Name = "label96";
            this.label96.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label96.Size = new System.Drawing.Size(70, 50);
            this.label96.TabIndex = 151;
            this.label96.Text = "2";
            this.label96.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label98
            // 
            this.label98.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label98.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label98.ForeColor = System.Drawing.Color.Gray;
            this.label98.Location = new System.Drawing.Point(138, 245);
            this.label98.Name = "label98";
            this.label98.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label98.Size = new System.Drawing.Size(70, 50);
            this.label98.TabIndex = 150;
            this.label98.Text = "3";
            this.label98.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label100
            // 
            this.label100.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label100.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label100.ForeColor = System.Drawing.Color.Gray;
            this.label100.Location = new System.Drawing.Point(345, 245);
            this.label100.Name = "label100";
            this.label100.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label100.Size = new System.Drawing.Size(70, 50);
            this.label100.TabIndex = 148;
            this.label100.Text = "6";
            this.label100.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label102
            // 
            this.label102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label102.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label102.ForeColor = System.Drawing.Color.Gray;
            this.label102.Location = new System.Drawing.Point(276, 245);
            this.label102.Name = "label102";
            this.label102.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label102.Size = new System.Drawing.Size(70, 50);
            this.label102.TabIndex = 147;
            this.label102.Text = "5";
            this.label102.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label104
            // 
            this.label104.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label104.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label104.ForeColor = System.Drawing.Color.Gray;
            this.label104.Location = new System.Drawing.Point(414, 245);
            this.label104.Name = "label104";
            this.label104.Size = new System.Drawing.Size(70, 50);
            this.label104.TabIndex = 149;
            this.label104.Text = "7";
            this.label104.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label113
            // 
            this.label113.BackColor = System.Drawing.Color.Transparent;
            this.label113.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label113.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label113.ForeColor = System.Drawing.Color.Gray;
            this.label113.Location = new System.Drawing.Point(138, 0);
            this.label113.Name = "label113";
            this.label113.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label113.Size = new System.Drawing.Size(70, 50);
            this.label113.TabIndex = 141;
            this.label113.Text = "27";
            this.label113.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label115
            // 
            this.label115.BackColor = System.Drawing.Color.Transparent;
            this.label115.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label115.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label115.ForeColor = System.Drawing.Color.Gray;
            this.label115.Location = new System.Drawing.Point(207, 0);
            this.label115.Name = "label115";
            this.label115.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label115.Size = new System.Drawing.Size(70, 50);
            this.label115.TabIndex = 140;
            this.label115.Text = "28";
            this.label115.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label132
            // 
            this.label132.BackColor = System.Drawing.Color.Transparent;
            this.label132.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label132.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label132.ForeColor = System.Drawing.Color.Gray;
            this.label132.Location = new System.Drawing.Point(0, 0);
            this.label132.Name = "label132";
            this.label132.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label132.Size = new System.Drawing.Size(70, 50);
            this.label132.TabIndex = 143;
            this.label132.Text = "25";
            this.label132.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // April
            // 
            this.April.Controls.Add(this.Apr);
            this.April.Controls.Add(this.panel4);
            this.April.Controls.Add(this.button12);
            this.April.Controls.Add(this.button15);
            this.April.Controls.Add(this.heading4);
            this.April.Location = new System.Drawing.Point(1, 70);
            this.April.Name = "April";
            this.April.Size = new System.Drawing.Size(486, 353);
            this.April.TabIndex = 232;
            // 
            // Apr
            // 
            this.Apr.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Apr.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Apr.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Apr.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Apr.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Apr.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Apr.Location = new System.Drawing.Point(139, 0);
            this.Apr.Name = "Apr";
            this.Apr.Size = new System.Drawing.Size(208, 39);
            this.Apr.TabIndex = 157;
            this.Apr.TabStop = false;
            this.Apr.Text = "April";
            this.Apr.UseVisualStyleBackColor = false;
            this.Apr.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.button172);
            this.panel4.Controls.Add(this.button173);
            this.panel4.Controls.Add(this.button171);
            this.panel4.Controls.Add(this.button165);
            this.panel4.Controls.Add(this.button166);
            this.panel4.Controls.Add(this.button167);
            this.panel4.Controls.Add(this.button168);
            this.panel4.Controls.Add(this.button169);
            this.panel4.Controls.Add(this.button170);
            this.panel4.Controls.Add(this.button164);
            this.panel4.Controls.Add(this.button161);
            this.panel4.Controls.Add(this.button162);
            this.panel4.Controls.Add(this.button158);
            this.panel4.Controls.Add(this.button163);
            this.panel4.Controls.Add(this.button159);
            this.panel4.Controls.Add(this.button154);
            this.panel4.Controls.Add(this.button160);
            this.panel4.Controls.Add(this.button155);
            this.panel4.Controls.Add(this.button151);
            this.panel4.Controls.Add(this.button156);
            this.panel4.Controls.Add(this.button147);
            this.panel4.Controls.Add(this.button157);
            this.panel4.Controls.Add(this.button152);
            this.panel4.Controls.Add(this.button153);
            this.panel4.Controls.Add(this.button148);
            this.panel4.Controls.Add(this.button144);
            this.panel4.Controls.Add(this.button149);
            this.panel4.Controls.Add(this.button145);
            this.panel4.Controls.Add(this.button150);
            this.panel4.Controls.Add(this.label89);
            this.panel4.Controls.Add(this.button146);
            this.panel4.Controls.Add(this.label136);
            this.panel4.Controls.Add(this.label139);
            this.panel4.Controls.Add(this.label141);
            this.panel4.Controls.Add(this.label143);
            this.panel4.Controls.Add(this.label145);
            this.panel4.Controls.Add(this.label147);
            this.panel4.Controls.Add(this.label149);
            this.panel4.Controls.Add(this.label151);
            this.panel4.Controls.Add(this.label154);
            this.panel4.Controls.Add(this.label162);
            this.panel4.Controls.Add(this.label164);
            this.panel4.Location = new System.Drawing.Point(1, 58);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(484, 295);
            this.panel4.TabIndex = 124;
            // 
            // button172
            // 
            this.button172.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button172.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button172.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button172.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button172.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button172.Location = new System.Drawing.Point(69, 196);
            this.button172.Name = "button172";
            this.button172.Size = new System.Drawing.Size(70, 50);
            this.button172.TabIndex = 255;
            this.button172.TabStop = false;
            this.button172.Text = "30";
            this.button172.UseCompatibleTextRendering = true;
            this.button172.UseVisualStyleBackColor = true;
            // 
            // button173
            // 
            this.button173.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button173.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button173.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button173.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button173.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button173.Location = new System.Drawing.Point(0, 196);
            this.button173.Name = "button173";
            this.button173.Size = new System.Drawing.Size(70, 50);
            this.button173.TabIndex = 254;
            this.button173.TabStop = false;
            this.button173.Text = "29";
            this.button173.UseCompatibleTextRendering = true;
            this.button173.UseVisualStyleBackColor = true;
            // 
            // button171
            // 
            this.button171.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button171.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button171.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button171.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button171.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button171.Location = new System.Drawing.Point(414, 147);
            this.button171.Name = "button171";
            this.button171.Size = new System.Drawing.Size(70, 50);
            this.button171.TabIndex = 244;
            this.button171.TabStop = false;
            this.button171.Text = "28";
            this.button171.UseCompatibleTextRendering = true;
            this.button171.UseVisualStyleBackColor = true;
            // 
            // button165
            // 
            this.button165.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button165.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button165.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button165.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button165.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button165.Location = new System.Drawing.Point(345, 147);
            this.button165.Name = "button165";
            this.button165.Size = new System.Drawing.Size(70, 50);
            this.button165.TabIndex = 253;
            this.button165.TabStop = false;
            this.button165.Text = "27";
            this.button165.UseCompatibleTextRendering = true;
            this.button165.UseVisualStyleBackColor = true;
            // 
            // button166
            // 
            this.button166.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button166.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button166.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button166.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button166.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button166.Location = new System.Drawing.Point(276, 147);
            this.button166.Name = "button166";
            this.button166.Size = new System.Drawing.Size(70, 50);
            this.button166.TabIndex = 252;
            this.button166.TabStop = false;
            this.button166.Text = "26";
            this.button166.UseCompatibleTextRendering = true;
            this.button166.UseVisualStyleBackColor = true;
            // 
            // button167
            // 
            this.button167.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button167.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button167.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button167.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button167.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button167.Location = new System.Drawing.Point(207, 147);
            this.button167.Name = "button167";
            this.button167.Size = new System.Drawing.Size(70, 50);
            this.button167.TabIndex = 251;
            this.button167.TabStop = false;
            this.button167.Text = "25";
            this.button167.UseCompatibleTextRendering = true;
            this.button167.UseVisualStyleBackColor = true;
            // 
            // button168
            // 
            this.button168.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button168.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button168.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button168.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button168.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button168.Location = new System.Drawing.Point(138, 147);
            this.button168.Name = "button168";
            this.button168.Size = new System.Drawing.Size(70, 50);
            this.button168.TabIndex = 250;
            this.button168.TabStop = false;
            this.button168.Text = "24";
            this.button168.UseCompatibleTextRendering = true;
            this.button168.UseVisualStyleBackColor = true;
            // 
            // button169
            // 
            this.button169.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button169.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button169.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button169.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button169.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button169.Location = new System.Drawing.Point(69, 147);
            this.button169.Name = "button169";
            this.button169.Size = new System.Drawing.Size(70, 50);
            this.button169.TabIndex = 249;
            this.button169.TabStop = false;
            this.button169.Text = "23";
            this.button169.UseCompatibleTextRendering = true;
            this.button169.UseVisualStyleBackColor = true;
            // 
            // button170
            // 
            this.button170.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button170.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button170.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button170.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button170.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button170.Location = new System.Drawing.Point(0, 147);
            this.button170.Name = "button170";
            this.button170.Size = new System.Drawing.Size(70, 50);
            this.button170.TabIndex = 248;
            this.button170.TabStop = false;
            this.button170.Text = "22";
            this.button170.UseCompatibleTextRendering = true;
            this.button170.UseVisualStyleBackColor = true;
            // 
            // button164
            // 
            this.button164.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button164.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button164.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button164.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button164.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button164.Location = new System.Drawing.Point(414, 98);
            this.button164.Name = "button164";
            this.button164.Size = new System.Drawing.Size(70, 50);
            this.button164.TabIndex = 196;
            this.button164.TabStop = false;
            this.button164.Text = "21";
            this.button164.UseCompatibleTextRendering = true;
            this.button164.UseVisualStyleBackColor = true;
            // 
            // button161
            // 
            this.button161.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button161.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button161.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button161.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button161.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button161.Location = new System.Drawing.Point(345, 98);
            this.button161.Name = "button161";
            this.button161.Size = new System.Drawing.Size(70, 50);
            this.button161.TabIndex = 246;
            this.button161.TabStop = false;
            this.button161.Text = "20";
            this.button161.UseCompatibleTextRendering = true;
            this.button161.UseVisualStyleBackColor = true;
            // 
            // button162
            // 
            this.button162.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button162.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button162.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button162.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button162.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button162.Location = new System.Drawing.Point(276, 98);
            this.button162.Name = "button162";
            this.button162.Size = new System.Drawing.Size(70, 50);
            this.button162.TabIndex = 245;
            this.button162.TabStop = false;
            this.button162.Text = "19";
            this.button162.UseCompatibleTextRendering = true;
            this.button162.UseVisualStyleBackColor = true;
            // 
            // button158
            // 
            this.button158.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button158.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button158.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button158.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button158.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button158.Location = new System.Drawing.Point(138, 98);
            this.button158.Name = "button158";
            this.button158.Size = new System.Drawing.Size(70, 50);
            this.button158.TabIndex = 246;
            this.button158.TabStop = false;
            this.button158.Text = "17";
            this.button158.UseCompatibleTextRendering = true;
            this.button158.UseVisualStyleBackColor = true;
            // 
            // button163
            // 
            this.button163.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button163.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button163.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button163.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button163.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button163.Location = new System.Drawing.Point(207, 98);
            this.button163.Name = "button163";
            this.button163.Size = new System.Drawing.Size(70, 50);
            this.button163.TabIndex = 244;
            this.button163.TabStop = false;
            this.button163.Text = "18";
            this.button163.UseCompatibleTextRendering = true;
            this.button163.UseVisualStyleBackColor = true;
            // 
            // button159
            // 
            this.button159.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button159.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button159.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button159.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button159.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button159.Location = new System.Drawing.Point(69, 98);
            this.button159.Name = "button159";
            this.button159.Size = new System.Drawing.Size(70, 50);
            this.button159.TabIndex = 245;
            this.button159.TabStop = false;
            this.button159.Text = "16";
            this.button159.UseCompatibleTextRendering = true;
            this.button159.UseVisualStyleBackColor = true;
            // 
            // button154
            // 
            this.button154.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button154.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button154.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button154.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button154.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button154.Location = new System.Drawing.Point(414, 49);
            this.button154.Name = "button154";
            this.button154.Size = new System.Drawing.Size(70, 50);
            this.button154.TabIndex = 220;
            this.button154.TabStop = false;
            this.button154.Text = "14";
            this.button154.UseCompatibleTextRendering = true;
            this.button154.UseVisualStyleBackColor = true;
            // 
            // button160
            // 
            this.button160.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button160.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button160.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button160.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button160.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button160.Location = new System.Drawing.Point(0, 98);
            this.button160.Name = "button160";
            this.button160.Size = new System.Drawing.Size(70, 50);
            this.button160.TabIndex = 244;
            this.button160.TabStop = false;
            this.button160.Text = "15";
            this.button160.UseCompatibleTextRendering = true;
            this.button160.UseVisualStyleBackColor = true;
            // 
            // button155
            // 
            this.button155.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button155.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button155.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button155.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button155.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button155.Location = new System.Drawing.Point(345, 49);
            this.button155.Name = "button155";
            this.button155.Size = new System.Drawing.Size(70, 50);
            this.button155.TabIndex = 219;
            this.button155.TabStop = false;
            this.button155.Text = "13";
            this.button155.UseCompatibleTextRendering = true;
            this.button155.UseVisualStyleBackColor = true;
            // 
            // button151
            // 
            this.button151.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button151.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button151.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button151.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button151.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button151.Location = new System.Drawing.Point(138, 49);
            this.button151.Name = "button151";
            this.button151.Size = new System.Drawing.Size(70, 50);
            this.button151.TabIndex = 246;
            this.button151.TabStop = false;
            this.button151.Text = "10";
            this.button151.UseCompatibleTextRendering = true;
            this.button151.UseVisualStyleBackColor = true;
            // 
            // button156
            // 
            this.button156.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button156.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button156.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button156.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button156.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button156.Location = new System.Drawing.Point(276, 49);
            this.button156.Name = "button156";
            this.button156.Size = new System.Drawing.Size(70, 50);
            this.button156.TabIndex = 218;
            this.button156.TabStop = false;
            this.button156.Text = "12";
            this.button156.UseCompatibleTextRendering = true;
            this.button156.UseVisualStyleBackColor = true;
            // 
            // button147
            // 
            this.button147.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button147.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button147.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button147.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button147.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button147.Location = new System.Drawing.Point(414, 0);
            this.button147.Name = "button147";
            this.button147.Size = new System.Drawing.Size(70, 50);
            this.button147.TabIndex = 247;
            this.button147.TabStop = false;
            this.button147.Text = "7";
            this.button147.UseCompatibleTextRendering = true;
            this.button147.UseVisualStyleBackColor = true;
            // 
            // button157
            // 
            this.button157.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button157.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button157.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button157.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button157.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button157.Location = new System.Drawing.Point(207, 49);
            this.button157.Name = "button157";
            this.button157.Size = new System.Drawing.Size(70, 50);
            this.button157.TabIndex = 217;
            this.button157.TabStop = false;
            this.button157.Text = "11";
            this.button157.UseCompatibleTextRendering = true;
            this.button157.UseVisualStyleBackColor = true;
            // 
            // button152
            // 
            this.button152.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button152.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button152.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button152.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button152.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button152.Location = new System.Drawing.Point(69, 49);
            this.button152.Name = "button152";
            this.button152.Size = new System.Drawing.Size(70, 50);
            this.button152.TabIndex = 245;
            this.button152.TabStop = false;
            this.button152.Text = "9";
            this.button152.UseCompatibleTextRendering = true;
            this.button152.UseVisualStyleBackColor = true;
            // 
            // button153
            // 
            this.button153.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button153.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button153.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button153.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button153.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button153.Location = new System.Drawing.Point(0, 49);
            this.button153.Name = "button153";
            this.button153.Size = new System.Drawing.Size(70, 50);
            this.button153.TabIndex = 244;
            this.button153.TabStop = false;
            this.button153.Text = "8";
            this.button153.UseCompatibleTextRendering = true;
            this.button153.UseVisualStyleBackColor = true;
            // 
            // button148
            // 
            this.button148.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button148.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button148.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button148.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button148.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button148.Location = new System.Drawing.Point(345, 0);
            this.button148.Name = "button148";
            this.button148.Size = new System.Drawing.Size(70, 50);
            this.button148.TabIndex = 246;
            this.button148.TabStop = false;
            this.button148.Text = "6";
            this.button148.UseCompatibleTextRendering = true;
            this.button148.UseVisualStyleBackColor = true;
            // 
            // button144
            // 
            this.button144.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button144.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button144.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button144.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button144.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button144.Location = new System.Drawing.Point(138, 0);
            this.button144.Name = "button144";
            this.button144.Size = new System.Drawing.Size(70, 50);
            this.button144.TabIndex = 205;
            this.button144.TabStop = false;
            this.button144.Text = "3";
            this.button144.UseCompatibleTextRendering = true;
            this.button144.UseVisualStyleBackColor = true;
            // 
            // button149
            // 
            this.button149.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button149.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button149.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button149.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button149.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button149.Location = new System.Drawing.Point(276, 0);
            this.button149.Name = "button149";
            this.button149.Size = new System.Drawing.Size(70, 50);
            this.button149.TabIndex = 245;
            this.button149.TabStop = false;
            this.button149.Text = "5";
            this.button149.UseCompatibleTextRendering = true;
            this.button149.UseVisualStyleBackColor = true;
            // 
            // button145
            // 
            this.button145.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button145.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button145.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button145.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button145.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button145.Location = new System.Drawing.Point(69, 0);
            this.button145.Name = "button145";
            this.button145.Size = new System.Drawing.Size(70, 50);
            this.button145.TabIndex = 204;
            this.button145.TabStop = false;
            this.button145.Text = "2";
            this.button145.UseCompatibleTextRendering = true;
            this.button145.UseVisualStyleBackColor = true;
            // 
            // button150
            // 
            this.button150.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button150.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button150.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button150.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button150.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button150.Location = new System.Drawing.Point(207, 0);
            this.button150.Name = "button150";
            this.button150.Size = new System.Drawing.Size(70, 50);
            this.button150.TabIndex = 244;
            this.button150.TabStop = false;
            this.button150.Text = "4";
            this.button150.UseCompatibleTextRendering = true;
            this.button150.UseVisualStyleBackColor = true;
            // 
            // label89
            // 
            this.label89.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label89.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label89.ForeColor = System.Drawing.Color.Gray;
            this.label89.Location = new System.Drawing.Point(276, 196);
            this.label89.Name = "label89";
            this.label89.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label89.Size = new System.Drawing.Size(70, 50);
            this.label89.TabIndex = 154;
            this.label89.Text = "3";
            this.label89.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button146
            // 
            this.button146.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button146.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button146.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button146.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button146.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button146.Location = new System.Drawing.Point(0, 0);
            this.button146.Name = "button146";
            this.button146.Size = new System.Drawing.Size(70, 50);
            this.button146.TabIndex = 203;
            this.button146.TabStop = false;
            this.button146.Text = "1";
            this.button146.UseCompatibleTextRendering = true;
            this.button146.UseVisualStyleBackColor = true;
            // 
            // label136
            // 
            this.label136.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label136.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label136.ForeColor = System.Drawing.Color.Gray;
            this.label136.Location = new System.Drawing.Point(207, 245);
            this.label136.Name = "label136";
            this.label136.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label136.Size = new System.Drawing.Size(70, 50);
            this.label136.TabIndex = 153;
            this.label136.Text = "9";
            this.label136.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label139
            // 
            this.label139.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label139.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label139.ForeColor = System.Drawing.Color.Gray;
            this.label139.Location = new System.Drawing.Point(0, 245);
            this.label139.Name = "label139";
            this.label139.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label139.Size = new System.Drawing.Size(70, 50);
            this.label139.TabIndex = 152;
            this.label139.Text = "6";
            this.label139.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label141
            // 
            this.label141.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label141.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label141.ForeColor = System.Drawing.Color.Gray;
            this.label141.Location = new System.Drawing.Point(69, 245);
            this.label141.Name = "label141";
            this.label141.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label141.Size = new System.Drawing.Size(70, 50);
            this.label141.TabIndex = 151;
            this.label141.Text = "7";
            this.label141.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label143
            // 
            this.label143.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label143.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label143.ForeColor = System.Drawing.Color.Gray;
            this.label143.Location = new System.Drawing.Point(138, 245);
            this.label143.Name = "label143";
            this.label143.Size = new System.Drawing.Size(70, 50);
            this.label143.TabIndex = 150;
            this.label143.Text = "8";
            this.label143.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label145
            // 
            this.label145.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label145.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label145.ForeColor = System.Drawing.Color.Gray;
            this.label145.Location = new System.Drawing.Point(345, 245);
            this.label145.Name = "label145";
            this.label145.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label145.Size = new System.Drawing.Size(70, 50);
            this.label145.TabIndex = 148;
            this.label145.Text = "11";
            this.label145.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label147
            // 
            this.label147.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label147.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label147.ForeColor = System.Drawing.Color.Gray;
            this.label147.Location = new System.Drawing.Point(276, 245);
            this.label147.Name = "label147";
            this.label147.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label147.Size = new System.Drawing.Size(70, 50);
            this.label147.TabIndex = 147;
            this.label147.Text = "10";
            this.label147.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label149
            // 
            this.label149.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label149.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label149.ForeColor = System.Drawing.Color.Gray;
            this.label149.Location = new System.Drawing.Point(414, 245);
            this.label149.Name = "label149";
            this.label149.Size = new System.Drawing.Size(70, 50);
            this.label149.TabIndex = 149;
            this.label149.Text = "12";
            this.label149.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label151
            // 
            this.label151.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label151.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label151.ForeColor = System.Drawing.Color.Gray;
            this.label151.Location = new System.Drawing.Point(345, 196);
            this.label151.Name = "label151";
            this.label151.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label151.Size = new System.Drawing.Size(70, 50);
            this.label151.TabIndex = 145;
            this.label151.Text = "4";
            this.label151.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label154
            // 
            this.label154.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label154.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label154.ForeColor = System.Drawing.Color.Gray;
            this.label154.Location = new System.Drawing.Point(414, 196);
            this.label154.Name = "label154";
            this.label154.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label154.Size = new System.Drawing.Size(70, 50);
            this.label154.TabIndex = 146;
            this.label154.Text = "5";
            this.label154.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label162
            // 
            this.label162.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label162.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label162.ForeColor = System.Drawing.Color.Gray;
            this.label162.Location = new System.Drawing.Point(207, 196);
            this.label162.Name = "label162";
            this.label162.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label162.Size = new System.Drawing.Size(70, 50);
            this.label162.TabIndex = 112;
            this.label162.Text = "2";
            this.label162.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label164
            // 
            this.label164.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label164.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label164.ForeColor = System.Drawing.Color.Gray;
            this.label164.Location = new System.Drawing.Point(138, 196);
            this.label164.Name = "label164";
            this.label164.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label164.Size = new System.Drawing.Size(70, 50);
            this.label164.TabIndex = 139;
            this.label164.Text = "1";
            this.label164.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button12.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderSize = 0;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button12.Location = new System.Drawing.Point(452, 4);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(30, 30);
            this.button12.TabIndex = 122;
            this.button12.TabStop = false;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button15.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button15.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button15.FlatAppearance.BorderSize = 0;
            this.button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button15.Location = new System.Drawing.Point(5, 4);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(30, 30);
            this.button15.TabIndex = 121;
            this.button15.TabStop = false;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // heading4
            // 
            this.heading4.Location = new System.Drawing.Point(1, 1);
            this.heading4.Name = "heading4";
            this.heading4.Size = new System.Drawing.Size(484, 58);
            this.heading4.TabIndex = 119;
            // 
            // May
            // 
            this.May.Controls.Add(this.Ma);
            this.May.Controls.Add(this.panel5);
            this.May.Controls.Add(this.label224);
            this.May.Controls.Add(this.button17);
            this.May.Controls.Add(this.button20);
            this.May.Controls.Add(this.heading5);
            this.May.Location = new System.Drawing.Point(1, 70);
            this.May.Name = "May";
            this.May.Size = new System.Drawing.Size(486, 353);
            this.May.TabIndex = 233;
            // 
            // Ma
            // 
            this.Ma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Ma.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Ma.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Ma.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Ma.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Ma.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Ma.Location = new System.Drawing.Point(139, 0);
            this.Ma.Name = "Ma";
            this.Ma.Size = new System.Drawing.Size(208, 39);
            this.Ma.TabIndex = 158;
            this.Ma.TabStop = false;
            this.Ma.Text = "May";
            this.Ma.UseVisualStyleBackColor = false;
            this.Ma.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.button139);
            this.panel5.Controls.Add(this.button138);
            this.panel5.Controls.Add(this.button140);
            this.panel5.Controls.Add(this.button141);
            this.panel5.Controls.Add(this.button132);
            this.panel5.Controls.Add(this.button142);
            this.panel5.Controls.Add(this.button131);
            this.panel5.Controls.Add(this.button133);
            this.panel5.Controls.Add(this.button129);
            this.panel5.Controls.Add(this.button134);
            this.panel5.Controls.Add(this.button135);
            this.panel5.Controls.Add(this.button130);
            this.panel5.Controls.Add(this.button136);
            this.panel5.Controls.Add(this.button124);
            this.panel5.Controls.Add(this.button137);
            this.panel5.Controls.Add(this.button125);
            this.panel5.Controls.Add(this.button126);
            this.panel5.Controls.Add(this.button127);
            this.panel5.Controls.Add(this.button128);
            this.panel5.Controls.Add(this.button122);
            this.panel5.Controls.Add(this.button123);
            this.panel5.Controls.Add(this.button117);
            this.panel5.Controls.Add(this.button115);
            this.panel5.Controls.Add(this.button118);
            this.panel5.Controls.Add(this.button116);
            this.panel5.Controls.Add(this.button119);
            this.panel5.Controls.Add(this.button8);
            this.panel5.Controls.Add(this.button120);
            this.panel5.Controls.Add(this.button121);
            this.panel5.Controls.Add(this.button9);
            this.panel5.Controls.Add(this.button114);
            this.panel5.Controls.Add(this.label183);
            this.panel5.Controls.Add(this.label184);
            this.panel5.Controls.Add(this.label185);
            this.panel5.Controls.Add(this.label187);
            this.panel5.Controls.Add(this.label189);
            this.panel5.Controls.Add(this.label191);
            this.panel5.Controls.Add(this.label193);
            this.panel5.Controls.Add(this.label195);
            this.panel5.Controls.Add(this.label197);
            this.panel5.Controls.Add(this.label200);
            this.panel5.Controls.Add(this.label223);
            this.panel5.Location = new System.Drawing.Point(1, 58);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(484, 295);
            this.panel5.TabIndex = 124;
            // 
            // button139
            // 
            this.button139.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button139.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button139.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button139.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button139.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button139.Location = new System.Drawing.Point(69, 196);
            this.button139.Name = "button139";
            this.button139.Size = new System.Drawing.Size(70, 50);
            this.button139.TabIndex = 247;
            this.button139.TabStop = false;
            this.button139.Text = "28";
            this.button139.UseCompatibleTextRendering = true;
            this.button139.UseVisualStyleBackColor = true;
            this.button139.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button138
            // 
            this.button138.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button138.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button138.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button138.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button138.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button138.Location = new System.Drawing.Point(0, 196);
            this.button138.Name = "button138";
            this.button138.Size = new System.Drawing.Size(70, 50);
            this.button138.TabIndex = 244;
            this.button138.TabStop = false;
            this.button138.Text = "27";
            this.button138.UseCompatibleTextRendering = true;
            this.button138.UseVisualStyleBackColor = true;
            this.button138.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button140
            // 
            this.button140.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button140.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button140.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button140.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button140.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button140.Location = new System.Drawing.Point(276, 196);
            this.button140.Name = "button140";
            this.button140.Size = new System.Drawing.Size(70, 50);
            this.button140.TabIndex = 246;
            this.button140.TabStop = false;
            this.button140.Text = "31";
            this.button140.UseCompatibleTextRendering = true;
            this.button140.UseVisualStyleBackColor = true;
            this.button140.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button141
            // 
            this.button141.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button141.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button141.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button141.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button141.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button141.Location = new System.Drawing.Point(207, 196);
            this.button141.Name = "button141";
            this.button141.Size = new System.Drawing.Size(70, 50);
            this.button141.TabIndex = 245;
            this.button141.TabStop = false;
            this.button141.Text = "30";
            this.button141.UseCompatibleTextRendering = true;
            this.button141.UseVisualStyleBackColor = true;
            this.button141.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button132
            // 
            this.button132.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button132.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button132.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button132.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button132.Location = new System.Drawing.Point(69, 147);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(70, 50);
            this.button132.TabIndex = 249;
            this.button132.TabStop = false;
            this.button132.Text = "21";
            this.button132.UseCompatibleTextRendering = true;
            this.button132.UseVisualStyleBackColor = true;
            this.button132.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button142
            // 
            this.button142.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button142.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button142.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button142.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button142.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button142.Location = new System.Drawing.Point(138, 196);
            this.button142.Name = "button142";
            this.button142.Size = new System.Drawing.Size(70, 50);
            this.button142.TabIndex = 244;
            this.button142.TabStop = false;
            this.button142.Text = "29";
            this.button142.UseCompatibleTextRendering = true;
            this.button142.UseVisualStyleBackColor = true;
            this.button142.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button131
            // 
            this.button131.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button131.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button131.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button131.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button131.Location = new System.Drawing.Point(0, 147);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(70, 50);
            this.button131.TabIndex = 244;
            this.button131.TabStop = false;
            this.button131.Text = "20";
            this.button131.UseCompatibleTextRendering = true;
            this.button131.UseVisualStyleBackColor = true;
            this.button131.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button133
            // 
            this.button133.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button133.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button133.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button133.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button133.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button133.Location = new System.Drawing.Point(414, 147);
            this.button133.Name = "button133";
            this.button133.Size = new System.Drawing.Size(70, 50);
            this.button133.TabIndex = 248;
            this.button133.TabStop = false;
            this.button133.Text = "26";
            this.button133.UseCompatibleTextRendering = true;
            this.button133.UseVisualStyleBackColor = true;
            this.button133.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button129
            // 
            this.button129.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button129.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button129.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button129.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button129.Location = new System.Drawing.Point(414, 98);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(70, 50);
            this.button129.TabIndex = 257;
            this.button129.TabStop = false;
            this.button129.Text = "19";
            this.button129.UseCompatibleTextRendering = true;
            this.button129.UseVisualStyleBackColor = true;
            this.button129.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button134
            // 
            this.button134.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button134.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button134.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button134.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button134.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button134.Location = new System.Drawing.Point(345, 147);
            this.button134.Name = "button134";
            this.button134.Size = new System.Drawing.Size(70, 50);
            this.button134.TabIndex = 247;
            this.button134.TabStop = false;
            this.button134.Text = "25";
            this.button134.UseCompatibleTextRendering = true;
            this.button134.UseVisualStyleBackColor = true;
            this.button134.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button135
            // 
            this.button135.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button135.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button135.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button135.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button135.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button135.Location = new System.Drawing.Point(276, 147);
            this.button135.Name = "button135";
            this.button135.Size = new System.Drawing.Size(70, 50);
            this.button135.TabIndex = 246;
            this.button135.TabStop = false;
            this.button135.Text = "24";
            this.button135.UseCompatibleTextRendering = true;
            this.button135.UseVisualStyleBackColor = true;
            this.button135.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button130
            // 
            this.button130.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button130.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button130.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button130.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button130.Location = new System.Drawing.Point(345, 98);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(70, 50);
            this.button130.TabIndex = 256;
            this.button130.TabStop = false;
            this.button130.Text = "18";
            this.button130.UseCompatibleTextRendering = true;
            this.button130.UseVisualStyleBackColor = true;
            this.button130.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button136
            // 
            this.button136.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button136.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button136.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button136.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button136.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button136.Location = new System.Drawing.Point(207, 147);
            this.button136.Name = "button136";
            this.button136.Size = new System.Drawing.Size(70, 50);
            this.button136.TabIndex = 245;
            this.button136.TabStop = false;
            this.button136.Text = "23";
            this.button136.UseCompatibleTextRendering = true;
            this.button136.UseVisualStyleBackColor = true;
            this.button136.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button124
            // 
            this.button124.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button124.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button124.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button124.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button124.Location = new System.Drawing.Point(69, 98);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(70, 50);
            this.button124.TabIndex = 255;
            this.button124.TabStop = false;
            this.button124.Text = "14";
            this.button124.UseCompatibleTextRendering = true;
            this.button124.UseVisualStyleBackColor = true;
            this.button124.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button137
            // 
            this.button137.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button137.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button137.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button137.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button137.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button137.Location = new System.Drawing.Point(138, 147);
            this.button137.Name = "button137";
            this.button137.Size = new System.Drawing.Size(70, 50);
            this.button137.TabIndex = 244;
            this.button137.TabStop = false;
            this.button137.Text = "22";
            this.button137.UseCompatibleTextRendering = true;
            this.button137.UseVisualStyleBackColor = true;
            this.button137.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button125
            // 
            this.button125.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button125.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button125.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button125.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button125.Location = new System.Drawing.Point(276, 98);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(70, 50);
            this.button125.TabIndex = 254;
            this.button125.TabStop = false;
            this.button125.Text = "17";
            this.button125.UseCompatibleTextRendering = true;
            this.button125.UseVisualStyleBackColor = true;
            this.button125.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button126
            // 
            this.button126.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button126.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button126.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button126.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button126.Location = new System.Drawing.Point(207, 98);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(70, 50);
            this.button126.TabIndex = 253;
            this.button126.TabStop = false;
            this.button126.Text = "16";
            this.button126.UseCompatibleTextRendering = true;
            this.button126.UseVisualStyleBackColor = true;
            this.button126.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button127
            // 
            this.button127.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button127.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button127.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button127.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button127.Location = new System.Drawing.Point(138, 98);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(70, 50);
            this.button127.TabIndex = 252;
            this.button127.TabStop = false;
            this.button127.Text = "15";
            this.button127.UseCompatibleTextRendering = true;
            this.button127.UseVisualStyleBackColor = true;
            this.button127.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button128
            // 
            this.button128.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button128.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button128.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button128.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button128.Location = new System.Drawing.Point(0, 98);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(70, 50);
            this.button128.TabIndex = 251;
            this.button128.TabStop = false;
            this.button128.Text = "13";
            this.button128.UseCompatibleTextRendering = true;
            this.button128.UseVisualStyleBackColor = true;
            this.button128.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button122
            // 
            this.button122.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button122.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button122.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button122.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button122.Location = new System.Drawing.Point(414, 49);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(70, 50);
            this.button122.TabIndex = 250;
            this.button122.TabStop = false;
            this.button122.Text = "12";
            this.button122.UseCompatibleTextRendering = true;
            this.button122.UseVisualStyleBackColor = true;
            this.button122.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button123
            // 
            this.button123.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button123.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button123.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button123.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button123.Location = new System.Drawing.Point(345, 49);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(70, 50);
            this.button123.TabIndex = 249;
            this.button123.TabStop = false;
            this.button123.Text = "11";
            this.button123.UseCompatibleTextRendering = true;
            this.button123.UseVisualStyleBackColor = true;
            this.button123.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button117
            // 
            this.button117.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button117.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button117.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button117.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button117.Location = new System.Drawing.Point(69, 49);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(70, 50);
            this.button117.TabIndex = 248;
            this.button117.TabStop = false;
            this.button117.Text = "7";
            this.button117.UseCompatibleTextRendering = true;
            this.button117.UseVisualStyleBackColor = true;
            this.button117.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button115
            // 
            this.button115.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button115.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button115.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button115.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button115.Location = new System.Drawing.Point(414, 0);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(70, 50);
            this.button115.TabIndex = 245;
            this.button115.TabStop = false;
            this.button115.Text = "5";
            this.button115.UseCompatibleTextRendering = true;
            this.button115.UseVisualStyleBackColor = true;
            this.button115.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button118
            // 
            this.button118.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button118.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button118.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button118.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button118.Location = new System.Drawing.Point(0, 49);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(70, 50);
            this.button118.TabIndex = 244;
            this.button118.TabStop = false;
            this.button118.Text = "6";
            this.button118.UseCompatibleTextRendering = true;
            this.button118.UseVisualStyleBackColor = true;
            this.button118.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button116
            // 
            this.button116.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button116.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button116.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button116.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button116.Location = new System.Drawing.Point(345, 0);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(70, 50);
            this.button116.TabIndex = 244;
            this.button116.TabStop = false;
            this.button116.Text = "4";
            this.button116.UseCompatibleTextRendering = true;
            this.button116.UseVisualStyleBackColor = true;
            this.button116.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button119
            // 
            this.button119.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button119.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button119.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button119.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button119.Location = new System.Drawing.Point(276, 49);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(70, 50);
            this.button119.TabIndex = 247;
            this.button119.TabStop = false;
            this.button119.Text = "10";
            this.button119.UseCompatibleTextRendering = true;
            this.button119.UseVisualStyleBackColor = true;
            this.button119.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button8
            // 
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button8.Location = new System.Drawing.Point(276, 0);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(70, 50);
            this.button8.TabIndex = 205;
            this.button8.TabStop = false;
            this.button8.Text = "3";
            this.button8.UseCompatibleTextRendering = true;
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button120
            // 
            this.button120.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button120.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button120.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button120.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button120.Location = new System.Drawing.Point(207, 49);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(70, 50);
            this.button120.TabIndex = 246;
            this.button120.TabStop = false;
            this.button120.Text = "9";
            this.button120.UseCompatibleTextRendering = true;
            this.button120.UseVisualStyleBackColor = true;
            this.button120.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button121
            // 
            this.button121.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button121.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button121.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button121.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button121.Location = new System.Drawing.Point(138, 49);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(70, 50);
            this.button121.TabIndex = 245;
            this.button121.TabStop = false;
            this.button121.Text = "8";
            this.button121.UseCompatibleTextRendering = true;
            this.button121.UseVisualStyleBackColor = true;
            this.button121.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button9
            // 
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button9.Location = new System.Drawing.Point(207, 0);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(70, 50);
            this.button9.TabIndex = 204;
            this.button9.TabStop = false;
            this.button9.Text = "2";
            this.button9.UseCompatibleTextRendering = true;
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button114
            // 
            this.button114.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button114.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button114.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button114.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button114.Location = new System.Drawing.Point(138, 0);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(70, 50);
            this.button114.TabIndex = 203;
            this.button114.TabStop = false;
            this.button114.Text = "1";
            this.button114.UseCompatibleTextRendering = true;
            this.button114.UseVisualStyleBackColor = true;
            this.button114.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label183
            // 
            this.label183.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label183.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label183.ForeColor = System.Drawing.Color.Gray;
            this.label183.Location = new System.Drawing.Point(207, 245);
            this.label183.Name = "label183";
            this.label183.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label183.Size = new System.Drawing.Size(70, 50);
            this.label183.TabIndex = 153;
            this.label183.Text = "6";
            this.label183.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label184
            // 
            this.label184.BackColor = System.Drawing.Color.Transparent;
            this.label184.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label184.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label184.ForeColor = System.Drawing.Color.Gray;
            this.label184.Location = new System.Drawing.Point(69, 0);
            this.label184.Name = "label184";
            this.label184.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label184.Size = new System.Drawing.Size(70, 50);
            this.label184.TabIndex = 142;
            this.label184.Text = "31";
            this.label184.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label185
            // 
            this.label185.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label185.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label185.ForeColor = System.Drawing.Color.Gray;
            this.label185.Location = new System.Drawing.Point(0, 245);
            this.label185.Name = "label185";
            this.label185.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label185.Size = new System.Drawing.Size(70, 50);
            this.label185.TabIndex = 152;
            this.label185.Text = "3";
            this.label185.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label187
            // 
            this.label187.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label187.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label187.ForeColor = System.Drawing.Color.Gray;
            this.label187.Location = new System.Drawing.Point(69, 245);
            this.label187.Name = "label187";
            this.label187.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label187.Size = new System.Drawing.Size(70, 50);
            this.label187.TabIndex = 151;
            this.label187.Text = "4";
            this.label187.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label189
            // 
            this.label189.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label189.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label189.ForeColor = System.Drawing.Color.Gray;
            this.label189.Location = new System.Drawing.Point(138, 245);
            this.label189.Name = "label189";
            this.label189.Size = new System.Drawing.Size(70, 50);
            this.label189.TabIndex = 150;
            this.label189.Text = "5";
            this.label189.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label191
            // 
            this.label191.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label191.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label191.ForeColor = System.Drawing.Color.Gray;
            this.label191.Location = new System.Drawing.Point(345, 245);
            this.label191.Name = "label191";
            this.label191.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label191.Size = new System.Drawing.Size(70, 50);
            this.label191.TabIndex = 148;
            this.label191.Text = "8";
            this.label191.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label193
            // 
            this.label193.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label193.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label193.ForeColor = System.Drawing.Color.Gray;
            this.label193.Location = new System.Drawing.Point(276, 245);
            this.label193.Name = "label193";
            this.label193.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label193.Size = new System.Drawing.Size(70, 50);
            this.label193.TabIndex = 147;
            this.label193.Text = "7";
            this.label193.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label195
            // 
            this.label195.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label195.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label195.ForeColor = System.Drawing.Color.Gray;
            this.label195.Location = new System.Drawing.Point(414, 245);
            this.label195.Name = "label195";
            this.label195.Size = new System.Drawing.Size(70, 50);
            this.label195.TabIndex = 149;
            this.label195.Text = "9";
            this.label195.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label197
            // 
            this.label197.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label197.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label197.ForeColor = System.Drawing.Color.Gray;
            this.label197.Location = new System.Drawing.Point(345, 196);
            this.label197.Name = "label197";
            this.label197.Size = new System.Drawing.Size(70, 50);
            this.label197.TabIndex = 145;
            this.label197.Text = "1";
            this.label197.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label200
            // 
            this.label200.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label200.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label200.ForeColor = System.Drawing.Color.Gray;
            this.label200.Location = new System.Drawing.Point(414, 196);
            this.label200.Name = "label200";
            this.label200.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label200.Size = new System.Drawing.Size(70, 50);
            this.label200.TabIndex = 146;
            this.label200.Text = "2";
            this.label200.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label223
            // 
            this.label223.BackColor = System.Drawing.Color.Transparent;
            this.label223.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label223.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label223.ForeColor = System.Drawing.Color.Gray;
            this.label223.Location = new System.Drawing.Point(0, 0);
            this.label223.Name = "label223";
            this.label223.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label223.Size = new System.Drawing.Size(70, 50);
            this.label223.TabIndex = 143;
            this.label223.Text = "30";
            this.label223.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label224
            // 
            this.label224.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label224.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label224.Location = new System.Drawing.Point(0, 343);
            this.label224.Name = "label224";
            this.label224.Size = new System.Drawing.Size(486, 10);
            this.label224.TabIndex = 113;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button17.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.FlatAppearance.BorderSize = 0;
            this.button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(452, 4);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(30, 30);
            this.button17.TabIndex = 122;
            this.button17.TabStop = false;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button20.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button20.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button20.FlatAppearance.BorderSize = 0;
            this.button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(5, 4);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(30, 30);
            this.button20.TabIndex = 121;
            this.button20.TabStop = false;
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // heading5
            // 
            this.heading5.Location = new System.Drawing.Point(1, 1);
            this.heading5.Name = "heading5";
            this.heading5.Size = new System.Drawing.Size(484, 58);
            this.heading5.TabIndex = 119;
            // 
            // June
            // 
            this.June.Controls.Add(this.Jun);
            this.June.Controls.Add(this.button22);
            this.June.Controls.Add(this.button25);
            this.June.Controls.Add(this.panel6);
            this.June.Controls.Add(this.label270);
            this.June.Controls.Add(this.heading6);
            this.June.Location = new System.Drawing.Point(1, 70);
            this.June.Name = "June";
            this.June.Size = new System.Drawing.Size(486, 353);
            this.June.TabIndex = 234;
            // 
            // Jun
            // 
            this.Jun.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Jun.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Jun.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Jun.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Jun.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Jun.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Jun.Location = new System.Drawing.Point(139, 0);
            this.Jun.Name = "Jun";
            this.Jun.Size = new System.Drawing.Size(208, 39);
            this.Jun.TabIndex = 157;
            this.Jun.TabStop = false;
            this.Jun.Text = "June";
            this.Jun.UseVisualStyleBackColor = false;
            this.Jun.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button22.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button22.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button22.FlatAppearance.BorderSize = 0;
            this.button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(452, 4);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(30, 30);
            this.button22.TabIndex = 122;
            this.button22.TabStop = false;
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button25.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button25.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button25.FlatAppearance.BorderSize = 0;
            this.button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(5, 4);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(30, 30);
            this.button25.TabIndex = 121;
            this.button25.TabStop = false;
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.button200);
            this.panel6.Controls.Add(this.button195);
            this.panel6.Controls.Add(this.button201);
            this.panel6.Controls.Add(this.button202);
            this.panel6.Controls.Add(this.button198);
            this.panel6.Controls.Add(this.button203);
            this.panel6.Controls.Add(this.button194);
            this.panel6.Controls.Add(this.button199);
            this.panel6.Controls.Add(this.button196);
            this.panel6.Controls.Add(this.button197);
            this.panel6.Controls.Add(this.button191);
            this.panel6.Controls.Add(this.button190);
            this.panel6.Controls.Add(this.button192);
            this.panel6.Controls.Add(this.button193);
            this.panel6.Controls.Add(this.button184);
            this.panel6.Controls.Add(this.button183);
            this.panel6.Controls.Add(this.button185);
            this.panel6.Controls.Add(this.button186);
            this.panel6.Controls.Add(this.button177);
            this.panel6.Controls.Add(this.button187);
            this.panel6.Controls.Add(this.button176);
            this.panel6.Controls.Add(this.button188);
            this.panel6.Controls.Add(this.button178);
            this.panel6.Controls.Add(this.button189);
            this.panel6.Controls.Add(this.button174);
            this.panel6.Controls.Add(this.button179);
            this.panel6.Controls.Add(this.button175);
            this.panel6.Controls.Add(this.button180);
            this.panel6.Controls.Add(this.button181);
            this.panel6.Controls.Add(this.label229);
            this.panel6.Controls.Add(this.button182);
            this.panel6.Controls.Add(this.label230);
            this.panel6.Controls.Add(this.label231);
            this.panel6.Controls.Add(this.label233);
            this.panel6.Controls.Add(this.label235);
            this.panel6.Controls.Add(this.label237);
            this.panel6.Controls.Add(this.label239);
            this.panel6.Controls.Add(this.label240);
            this.panel6.Controls.Add(this.label241);
            this.panel6.Controls.Add(this.label250);
            this.panel6.Controls.Add(this.label252);
            this.panel6.Controls.Add(this.label269);
            this.panel6.Location = new System.Drawing.Point(1, 58);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(484, 295);
            this.panel6.TabIndex = 124;
            // 
            // button200
            // 
            this.button200.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button200.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button200.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button200.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button200.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button200.Location = new System.Drawing.Point(207, 196);
            this.button200.Name = "button200";
            this.button200.Size = new System.Drawing.Size(70, 50);
            this.button200.TabIndex = 247;
            this.button200.TabStop = false;
            this.button200.Text = "28";
            this.button200.UseCompatibleTextRendering = true;
            this.button200.UseVisualStyleBackColor = true;
            this.button200.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button195
            // 
            this.button195.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button195.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button195.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button195.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button195.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button195.Location = new System.Drawing.Point(138, 196);
            this.button195.Name = "button195";
            this.button195.Size = new System.Drawing.Size(70, 50);
            this.button195.TabIndex = 197;
            this.button195.TabStop = false;
            this.button195.Text = "27";
            this.button195.UseCompatibleTextRendering = true;
            this.button195.UseVisualStyleBackColor = true;
            this.button195.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button201
            // 
            this.button201.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button201.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button201.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button201.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button201.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button201.Location = new System.Drawing.Point(414, 196);
            this.button201.Name = "button201";
            this.button201.Size = new System.Drawing.Size(70, 50);
            this.button201.TabIndex = 246;
            this.button201.TabStop = false;
            this.button201.Text = "31";
            this.button201.UseCompatibleTextRendering = true;
            this.button201.UseVisualStyleBackColor = true;
            this.button201.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button202
            // 
            this.button202.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button202.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button202.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button202.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button202.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button202.Location = new System.Drawing.Point(345, 196);
            this.button202.Name = "button202";
            this.button202.Size = new System.Drawing.Size(70, 50);
            this.button202.TabIndex = 245;
            this.button202.TabStop = false;
            this.button202.Text = "30";
            this.button202.UseCompatibleTextRendering = true;
            this.button202.UseVisualStyleBackColor = true;
            this.button202.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button198
            // 
            this.button198.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button198.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button198.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button198.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button198.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button198.Location = new System.Drawing.Point(69, 196);
            this.button198.Name = "button198";
            this.button198.Size = new System.Drawing.Size(70, 50);
            this.button198.TabIndex = 196;
            this.button198.TabStop = false;
            this.button198.Text = "26";
            this.button198.UseCompatibleTextRendering = true;
            this.button198.UseVisualStyleBackColor = true;
            this.button198.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button203
            // 
            this.button203.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button203.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button203.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button203.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button203.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button203.Location = new System.Drawing.Point(276, 196);
            this.button203.Name = "button203";
            this.button203.Size = new System.Drawing.Size(70, 50);
            this.button203.TabIndex = 244;
            this.button203.TabStop = false;
            this.button203.Text = "29";
            this.button203.UseCompatibleTextRendering = true;
            this.button203.UseVisualStyleBackColor = true;
            this.button203.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button194
            // 
            this.button194.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button194.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button194.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button194.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button194.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button194.Location = new System.Drawing.Point(276, 147);
            this.button194.Name = "button194";
            this.button194.Size = new System.Drawing.Size(70, 50);
            this.button194.TabIndex = 253;
            this.button194.TabStop = false;
            this.button194.Text = "21";
            this.button194.UseCompatibleTextRendering = true;
            this.button194.UseVisualStyleBackColor = true;
            this.button194.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button199
            // 
            this.button199.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button199.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button199.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button199.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button199.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button199.Location = new System.Drawing.Point(0, 196);
            this.button199.Name = "button199";
            this.button199.Size = new System.Drawing.Size(70, 50);
            this.button199.TabIndex = 195;
            this.button199.TabStop = false;
            this.button199.Text = "25";
            this.button199.UseCompatibleTextRendering = true;
            this.button199.UseVisualStyleBackColor = true;
            this.button199.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button196
            // 
            this.button196.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button196.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button196.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button196.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button196.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button196.Location = new System.Drawing.Point(414, 147);
            this.button196.Name = "button196";
            this.button196.Size = new System.Drawing.Size(70, 50);
            this.button196.TabIndex = 251;
            this.button196.TabStop = false;
            this.button196.Text = "23";
            this.button196.UseCompatibleTextRendering = true;
            this.button196.UseVisualStyleBackColor = true;
            this.button196.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button197
            // 
            this.button197.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button197.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button197.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button197.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button197.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button197.Location = new System.Drawing.Point(345, 147);
            this.button197.Name = "button197";
            this.button197.Size = new System.Drawing.Size(70, 50);
            this.button197.TabIndex = 250;
            this.button197.TabStop = false;
            this.button197.Text = "22";
            this.button197.UseCompatibleTextRendering = true;
            this.button197.UseVisualStyleBackColor = true;
            this.button197.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button191
            // 
            this.button191.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button191.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button191.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button191.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button191.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button191.Location = new System.Drawing.Point(207, 147);
            this.button191.Name = "button191";
            this.button191.Size = new System.Drawing.Size(70, 50);
            this.button191.TabIndex = 246;
            this.button191.TabStop = false;
            this.button191.Text = "20";
            this.button191.UseCompatibleTextRendering = true;
            this.button191.UseVisualStyleBackColor = true;
            this.button191.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button190
            // 
            this.button190.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button190.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button190.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button190.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button190.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button190.Location = new System.Drawing.Point(0, 147);
            this.button190.Name = "button190";
            this.button190.Size = new System.Drawing.Size(70, 50);
            this.button190.TabIndex = 244;
            this.button190.TabStop = false;
            this.button190.Text = "17";
            this.button190.UseCompatibleTextRendering = true;
            this.button190.UseVisualStyleBackColor = true;
            this.button190.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button192
            // 
            this.button192.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button192.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button192.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button192.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button192.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button192.Location = new System.Drawing.Point(138, 147);
            this.button192.Name = "button192";
            this.button192.Size = new System.Drawing.Size(70, 50);
            this.button192.TabIndex = 245;
            this.button192.TabStop = false;
            this.button192.Text = "19";
            this.button192.UseCompatibleTextRendering = true;
            this.button192.UseVisualStyleBackColor = true;
            this.button192.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button193
            // 
            this.button193.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button193.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button193.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button193.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button193.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button193.Location = new System.Drawing.Point(69, 147);
            this.button193.Name = "button193";
            this.button193.Size = new System.Drawing.Size(70, 50);
            this.button193.TabIndex = 244;
            this.button193.TabStop = false;
            this.button193.Text = "18";
            this.button193.UseCompatibleTextRendering = true;
            this.button193.UseVisualStyleBackColor = true;
            this.button193.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button184
            // 
            this.button184.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button184.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button184.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button184.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button184.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button184.Location = new System.Drawing.Point(276, 98);
            this.button184.Name = "button184";
            this.button184.Size = new System.Drawing.Size(70, 50);
            this.button184.TabIndex = 249;
            this.button184.TabStop = false;
            this.button184.Text = "14";
            this.button184.UseCompatibleTextRendering = true;
            this.button184.UseVisualStyleBackColor = true;
            this.button184.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button183
            // 
            this.button183.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button183.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button183.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button183.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button183.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button183.Location = new System.Drawing.Point(0, 98);
            this.button183.Name = "button183";
            this.button183.Size = new System.Drawing.Size(70, 50);
            this.button183.TabIndex = 244;
            this.button183.TabStop = false;
            this.button183.Text = "10";
            this.button183.UseCompatibleTextRendering = true;
            this.button183.UseVisualStyleBackColor = true;
            this.button183.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button185
            // 
            this.button185.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button185.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button185.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button185.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button185.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button185.Location = new System.Drawing.Point(414, 98);
            this.button185.Name = "button185";
            this.button185.Size = new System.Drawing.Size(70, 50);
            this.button185.TabIndex = 248;
            this.button185.TabStop = false;
            this.button185.Text = "16";
            this.button185.UseCompatibleTextRendering = true;
            this.button185.UseVisualStyleBackColor = true;
            this.button185.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button186
            // 
            this.button186.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button186.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button186.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button186.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button186.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button186.Location = new System.Drawing.Point(345, 98);
            this.button186.Name = "button186";
            this.button186.Size = new System.Drawing.Size(70, 50);
            this.button186.TabIndex = 247;
            this.button186.TabStop = false;
            this.button186.Text = "15";
            this.button186.UseCompatibleTextRendering = true;
            this.button186.UseVisualStyleBackColor = true;
            this.button186.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button177
            // 
            this.button177.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button177.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button177.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button177.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button177.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button177.Location = new System.Drawing.Point(276, 49);
            this.button177.Name = "button177";
            this.button177.Size = new System.Drawing.Size(70, 50);
            this.button177.TabIndex = 249;
            this.button177.TabStop = false;
            this.button177.Text = "7";
            this.button177.UseCompatibleTextRendering = true;
            this.button177.UseVisualStyleBackColor = true;
            this.button177.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button187
            // 
            this.button187.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button187.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button187.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button187.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button187.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button187.Location = new System.Drawing.Point(207, 98);
            this.button187.Name = "button187";
            this.button187.Size = new System.Drawing.Size(70, 50);
            this.button187.TabIndex = 246;
            this.button187.TabStop = false;
            this.button187.Text = "13";
            this.button187.UseCompatibleTextRendering = true;
            this.button187.UseVisualStyleBackColor = true;
            this.button187.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button176
            // 
            this.button176.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button176.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button176.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button176.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button176.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button176.Location = new System.Drawing.Point(0, 49);
            this.button176.Name = "button176";
            this.button176.Size = new System.Drawing.Size(70, 50);
            this.button176.TabIndex = 244;
            this.button176.TabStop = false;
            this.button176.Text = "3";
            this.button176.UseCompatibleTextRendering = true;
            this.button176.UseVisualStyleBackColor = true;
            this.button176.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button188
            // 
            this.button188.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button188.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button188.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button188.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button188.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button188.Location = new System.Drawing.Point(138, 98);
            this.button188.Name = "button188";
            this.button188.Size = new System.Drawing.Size(70, 50);
            this.button188.TabIndex = 245;
            this.button188.TabStop = false;
            this.button188.Text = "12";
            this.button188.UseCompatibleTextRendering = true;
            this.button188.UseVisualStyleBackColor = true;
            this.button188.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button178
            // 
            this.button178.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button178.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button178.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button178.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button178.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button178.Location = new System.Drawing.Point(207, 49);
            this.button178.Name = "button178";
            this.button178.Size = new System.Drawing.Size(70, 50);
            this.button178.TabIndex = 246;
            this.button178.TabStop = false;
            this.button178.Text = "6";
            this.button178.UseCompatibleTextRendering = true;
            this.button178.UseVisualStyleBackColor = true;
            this.button178.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button189
            // 
            this.button189.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button189.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button189.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button189.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button189.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button189.Location = new System.Drawing.Point(69, 98);
            this.button189.Name = "button189";
            this.button189.Size = new System.Drawing.Size(70, 50);
            this.button189.TabIndex = 244;
            this.button189.TabStop = false;
            this.button189.Text = "11";
            this.button189.UseCompatibleTextRendering = true;
            this.button189.UseVisualStyleBackColor = true;
            this.button189.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button174
            // 
            this.button174.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button174.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button174.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button174.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button174.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button174.Location = new System.Drawing.Point(414, 0);
            this.button174.Name = "button174";
            this.button174.Size = new System.Drawing.Size(70, 50);
            this.button174.TabIndex = 245;
            this.button174.TabStop = false;
            this.button174.Text = "2";
            this.button174.UseCompatibleTextRendering = true;
            this.button174.UseVisualStyleBackColor = true;
            this.button174.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button179
            // 
            this.button179.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button179.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button179.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button179.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button179.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button179.Location = new System.Drawing.Point(138, 49);
            this.button179.Name = "button179";
            this.button179.Size = new System.Drawing.Size(70, 50);
            this.button179.TabIndex = 245;
            this.button179.TabStop = false;
            this.button179.Text = "5";
            this.button179.UseCompatibleTextRendering = true;
            this.button179.UseVisualStyleBackColor = true;
            this.button179.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button175
            // 
            this.button175.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button175.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button175.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button175.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button175.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button175.Location = new System.Drawing.Point(345, 0);
            this.button175.Name = "button175";
            this.button175.Size = new System.Drawing.Size(70, 50);
            this.button175.TabIndex = 244;
            this.button175.TabStop = false;
            this.button175.Text = "1";
            this.button175.UseCompatibleTextRendering = true;
            this.button175.UseVisualStyleBackColor = true;
            this.button175.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button180
            // 
            this.button180.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button180.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button180.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button180.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button180.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button180.Location = new System.Drawing.Point(414, 49);
            this.button180.Name = "button180";
            this.button180.Size = new System.Drawing.Size(70, 50);
            this.button180.TabIndex = 248;
            this.button180.TabStop = false;
            this.button180.Text = "9";
            this.button180.UseCompatibleTextRendering = true;
            this.button180.UseVisualStyleBackColor = true;
            this.button180.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button181
            // 
            this.button181.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button181.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button181.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button181.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button181.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button181.Location = new System.Drawing.Point(345, 49);
            this.button181.Name = "button181";
            this.button181.Size = new System.Drawing.Size(70, 50);
            this.button181.TabIndex = 247;
            this.button181.TabStop = false;
            this.button181.Text = "8";
            this.button181.UseCompatibleTextRendering = true;
            this.button181.UseVisualStyleBackColor = true;
            this.button181.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label229
            // 
            this.label229.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label229.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label229.ForeColor = System.Drawing.Color.Gray;
            this.label229.Location = new System.Drawing.Point(207, 245);
            this.label229.Name = "label229";
            this.label229.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label229.Size = new System.Drawing.Size(70, 50);
            this.label229.TabIndex = 153;
            this.label229.Text = "4";
            this.label229.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button182
            // 
            this.button182.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button182.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button182.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button182.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button182.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button182.Location = new System.Drawing.Point(69, 49);
            this.button182.Name = "button182";
            this.button182.Size = new System.Drawing.Size(70, 50);
            this.button182.TabIndex = 244;
            this.button182.TabStop = false;
            this.button182.Text = "4";
            this.button182.UseCompatibleTextRendering = true;
            this.button182.UseVisualStyleBackColor = true;
            this.button182.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label230
            // 
            this.label230.BackColor = System.Drawing.Color.Transparent;
            this.label230.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label230.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label230.ForeColor = System.Drawing.Color.Gray;
            this.label230.Location = new System.Drawing.Point(69, 0);
            this.label230.Name = "label230";
            this.label230.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label230.Size = new System.Drawing.Size(70, 50);
            this.label230.TabIndex = 142;
            this.label230.Text = "28";
            this.label230.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label231
            // 
            this.label231.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label231.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label231.ForeColor = System.Drawing.Color.Gray;
            this.label231.Location = new System.Drawing.Point(0, 245);
            this.label231.Name = "label231";
            this.label231.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label231.Size = new System.Drawing.Size(70, 50);
            this.label231.TabIndex = 152;
            this.label231.Text = "1";
            this.label231.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label233
            // 
            this.label233.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label233.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label233.ForeColor = System.Drawing.Color.Gray;
            this.label233.Location = new System.Drawing.Point(69, 245);
            this.label233.Name = "label233";
            this.label233.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label233.Size = new System.Drawing.Size(70, 50);
            this.label233.TabIndex = 151;
            this.label233.Text = "2";
            this.label233.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label235
            // 
            this.label235.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label235.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label235.ForeColor = System.Drawing.Color.Gray;
            this.label235.Location = new System.Drawing.Point(138, 245);
            this.label235.Name = "label235";
            this.label235.Size = new System.Drawing.Size(70, 50);
            this.label235.TabIndex = 150;
            this.label235.Text = "3";
            this.label235.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label237
            // 
            this.label237.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label237.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label237.ForeColor = System.Drawing.Color.Gray;
            this.label237.Location = new System.Drawing.Point(345, 245);
            this.label237.Name = "label237";
            this.label237.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label237.Size = new System.Drawing.Size(70, 50);
            this.label237.TabIndex = 148;
            this.label237.Text = "6";
            this.label237.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label239
            // 
            this.label239.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label239.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label239.ForeColor = System.Drawing.Color.Gray;
            this.label239.Location = new System.Drawing.Point(276, 245);
            this.label239.Name = "label239";
            this.label239.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label239.Size = new System.Drawing.Size(70, 50);
            this.label239.TabIndex = 147;
            this.label239.Text = "5";
            this.label239.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label240
            // 
            this.label240.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label240.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label240.ForeColor = System.Drawing.Color.Gray;
            this.label240.Location = new System.Drawing.Point(276, 0);
            this.label240.Name = "label240";
            this.label240.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label240.Size = new System.Drawing.Size(70, 50);
            this.label240.TabIndex = 113;
            this.label240.Text = "31";
            this.label240.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label241
            // 
            this.label241.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label241.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label241.ForeColor = System.Drawing.Color.Gray;
            this.label241.Location = new System.Drawing.Point(414, 245);
            this.label241.Name = "label241";
            this.label241.Size = new System.Drawing.Size(70, 50);
            this.label241.TabIndex = 149;
            this.label241.Text = "7";
            this.label241.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label250
            // 
            this.label250.BackColor = System.Drawing.Color.Transparent;
            this.label250.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label250.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label250.ForeColor = System.Drawing.Color.Gray;
            this.label250.Location = new System.Drawing.Point(138, 0);
            this.label250.Name = "label250";
            this.label250.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label250.Size = new System.Drawing.Size(70, 50);
            this.label250.TabIndex = 141;
            this.label250.Text = "29";
            this.label250.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label252
            // 
            this.label252.BackColor = System.Drawing.Color.Transparent;
            this.label252.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label252.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label252.ForeColor = System.Drawing.Color.Gray;
            this.label252.Location = new System.Drawing.Point(207, 0);
            this.label252.Name = "label252";
            this.label252.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label252.Size = new System.Drawing.Size(70, 50);
            this.label252.TabIndex = 140;
            this.label252.Text = "30";
            this.label252.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label269
            // 
            this.label269.BackColor = System.Drawing.Color.Transparent;
            this.label269.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label269.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label269.ForeColor = System.Drawing.Color.Gray;
            this.label269.Location = new System.Drawing.Point(0, 0);
            this.label269.Name = "label269";
            this.label269.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label269.Size = new System.Drawing.Size(70, 50);
            this.label269.TabIndex = 143;
            this.label269.Text = "27";
            this.label269.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label270
            // 
            this.label270.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label270.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label270.Location = new System.Drawing.Point(0, 343);
            this.label270.Name = "label270";
            this.label270.Size = new System.Drawing.Size(486, 10);
            this.label270.TabIndex = 113;
            // 
            // heading6
            // 
            this.heading6.Location = new System.Drawing.Point(1, 1);
            this.heading6.Name = "heading6";
            this.heading6.Size = new System.Drawing.Size(484, 58);
            this.heading6.TabIndex = 125;
            // 
            // July
            // 
            this.July.Controls.Add(this.Jul);
            this.July.Controls.Add(this.button27);
            this.July.Controls.Add(this.button30);
            this.July.Controls.Add(this.panel7);
            this.July.Controls.Add(this.heading7);
            this.July.Location = new System.Drawing.Point(1, 70);
            this.July.Name = "July";
            this.July.Size = new System.Drawing.Size(486, 353);
            this.July.TabIndex = 235;
            // 
            // Jul
            // 
            this.Jul.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Jul.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Jul.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Jul.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Jul.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Jul.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Jul.Location = new System.Drawing.Point(139, 0);
            this.Jul.Name = "Jul";
            this.Jul.Size = new System.Drawing.Size(208, 39);
            this.Jul.TabIndex = 158;
            this.Jul.TabStop = false;
            this.Jul.Text = "July";
            this.Jul.UseVisualStyleBackColor = false;
            this.Jul.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button27.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button27.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button27.FlatAppearance.BorderSize = 0;
            this.button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(452, 4);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(30, 30);
            this.button27.TabIndex = 122;
            this.button27.TabStop = false;
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button30.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button30.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button30.FlatAppearance.BorderSize = 0;
            this.button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(5, 4);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(30, 30);
            this.button30.TabIndex = 121;
            this.button30.TabStop = false;
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.button232);
            this.panel7.Controls.Add(this.button231);
            this.panel7.Controls.Add(this.button233);
            this.panel7.Controls.Add(this.button234);
            this.panel7.Controls.Add(this.button225);
            this.panel7.Controls.Add(this.button224);
            this.panel7.Controls.Add(this.button226);
            this.panel7.Controls.Add(this.button227);
            this.panel7.Controls.Add(this.button221);
            this.panel7.Controls.Add(this.button228);
            this.panel7.Controls.Add(this.button222);
            this.panel7.Controls.Add(this.button229);
            this.panel7.Controls.Add(this.button218);
            this.panel7.Controls.Add(this.button230);
            this.panel7.Controls.Add(this.button223);
            this.panel7.Controls.Add(this.button219);
            this.panel7.Controls.Add(this.button214);
            this.panel7.Controls.Add(this.button220);
            this.panel7.Controls.Add(this.button215);
            this.panel7.Controls.Add(this.button211);
            this.panel7.Controls.Add(this.button216);
            this.panel7.Controls.Add(this.button212);
            this.panel7.Controls.Add(this.button217);
            this.panel7.Controls.Add(this.button213);
            this.panel7.Controls.Add(this.button207);
            this.panel7.Controls.Add(this.button204);
            this.panel7.Controls.Add(this.button208);
            this.panel7.Controls.Add(this.button209);
            this.panel7.Controls.Add(this.button205);
            this.panel7.Controls.Add(this.button210);
            this.panel7.Controls.Add(this.button206);
            this.panel7.Controls.Add(this.label273);
            this.panel7.Controls.Add(this.label275);
            this.panel7.Controls.Add(this.label277);
            this.panel7.Controls.Add(this.label279);
            this.panel7.Controls.Add(this.label281);
            this.panel7.Controls.Add(this.label283);
            this.panel7.Controls.Add(this.label285);
            this.panel7.Controls.Add(this.label287);
            this.panel7.Controls.Add(this.label289);
            this.panel7.Controls.Add(this.label292);
            this.panel7.Controls.Add(this.label300);
            this.panel7.Location = new System.Drawing.Point(1, 58);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(484, 295);
            this.panel7.TabIndex = 124;
            // 
            // button232
            // 
            this.button232.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button232.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button232.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button232.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button232.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button232.Location = new System.Drawing.Point(138, 196);
            this.button232.Name = "button232";
            this.button232.Size = new System.Drawing.Size(70, 50);
            this.button232.TabIndex = 246;
            this.button232.TabStop = false;
            this.button232.Text = "31";
            this.button232.UseCompatibleTextRendering = true;
            this.button232.UseVisualStyleBackColor = true;
            this.button232.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button231
            // 
            this.button231.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button231.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button231.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button231.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button231.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button231.Location = new System.Drawing.Point(414, 147);
            this.button231.Name = "button231";
            this.button231.Size = new System.Drawing.Size(70, 50);
            this.button231.TabIndex = 244;
            this.button231.TabStop = false;
            this.button231.Text = "28";
            this.button231.UseCompatibleTextRendering = true;
            this.button231.UseVisualStyleBackColor = true;
            this.button231.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button233
            // 
            this.button233.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button233.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button233.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button233.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button233.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button233.Location = new System.Drawing.Point(69, 196);
            this.button233.Name = "button233";
            this.button233.Size = new System.Drawing.Size(70, 50);
            this.button233.TabIndex = 245;
            this.button233.TabStop = false;
            this.button233.Text = "30";
            this.button233.UseCompatibleTextRendering = true;
            this.button233.UseVisualStyleBackColor = true;
            this.button233.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button234
            // 
            this.button234.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button234.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button234.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button234.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button234.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button234.Location = new System.Drawing.Point(0, 196);
            this.button234.Name = "button234";
            this.button234.Size = new System.Drawing.Size(70, 50);
            this.button234.TabIndex = 244;
            this.button234.TabStop = false;
            this.button234.Text = "29";
            this.button234.UseCompatibleTextRendering = true;
            this.button234.UseVisualStyleBackColor = true;
            this.button234.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button225
            // 
            this.button225.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button225.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button225.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button225.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button225.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button225.Location = new System.Drawing.Point(345, 147);
            this.button225.Name = "button225";
            this.button225.Size = new System.Drawing.Size(70, 50);
            this.button225.TabIndex = 249;
            this.button225.TabStop = false;
            this.button225.Text = "27";
            this.button225.UseCompatibleTextRendering = true;
            this.button225.UseVisualStyleBackColor = true;
            this.button225.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button224
            // 
            this.button224.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button224.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button224.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button224.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button224.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button224.Location = new System.Drawing.Point(414, 98);
            this.button224.Name = "button224";
            this.button224.Size = new System.Drawing.Size(70, 50);
            this.button224.TabIndex = 248;
            this.button224.TabStop = false;
            this.button224.Text = "21";
            this.button224.UseCompatibleTextRendering = true;
            this.button224.UseVisualStyleBackColor = true;
            this.button224.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button226
            // 
            this.button226.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button226.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button226.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button226.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button226.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button226.Location = new System.Drawing.Point(276, 147);
            this.button226.Name = "button226";
            this.button226.Size = new System.Drawing.Size(70, 50);
            this.button226.TabIndex = 248;
            this.button226.TabStop = false;
            this.button226.Text = "26";
            this.button226.UseCompatibleTextRendering = true;
            this.button226.UseVisualStyleBackColor = true;
            this.button226.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button227
            // 
            this.button227.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button227.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button227.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button227.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button227.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button227.Location = new System.Drawing.Point(207, 147);
            this.button227.Name = "button227";
            this.button227.Size = new System.Drawing.Size(70, 50);
            this.button227.TabIndex = 247;
            this.button227.TabStop = false;
            this.button227.Text = "25";
            this.button227.UseCompatibleTextRendering = true;
            this.button227.UseVisualStyleBackColor = true;
            this.button227.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button221
            // 
            this.button221.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button221.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button221.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button221.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button221.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button221.Location = new System.Drawing.Point(345, 98);
            this.button221.Name = "button221";
            this.button221.Size = new System.Drawing.Size(70, 50);
            this.button221.TabIndex = 191;
            this.button221.TabStop = false;
            this.button221.Text = "20";
            this.button221.UseCompatibleTextRendering = true;
            this.button221.UseVisualStyleBackColor = true;
            this.button221.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button228
            // 
            this.button228.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button228.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button228.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button228.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button228.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button228.Location = new System.Drawing.Point(138, 147);
            this.button228.Name = "button228";
            this.button228.Size = new System.Drawing.Size(70, 50);
            this.button228.TabIndex = 246;
            this.button228.TabStop = false;
            this.button228.Text = "24";
            this.button228.UseCompatibleTextRendering = true;
            this.button228.UseVisualStyleBackColor = true;
            this.button228.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button222
            // 
            this.button222.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button222.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button222.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button222.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button222.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button222.Location = new System.Drawing.Point(276, 98);
            this.button222.Name = "button222";
            this.button222.Size = new System.Drawing.Size(70, 50);
            this.button222.TabIndex = 190;
            this.button222.TabStop = false;
            this.button222.Text = "19";
            this.button222.UseCompatibleTextRendering = true;
            this.button222.UseVisualStyleBackColor = true;
            this.button222.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button229
            // 
            this.button229.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button229.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button229.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button229.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button229.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button229.Location = new System.Drawing.Point(69, 147);
            this.button229.Name = "button229";
            this.button229.Size = new System.Drawing.Size(70, 50);
            this.button229.TabIndex = 245;
            this.button229.TabStop = false;
            this.button229.Text = "23";
            this.button229.UseCompatibleTextRendering = true;
            this.button229.UseVisualStyleBackColor = true;
            this.button229.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button218
            // 
            this.button218.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button218.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button218.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button218.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button218.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button218.Location = new System.Drawing.Point(138, 98);
            this.button218.Name = "button218";
            this.button218.Size = new System.Drawing.Size(70, 50);
            this.button218.TabIndex = 246;
            this.button218.TabStop = false;
            this.button218.Text = "17";
            this.button218.UseCompatibleTextRendering = true;
            this.button218.UseVisualStyleBackColor = true;
            this.button218.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button230
            // 
            this.button230.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button230.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button230.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button230.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button230.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button230.Location = new System.Drawing.Point(0, 147);
            this.button230.Name = "button230";
            this.button230.Size = new System.Drawing.Size(70, 50);
            this.button230.TabIndex = 244;
            this.button230.TabStop = false;
            this.button230.Text = "22";
            this.button230.UseCompatibleTextRendering = true;
            this.button230.UseVisualStyleBackColor = true;
            this.button230.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button223
            // 
            this.button223.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button223.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button223.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button223.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button223.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button223.Location = new System.Drawing.Point(207, 98);
            this.button223.Name = "button223";
            this.button223.Size = new System.Drawing.Size(70, 50);
            this.button223.TabIndex = 189;
            this.button223.TabStop = false;
            this.button223.Text = "18";
            this.button223.UseCompatibleTextRendering = true;
            this.button223.UseVisualStyleBackColor = true;
            this.button223.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button219
            // 
            this.button219.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button219.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button219.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button219.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button219.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button219.Location = new System.Drawing.Point(69, 98);
            this.button219.Name = "button219";
            this.button219.Size = new System.Drawing.Size(70, 50);
            this.button219.TabIndex = 245;
            this.button219.TabStop = false;
            this.button219.Text = "16";
            this.button219.UseCompatibleTextRendering = true;
            this.button219.UseVisualStyleBackColor = true;
            this.button219.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button214
            // 
            this.button214.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button214.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button214.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button214.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button214.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button214.Location = new System.Drawing.Point(414, 49);
            this.button214.Name = "button214";
            this.button214.Size = new System.Drawing.Size(70, 50);
            this.button214.TabIndex = 247;
            this.button214.TabStop = false;
            this.button214.Text = "14";
            this.button214.UseCompatibleTextRendering = true;
            this.button214.UseVisualStyleBackColor = true;
            this.button214.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button220
            // 
            this.button220.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button220.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button220.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button220.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button220.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button220.Location = new System.Drawing.Point(0, 98);
            this.button220.Name = "button220";
            this.button220.Size = new System.Drawing.Size(70, 50);
            this.button220.TabIndex = 244;
            this.button220.TabStop = false;
            this.button220.Text = "15";
            this.button220.UseCompatibleTextRendering = true;
            this.button220.UseVisualStyleBackColor = true;
            this.button220.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button215
            // 
            this.button215.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button215.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button215.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button215.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button215.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button215.Location = new System.Drawing.Point(345, 49);
            this.button215.Name = "button215";
            this.button215.Size = new System.Drawing.Size(70, 50);
            this.button215.TabIndex = 246;
            this.button215.TabStop = false;
            this.button215.Text = "13";
            this.button215.UseCompatibleTextRendering = true;
            this.button215.UseVisualStyleBackColor = true;
            this.button215.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button211
            // 
            this.button211.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button211.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button211.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button211.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button211.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button211.Location = new System.Drawing.Point(138, 49);
            this.button211.Name = "button211";
            this.button211.Size = new System.Drawing.Size(70, 50);
            this.button211.TabIndex = 216;
            this.button211.TabStop = false;
            this.button211.Text = "10";
            this.button211.UseCompatibleTextRendering = true;
            this.button211.UseVisualStyleBackColor = true;
            this.button211.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button216
            // 
            this.button216.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button216.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button216.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button216.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button216.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button216.Location = new System.Drawing.Point(276, 49);
            this.button216.Name = "button216";
            this.button216.Size = new System.Drawing.Size(70, 50);
            this.button216.TabIndex = 245;
            this.button216.TabStop = false;
            this.button216.Text = "12";
            this.button216.UseCompatibleTextRendering = true;
            this.button216.UseVisualStyleBackColor = true;
            this.button216.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button212
            // 
            this.button212.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button212.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button212.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button212.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button212.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button212.Location = new System.Drawing.Point(69, 49);
            this.button212.Name = "button212";
            this.button212.Size = new System.Drawing.Size(70, 50);
            this.button212.TabIndex = 215;
            this.button212.TabStop = false;
            this.button212.Text = "9";
            this.button212.UseCompatibleTextRendering = true;
            this.button212.UseVisualStyleBackColor = true;
            this.button212.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button217
            // 
            this.button217.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button217.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button217.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button217.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button217.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button217.Location = new System.Drawing.Point(207, 49);
            this.button217.Name = "button217";
            this.button217.Size = new System.Drawing.Size(70, 50);
            this.button217.TabIndex = 244;
            this.button217.TabStop = false;
            this.button217.Text = "11";
            this.button217.UseCompatibleTextRendering = true;
            this.button217.UseVisualStyleBackColor = true;
            this.button217.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button213
            // 
            this.button213.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button213.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button213.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button213.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button213.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button213.Location = new System.Drawing.Point(0, 49);
            this.button213.Name = "button213";
            this.button213.Size = new System.Drawing.Size(70, 50);
            this.button213.TabIndex = 214;
            this.button213.TabStop = false;
            this.button213.Text = "8";
            this.button213.UseCompatibleTextRendering = true;
            this.button213.UseVisualStyleBackColor = true;
            this.button213.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button207
            // 
            this.button207.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button207.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button207.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button207.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button207.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button207.Location = new System.Drawing.Point(414, 0);
            this.button207.Name = "button207";
            this.button207.Size = new System.Drawing.Size(70, 50);
            this.button207.TabIndex = 213;
            this.button207.TabStop = false;
            this.button207.Text = "7";
            this.button207.UseCompatibleTextRendering = true;
            this.button207.UseVisualStyleBackColor = true;
            this.button207.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button204
            // 
            this.button204.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button204.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button204.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button204.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button204.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button204.Location = new System.Drawing.Point(138, 0);
            this.button204.Name = "button204";
            this.button204.Size = new System.Drawing.Size(70, 50);
            this.button204.TabIndex = 205;
            this.button204.TabStop = false;
            this.button204.Text = "3";
            this.button204.UseCompatibleTextRendering = true;
            this.button204.UseVisualStyleBackColor = true;
            this.button204.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button208
            // 
            this.button208.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button208.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button208.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button208.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button208.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button208.Location = new System.Drawing.Point(345, 0);
            this.button208.Name = "button208";
            this.button208.Size = new System.Drawing.Size(70, 50);
            this.button208.TabIndex = 212;
            this.button208.TabStop = false;
            this.button208.Text = "6";
            this.button208.UseCompatibleTextRendering = true;
            this.button208.UseVisualStyleBackColor = true;
            this.button208.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button209
            // 
            this.button209.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button209.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button209.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button209.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button209.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button209.Location = new System.Drawing.Point(276, 0);
            this.button209.Name = "button209";
            this.button209.Size = new System.Drawing.Size(70, 50);
            this.button209.TabIndex = 211;
            this.button209.TabStop = false;
            this.button209.Text = "5";
            this.button209.UseCompatibleTextRendering = true;
            this.button209.UseVisualStyleBackColor = true;
            this.button209.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button205
            // 
            this.button205.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button205.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button205.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button205.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button205.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button205.Location = new System.Drawing.Point(69, 0);
            this.button205.Name = "button205";
            this.button205.Size = new System.Drawing.Size(70, 50);
            this.button205.TabIndex = 204;
            this.button205.TabStop = false;
            this.button205.Text = "2";
            this.button205.UseCompatibleTextRendering = true;
            this.button205.UseVisualStyleBackColor = true;
            this.button205.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button210
            // 
            this.button210.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button210.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button210.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button210.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button210.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button210.Location = new System.Drawing.Point(207, 0);
            this.button210.Name = "button210";
            this.button210.Size = new System.Drawing.Size(70, 50);
            this.button210.TabIndex = 210;
            this.button210.TabStop = false;
            this.button210.Text = "4";
            this.button210.UseCompatibleTextRendering = true;
            this.button210.UseVisualStyleBackColor = true;
            this.button210.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button206
            // 
            this.button206.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button206.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button206.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button206.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button206.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button206.Location = new System.Drawing.Point(0, 0);
            this.button206.Name = "button206";
            this.button206.Size = new System.Drawing.Size(70, 50);
            this.button206.TabIndex = 203;
            this.button206.TabStop = false;
            this.button206.Text = "1";
            this.button206.UseCompatibleTextRendering = true;
            this.button206.UseVisualStyleBackColor = true;
            this.button206.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label273
            // 
            this.label273.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label273.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label273.ForeColor = System.Drawing.Color.Gray;
            this.label273.Location = new System.Drawing.Point(276, 196);
            this.label273.Name = "label273";
            this.label273.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label273.Size = new System.Drawing.Size(70, 50);
            this.label273.TabIndex = 154;
            this.label273.Text = "2";
            this.label273.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label275
            // 
            this.label275.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label275.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label275.ForeColor = System.Drawing.Color.Gray;
            this.label275.Location = new System.Drawing.Point(207, 245);
            this.label275.Name = "label275";
            this.label275.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label275.Size = new System.Drawing.Size(70, 50);
            this.label275.TabIndex = 153;
            this.label275.Text = "8";
            this.label275.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label277
            // 
            this.label277.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label277.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label277.ForeColor = System.Drawing.Color.Gray;
            this.label277.Location = new System.Drawing.Point(0, 245);
            this.label277.Name = "label277";
            this.label277.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label277.Size = new System.Drawing.Size(70, 50);
            this.label277.TabIndex = 152;
            this.label277.Text = "5";
            this.label277.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label279
            // 
            this.label279.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label279.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label279.ForeColor = System.Drawing.Color.Gray;
            this.label279.Location = new System.Drawing.Point(69, 245);
            this.label279.Name = "label279";
            this.label279.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label279.Size = new System.Drawing.Size(70, 50);
            this.label279.TabIndex = 151;
            this.label279.Text = "6";
            this.label279.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label281
            // 
            this.label281.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label281.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label281.ForeColor = System.Drawing.Color.Gray;
            this.label281.Location = new System.Drawing.Point(138, 245);
            this.label281.Name = "label281";
            this.label281.Size = new System.Drawing.Size(70, 50);
            this.label281.TabIndex = 150;
            this.label281.Text = "7";
            this.label281.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label283
            // 
            this.label283.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label283.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label283.ForeColor = System.Drawing.Color.Gray;
            this.label283.Location = new System.Drawing.Point(345, 245);
            this.label283.Name = "label283";
            this.label283.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label283.Size = new System.Drawing.Size(70, 50);
            this.label283.TabIndex = 148;
            this.label283.Text = "10";
            this.label283.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label285
            // 
            this.label285.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label285.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label285.ForeColor = System.Drawing.Color.Gray;
            this.label285.Location = new System.Drawing.Point(276, 245);
            this.label285.Name = "label285";
            this.label285.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label285.Size = new System.Drawing.Size(70, 50);
            this.label285.TabIndex = 147;
            this.label285.Text = "9";
            this.label285.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label287
            // 
            this.label287.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label287.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label287.ForeColor = System.Drawing.Color.Gray;
            this.label287.Location = new System.Drawing.Point(414, 245);
            this.label287.Name = "label287";
            this.label287.Size = new System.Drawing.Size(70, 50);
            this.label287.TabIndex = 149;
            this.label287.Text = "11";
            this.label287.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label289
            // 
            this.label289.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label289.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label289.ForeColor = System.Drawing.Color.Gray;
            this.label289.Location = new System.Drawing.Point(345, 196);
            this.label289.Name = "label289";
            this.label289.Size = new System.Drawing.Size(70, 50);
            this.label289.TabIndex = 145;
            this.label289.Text = "3";
            this.label289.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label292
            // 
            this.label292.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label292.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label292.ForeColor = System.Drawing.Color.Gray;
            this.label292.Location = new System.Drawing.Point(414, 196);
            this.label292.Name = "label292";
            this.label292.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label292.Size = new System.Drawing.Size(70, 50);
            this.label292.TabIndex = 146;
            this.label292.Text = "4";
            this.label292.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label300
            // 
            this.label300.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label300.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label300.ForeColor = System.Drawing.Color.Gray;
            this.label300.Location = new System.Drawing.Point(207, 196);
            this.label300.Name = "label300";
            this.label300.Size = new System.Drawing.Size(70, 50);
            this.label300.TabIndex = 112;
            this.label300.Text = "1";
            this.label300.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // heading7
            // 
            this.heading7.Location = new System.Drawing.Point(1, 1);
            this.heading7.Name = "heading7";
            this.heading7.Size = new System.Drawing.Size(484, 58);
            this.heading7.TabIndex = 119;
            // 
            // August
            // 
            this.August.Controls.Add(this.Aug);
            this.August.Controls.Add(this.button32);
            this.August.Controls.Add(this.button35);
            this.August.Controls.Add(this.panel8);
            this.August.Controls.Add(this.label362);
            this.August.Controls.Add(this.heading8);
            this.August.Location = new System.Drawing.Point(1, 70);
            this.August.Name = "August";
            this.August.Size = new System.Drawing.Size(486, 353);
            this.August.TabIndex = 236;
            // 
            // Aug
            // 
            this.Aug.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Aug.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Aug.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Aug.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Aug.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Aug.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Aug.Location = new System.Drawing.Point(139, 0);
            this.Aug.Name = "Aug";
            this.Aug.Size = new System.Drawing.Size(208, 39);
            this.Aug.TabIndex = 159;
            this.Aug.TabStop = false;
            this.Aug.Text = "August";
            this.Aug.UseVisualStyleBackColor = false;
            this.Aug.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button32.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button32.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button32.FlatAppearance.BorderSize = 0;
            this.button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(452, 4);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(30, 30);
            this.button32.TabIndex = 122;
            this.button32.TabStop = false;
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button35.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button35.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button35.FlatAppearance.BorderSize = 0;
            this.button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(5, 4);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(30, 30);
            this.button35.TabIndex = 121;
            this.button35.TabStop = false;
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.button262);
            this.panel8.Controls.Add(this.button263);
            this.panel8.Controls.Add(this.button264);
            this.panel8.Controls.Add(this.button265);
            this.panel8.Controls.Add(this.button260);
            this.panel8.Controls.Add(this.button261);
            this.panel8.Controls.Add(this.button255);
            this.panel8.Controls.Add(this.button253);
            this.panel8.Controls.Add(this.button256);
            this.panel8.Controls.Add(this.button257);
            this.panel8.Controls.Add(this.button254);
            this.panel8.Controls.Add(this.button258);
            this.panel8.Controls.Add(this.button252);
            this.panel8.Controls.Add(this.button259);
            this.panel8.Controls.Add(this.button246);
            this.panel8.Controls.Add(this.button245);
            this.panel8.Controls.Add(this.button247);
            this.panel8.Controls.Add(this.button248);
            this.panel8.Controls.Add(this.button239);
            this.panel8.Controls.Add(this.button249);
            this.panel8.Controls.Add(this.button238);
            this.panel8.Controls.Add(this.button250);
            this.panel8.Controls.Add(this.button240);
            this.panel8.Controls.Add(this.button251);
            this.panel8.Controls.Add(this.button235);
            this.panel8.Controls.Add(this.button241);
            this.panel8.Controls.Add(this.button236);
            this.panel8.Controls.Add(this.button242);
            this.panel8.Controls.Add(this.label321);
            this.panel8.Controls.Add(this.button243);
            this.panel8.Controls.Add(this.button237);
            this.panel8.Controls.Add(this.button244);
            this.panel8.Controls.Add(this.label323);
            this.panel8.Controls.Add(this.label325);
            this.panel8.Controls.Add(this.label327);
            this.panel8.Controls.Add(this.label329);
            this.panel8.Controls.Add(this.label331);
            this.panel8.Controls.Add(this.label333);
            this.panel8.Controls.Add(this.label343);
            this.panel8.Controls.Add(this.label344);
            this.panel8.Controls.Add(this.label338);
            this.panel8.Controls.Add(this.label361);
            this.panel8.Location = new System.Drawing.Point(1, 58);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(484, 295);
            this.panel8.TabIndex = 124;
            // 
            // button262
            // 
            this.button262.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button262.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button262.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button262.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button262.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button262.Location = new System.Drawing.Point(138, 196);
            this.button262.Name = "button262";
            this.button262.Size = new System.Drawing.Size(70, 50);
            this.button262.TabIndex = 253;
            this.button262.TabStop = false;
            this.button262.Text = "28";
            this.button262.UseCompatibleTextRendering = true;
            this.button262.UseVisualStyleBackColor = true;
            this.button262.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button263
            // 
            this.button263.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button263.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button263.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button263.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button263.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button263.Location = new System.Drawing.Point(345, 196);
            this.button263.Name = "button263";
            this.button263.Size = new System.Drawing.Size(70, 50);
            this.button263.TabIndex = 252;
            this.button263.TabStop = false;
            this.button263.Text = "31";
            this.button263.UseCompatibleTextRendering = true;
            this.button263.UseVisualStyleBackColor = true;
            this.button263.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button264
            // 
            this.button264.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button264.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button264.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button264.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button264.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button264.Location = new System.Drawing.Point(276, 196);
            this.button264.Name = "button264";
            this.button264.Size = new System.Drawing.Size(70, 50);
            this.button264.TabIndex = 251;
            this.button264.TabStop = false;
            this.button264.Text = "30";
            this.button264.UseCompatibleTextRendering = true;
            this.button264.UseVisualStyleBackColor = true;
            this.button264.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button265
            // 
            this.button265.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button265.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button265.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button265.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button265.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button265.Location = new System.Drawing.Point(207, 196);
            this.button265.Name = "button265";
            this.button265.Size = new System.Drawing.Size(70, 50);
            this.button265.TabIndex = 250;
            this.button265.TabStop = false;
            this.button265.Text = "29";
            this.button265.UseCompatibleTextRendering = true;
            this.button265.UseVisualStyleBackColor = true;
            this.button265.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button260
            // 
            this.button260.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button260.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button260.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button260.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button260.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button260.Location = new System.Drawing.Point(69, 196);
            this.button260.Name = "button260";
            this.button260.Size = new System.Drawing.Size(70, 50);
            this.button260.TabIndex = 245;
            this.button260.TabStop = false;
            this.button260.Text = "27";
            this.button260.UseCompatibleTextRendering = true;
            this.button260.UseVisualStyleBackColor = true;
            this.button260.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button261
            // 
            this.button261.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button261.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button261.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button261.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button261.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button261.Location = new System.Drawing.Point(0, 196);
            this.button261.Name = "button261";
            this.button261.Size = new System.Drawing.Size(70, 50);
            this.button261.TabIndex = 244;
            this.button261.TabStop = false;
            this.button261.Text = "26";
            this.button261.UseCompatibleTextRendering = true;
            this.button261.UseVisualStyleBackColor = true;
            this.button261.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button255
            // 
            this.button255.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button255.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button255.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button255.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button255.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button255.Location = new System.Drawing.Point(138, 147);
            this.button255.Name = "button255";
            this.button255.Size = new System.Drawing.Size(70, 50);
            this.button255.TabIndex = 248;
            this.button255.TabStop = false;
            this.button255.Text = "21";
            this.button255.UseCompatibleTextRendering = true;
            this.button255.UseVisualStyleBackColor = true;
            this.button255.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button253
            // 
            this.button253.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button253.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button253.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button253.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button253.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button253.Location = new System.Drawing.Point(69, 147);
            this.button253.Name = "button253";
            this.button253.Size = new System.Drawing.Size(70, 50);
            this.button253.TabIndex = 245;
            this.button253.TabStop = false;
            this.button253.Text = "20";
            this.button253.UseCompatibleTextRendering = true;
            this.button253.UseVisualStyleBackColor = true;
            this.button253.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button256
            // 
            this.button256.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button256.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button256.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button256.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button256.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button256.Location = new System.Drawing.Point(414, 147);
            this.button256.Name = "button256";
            this.button256.Size = new System.Drawing.Size(70, 50);
            this.button256.TabIndex = 247;
            this.button256.TabStop = false;
            this.button256.Text = "25";
            this.button256.UseCompatibleTextRendering = true;
            this.button256.UseVisualStyleBackColor = true;
            this.button256.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button257
            // 
            this.button257.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button257.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button257.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button257.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button257.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button257.Location = new System.Drawing.Point(345, 147);
            this.button257.Name = "button257";
            this.button257.Size = new System.Drawing.Size(70, 50);
            this.button257.TabIndex = 246;
            this.button257.TabStop = false;
            this.button257.Text = "24";
            this.button257.UseCompatibleTextRendering = true;
            this.button257.UseVisualStyleBackColor = true;
            this.button257.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button254
            // 
            this.button254.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button254.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button254.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button254.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button254.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button254.Location = new System.Drawing.Point(0, 147);
            this.button254.Name = "button254";
            this.button254.Size = new System.Drawing.Size(70, 50);
            this.button254.TabIndex = 244;
            this.button254.TabStop = false;
            this.button254.Text = "19";
            this.button254.UseCompatibleTextRendering = true;
            this.button254.UseVisualStyleBackColor = true;
            this.button254.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button258
            // 
            this.button258.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button258.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button258.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button258.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button258.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button258.Location = new System.Drawing.Point(276, 147);
            this.button258.Name = "button258";
            this.button258.Size = new System.Drawing.Size(70, 50);
            this.button258.TabIndex = 245;
            this.button258.TabStop = false;
            this.button258.Text = "23";
            this.button258.UseCompatibleTextRendering = true;
            this.button258.UseVisualStyleBackColor = true;
            this.button258.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button252
            // 
            this.button252.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button252.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button252.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button252.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button252.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button252.Location = new System.Drawing.Point(414, 98);
            this.button252.Name = "button252";
            this.button252.Size = new System.Drawing.Size(70, 50);
            this.button252.TabIndex = 244;
            this.button252.TabStop = false;
            this.button252.Text = "18";
            this.button252.UseCompatibleTextRendering = true;
            this.button252.UseVisualStyleBackColor = true;
            this.button252.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button259
            // 
            this.button259.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button259.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button259.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button259.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button259.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button259.Location = new System.Drawing.Point(207, 147);
            this.button259.Name = "button259";
            this.button259.Size = new System.Drawing.Size(70, 50);
            this.button259.TabIndex = 244;
            this.button259.TabStop = false;
            this.button259.Text = "22";
            this.button259.UseCompatibleTextRendering = true;
            this.button259.UseVisualStyleBackColor = true;
            this.button259.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button246
            // 
            this.button246.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button246.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button246.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button246.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button246.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button246.Location = new System.Drawing.Point(138, 98);
            this.button246.Name = "button246";
            this.button246.Size = new System.Drawing.Size(70, 50);
            this.button246.TabIndex = 249;
            this.button246.TabStop = false;
            this.button246.Text = "14";
            this.button246.UseCompatibleTextRendering = true;
            this.button246.UseVisualStyleBackColor = true;
            this.button246.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button245
            // 
            this.button245.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button245.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button245.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button245.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button245.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button245.Location = new System.Drawing.Point(414, 49);
            this.button245.Name = "button245";
            this.button245.Size = new System.Drawing.Size(70, 50);
            this.button245.TabIndex = 244;
            this.button245.TabStop = false;
            this.button245.Text = "11";
            this.button245.UseCompatibleTextRendering = true;
            this.button245.UseVisualStyleBackColor = true;
            this.button245.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button247
            // 
            this.button247.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button247.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button247.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button247.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button247.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button247.Location = new System.Drawing.Point(345, 98);
            this.button247.Name = "button247";
            this.button247.Size = new System.Drawing.Size(70, 50);
            this.button247.TabIndex = 248;
            this.button247.TabStop = false;
            this.button247.Text = "17";
            this.button247.UseCompatibleTextRendering = true;
            this.button247.UseVisualStyleBackColor = true;
            this.button247.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button248
            // 
            this.button248.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button248.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button248.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button248.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button248.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button248.Location = new System.Drawing.Point(276, 98);
            this.button248.Name = "button248";
            this.button248.Size = new System.Drawing.Size(70, 50);
            this.button248.TabIndex = 247;
            this.button248.TabStop = false;
            this.button248.Text = "16";
            this.button248.UseCompatibleTextRendering = true;
            this.button248.UseVisualStyleBackColor = true;
            this.button248.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button239
            // 
            this.button239.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button239.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button239.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button239.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button239.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button239.Location = new System.Drawing.Point(138, 49);
            this.button239.Name = "button239";
            this.button239.Size = new System.Drawing.Size(70, 50);
            this.button239.TabIndex = 249;
            this.button239.TabStop = false;
            this.button239.Text = "7";
            this.button239.UseCompatibleTextRendering = true;
            this.button239.UseVisualStyleBackColor = true;
            this.button239.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button249
            // 
            this.button249.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button249.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button249.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button249.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button249.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button249.Location = new System.Drawing.Point(207, 98);
            this.button249.Name = "button249";
            this.button249.Size = new System.Drawing.Size(70, 50);
            this.button249.TabIndex = 246;
            this.button249.TabStop = false;
            this.button249.Text = "15";
            this.button249.UseCompatibleTextRendering = true;
            this.button249.UseVisualStyleBackColor = true;
            this.button249.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button238
            // 
            this.button238.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button238.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button238.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button238.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button238.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button238.Location = new System.Drawing.Point(414, 0);
            this.button238.Name = "button238";
            this.button238.Size = new System.Drawing.Size(70, 50);
            this.button238.TabIndex = 247;
            this.button238.TabStop = false;
            this.button238.Text = "4";
            this.button238.UseCompatibleTextRendering = true;
            this.button238.UseVisualStyleBackColor = true;
            this.button238.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button250
            // 
            this.button250.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button250.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button250.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button250.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button250.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button250.Location = new System.Drawing.Point(69, 98);
            this.button250.Name = "button250";
            this.button250.Size = new System.Drawing.Size(70, 50);
            this.button250.TabIndex = 245;
            this.button250.TabStop = false;
            this.button250.Text = "13";
            this.button250.UseCompatibleTextRendering = true;
            this.button250.UseVisualStyleBackColor = true;
            this.button250.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button240
            // 
            this.button240.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button240.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button240.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button240.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button240.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button240.Location = new System.Drawing.Point(69, 49);
            this.button240.Name = "button240";
            this.button240.Size = new System.Drawing.Size(70, 50);
            this.button240.TabIndex = 245;
            this.button240.TabStop = false;
            this.button240.Text = "6";
            this.button240.UseCompatibleTextRendering = true;
            this.button240.UseVisualStyleBackColor = true;
            this.button240.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button251
            // 
            this.button251.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button251.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button251.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button251.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button251.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button251.Location = new System.Drawing.Point(0, 98);
            this.button251.Name = "button251";
            this.button251.Size = new System.Drawing.Size(70, 50);
            this.button251.TabIndex = 244;
            this.button251.TabStop = false;
            this.button251.Text = "12";
            this.button251.UseCompatibleTextRendering = true;
            this.button251.UseVisualStyleBackColor = true;
            this.button251.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button235
            // 
            this.button235.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button235.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button235.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button235.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button235.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button235.Location = new System.Drawing.Point(345, 0);
            this.button235.Name = "button235";
            this.button235.Size = new System.Drawing.Size(70, 50);
            this.button235.TabIndex = 246;
            this.button235.TabStop = false;
            this.button235.Text = "3";
            this.button235.UseCompatibleTextRendering = true;
            this.button235.UseVisualStyleBackColor = true;
            this.button235.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button241
            // 
            this.button241.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button241.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button241.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button241.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button241.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button241.Location = new System.Drawing.Point(345, 49);
            this.button241.Name = "button241";
            this.button241.Size = new System.Drawing.Size(70, 50);
            this.button241.TabIndex = 248;
            this.button241.TabStop = false;
            this.button241.Text = "10";
            this.button241.UseCompatibleTextRendering = true;
            this.button241.UseVisualStyleBackColor = true;
            this.button241.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button236
            // 
            this.button236.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button236.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button236.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button236.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button236.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button236.Location = new System.Drawing.Point(276, 0);
            this.button236.Name = "button236";
            this.button236.Size = new System.Drawing.Size(70, 50);
            this.button236.TabIndex = 245;
            this.button236.TabStop = false;
            this.button236.Text = "2";
            this.button236.UseCompatibleTextRendering = true;
            this.button236.UseVisualStyleBackColor = true;
            this.button236.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button242
            // 
            this.button242.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button242.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button242.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button242.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button242.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button242.Location = new System.Drawing.Point(0, 49);
            this.button242.Name = "button242";
            this.button242.Size = new System.Drawing.Size(70, 50);
            this.button242.TabIndex = 244;
            this.button242.TabStop = false;
            this.button242.Text = "5";
            this.button242.UseCompatibleTextRendering = true;
            this.button242.UseVisualStyleBackColor = true;
            this.button242.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label321
            // 
            this.label321.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label321.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label321.ForeColor = System.Drawing.Color.Gray;
            this.label321.Location = new System.Drawing.Point(207, 245);
            this.label321.Name = "label321";
            this.label321.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label321.Size = new System.Drawing.Size(70, 50);
            this.label321.TabIndex = 153;
            this.label321.Text = "5";
            this.label321.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button243
            // 
            this.button243.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button243.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button243.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button243.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button243.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button243.Location = new System.Drawing.Point(276, 49);
            this.button243.Name = "button243";
            this.button243.Size = new System.Drawing.Size(70, 50);
            this.button243.TabIndex = 247;
            this.button243.TabStop = false;
            this.button243.Text = "9";
            this.button243.UseCompatibleTextRendering = true;
            this.button243.UseVisualStyleBackColor = true;
            this.button243.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button237
            // 
            this.button237.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button237.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button237.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button237.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button237.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button237.Location = new System.Drawing.Point(207, 0);
            this.button237.Name = "button237";
            this.button237.Size = new System.Drawing.Size(70, 50);
            this.button237.TabIndex = 244;
            this.button237.TabStop = false;
            this.button237.Text = "1";
            this.button237.UseCompatibleTextRendering = true;
            this.button237.UseVisualStyleBackColor = true;
            this.button237.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button244
            // 
            this.button244.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button244.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button244.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button244.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button244.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button244.Location = new System.Drawing.Point(207, 49);
            this.button244.Name = "button244";
            this.button244.Size = new System.Drawing.Size(70, 50);
            this.button244.TabIndex = 246;
            this.button244.TabStop = false;
            this.button244.Text = "8";
            this.button244.UseCompatibleTextRendering = true;
            this.button244.UseVisualStyleBackColor = true;
            this.button244.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label323
            // 
            this.label323.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label323.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label323.ForeColor = System.Drawing.Color.Gray;
            this.label323.Location = new System.Drawing.Point(0, 245);
            this.label323.Name = "label323";
            this.label323.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label323.Size = new System.Drawing.Size(70, 50);
            this.label323.TabIndex = 152;
            this.label323.Text = "2";
            this.label323.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label325
            // 
            this.label325.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label325.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label325.ForeColor = System.Drawing.Color.Gray;
            this.label325.Location = new System.Drawing.Point(69, 245);
            this.label325.Name = "label325";
            this.label325.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label325.Size = new System.Drawing.Size(70, 50);
            this.label325.TabIndex = 151;
            this.label325.Text = "3";
            this.label325.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label327
            // 
            this.label327.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label327.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label327.ForeColor = System.Drawing.Color.Gray;
            this.label327.Location = new System.Drawing.Point(138, 245);
            this.label327.Name = "label327";
            this.label327.Size = new System.Drawing.Size(70, 50);
            this.label327.TabIndex = 150;
            this.label327.Text = "4";
            this.label327.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label329
            // 
            this.label329.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label329.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label329.ForeColor = System.Drawing.Color.Gray;
            this.label329.Location = new System.Drawing.Point(345, 245);
            this.label329.Name = "label329";
            this.label329.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label329.Size = new System.Drawing.Size(70, 50);
            this.label329.TabIndex = 148;
            this.label329.Text = "7";
            this.label329.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label331
            // 
            this.label331.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label331.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label331.ForeColor = System.Drawing.Color.Gray;
            this.label331.Location = new System.Drawing.Point(276, 245);
            this.label331.Name = "label331";
            this.label331.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label331.Size = new System.Drawing.Size(70, 50);
            this.label331.TabIndex = 147;
            this.label331.Text = "6";
            this.label331.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label333
            // 
            this.label333.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label333.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label333.ForeColor = System.Drawing.Color.Gray;
            this.label333.Location = new System.Drawing.Point(414, 245);
            this.label333.Name = "label333";
            this.label333.Size = new System.Drawing.Size(70, 50);
            this.label333.TabIndex = 149;
            this.label333.Text = "8";
            this.label333.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label343
            // 
            this.label343.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label343.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label343.ForeColor = System.Drawing.Color.Gray;
            this.label343.Location = new System.Drawing.Point(138, 0);
            this.label343.Name = "label343";
            this.label343.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label343.Size = new System.Drawing.Size(70, 50);
            this.label343.TabIndex = 158;
            this.label343.Text = "31";
            this.label343.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label344
            // 
            this.label344.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label344.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label344.ForeColor = System.Drawing.Color.Gray;
            this.label344.Location = new System.Drawing.Point(0, 0);
            this.label344.Name = "label344";
            this.label344.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label344.Size = new System.Drawing.Size(70, 50);
            this.label344.TabIndex = 157;
            this.label344.Text = "29";
            this.label344.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label338
            // 
            this.label338.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label338.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label338.ForeColor = System.Drawing.Color.Gray;
            this.label338.Location = new System.Drawing.Point(414, 196);
            this.label338.Name = "label338";
            this.label338.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label338.Size = new System.Drawing.Size(70, 50);
            this.label338.TabIndex = 146;
            this.label338.Text = "1";
            this.label338.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label361
            // 
            this.label361.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label361.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label361.ForeColor = System.Drawing.Color.Gray;
            this.label361.Location = new System.Drawing.Point(69, 0);
            this.label361.Name = "label361";
            this.label361.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label361.Size = new System.Drawing.Size(70, 50);
            this.label361.TabIndex = 156;
            this.label361.Text = "30";
            this.label361.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label362
            // 
            this.label362.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label362.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label362.Location = new System.Drawing.Point(0, 343);
            this.label362.Name = "label362";
            this.label362.Size = new System.Drawing.Size(486, 10);
            this.label362.TabIndex = 113;
            // 
            // heading8
            // 
            this.heading8.Location = new System.Drawing.Point(1, 1);
            this.heading8.Name = "heading8";
            this.heading8.Size = new System.Drawing.Size(484, 58);
            this.heading8.TabIndex = 119;
            // 
            // September
            // 
            this.September.Controls.Add(this.Sep);
            this.September.Controls.Add(this.button37);
            this.September.Controls.Add(this.button40);
            this.September.Controls.Add(this.panel9);
            this.September.Controls.Add(this.label408);
            this.September.Controls.Add(this.heading9);
            this.September.Location = new System.Drawing.Point(1, 70);
            this.September.Name = "September";
            this.September.Size = new System.Drawing.Size(486, 353);
            this.September.TabIndex = 237;
            // 
            // Sep
            // 
            this.Sep.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Sep.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Sep.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Sep.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Sep.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Sep.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Sep.Location = new System.Drawing.Point(139, 0);
            this.Sep.Name = "Sep";
            this.Sep.Size = new System.Drawing.Size(208, 39);
            this.Sep.TabIndex = 160;
            this.Sep.TabStop = false;
            this.Sep.Text = "September";
            this.Sep.UseVisualStyleBackColor = false;
            this.Sep.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button37.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button37.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button37.FlatAppearance.BorderSize = 0;
            this.button37.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(452, 4);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(30, 30);
            this.button37.TabIndex = 122;
            this.button37.TabStop = false;
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button40.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button40.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button40.FlatAppearance.BorderSize = 0;
            this.button40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(5, 4);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(30, 30);
            this.button40.TabIndex = 121;
            this.button40.TabStop = false;
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.button296);
            this.panel9.Controls.Add(this.button293);
            this.panel9.Controls.Add(this.button290);
            this.panel9.Controls.Add(this.button294);
            this.panel9.Controls.Add(this.button291);
            this.panel9.Controls.Add(this.button286);
            this.panel9.Controls.Add(this.button292);
            this.panel9.Controls.Add(this.button283);
            this.panel9.Controls.Add(this.button289);
            this.panel9.Controls.Add(this.button287);
            this.panel9.Controls.Add(this.button281);
            this.panel9.Controls.Add(this.button288);
            this.panel9.Controls.Add(this.button284);
            this.panel9.Controls.Add(this.button285);
            this.panel9.Controls.Add(this.button282);
            this.panel9.Controls.Add(this.button276);
            this.panel9.Controls.Add(this.button274);
            this.panel9.Controls.Add(this.button277);
            this.panel9.Controls.Add(this.button278);
            this.panel9.Controls.Add(this.button275);
            this.panel9.Controls.Add(this.button279);
            this.panel9.Controls.Add(this.button269);
            this.panel9.Controls.Add(this.button280);
            this.panel9.Controls.Add(this.button267);
            this.panel9.Controls.Add(this.button270);
            this.panel9.Controls.Add(this.button268);
            this.panel9.Controls.Add(this.button271);
            this.panel9.Controls.Add(this.button266);
            this.panel9.Controls.Add(this.button272);
            this.panel9.Controls.Add(this.button273);
            this.panel9.Controls.Add(this.label365);
            this.panel9.Controls.Add(this.label368);
            this.panel9.Controls.Add(this.label384);
            this.panel9.Controls.Add(this.label388);
            this.panel9.Controls.Add(this.label389);
            this.panel9.Controls.Add(this.label391);
            this.panel9.Controls.Add(this.label411);
            this.panel9.Controls.Add(this.label369);
            this.panel9.Controls.Add(this.label375);
            this.panel9.Controls.Add(this.label379);
            this.panel9.Controls.Add(this.label381);
            this.panel9.Controls.Add(this.label383);
            this.panel9.Controls.Add(this.label385);
            this.panel9.Location = new System.Drawing.Point(1, 58);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(484, 295);
            this.panel9.TabIndex = 124;
            // 
            // button296
            // 
            this.button296.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button296.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button296.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button296.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button296.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button296.Location = new System.Drawing.Point(0, 245);
            this.button296.Name = "button296";
            this.button296.Size = new System.Drawing.Size(70, 50);
            this.button296.TabIndex = 249;
            this.button296.TabStop = false;
            this.button296.Text = "30";
            this.button296.UseCompatibleTextRendering = true;
            this.button296.UseVisualStyleBackColor = true;
            this.button296.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button293
            // 
            this.button293.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button293.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button293.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button293.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button293.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button293.Location = new System.Drawing.Point(345, 196);
            this.button293.Name = "button293";
            this.button293.Size = new System.Drawing.Size(70, 50);
            this.button293.TabIndex = 201;
            this.button293.TabStop = false;
            this.button293.Text = "28";
            this.button293.UseCompatibleTextRendering = true;
            this.button293.UseVisualStyleBackColor = true;
            this.button293.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button290
            // 
            this.button290.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button290.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button290.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button290.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button290.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button290.Location = new System.Drawing.Point(276, 196);
            this.button290.Name = "button290";
            this.button290.Size = new System.Drawing.Size(70, 50);
            this.button290.TabIndex = 246;
            this.button290.TabStop = false;
            this.button290.Text = "27";
            this.button290.UseCompatibleTextRendering = true;
            this.button290.UseVisualStyleBackColor = true;
            this.button290.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button294
            // 
            this.button294.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button294.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button294.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button294.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button294.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button294.Location = new System.Drawing.Point(414, 196);
            this.button294.Name = "button294";
            this.button294.Size = new System.Drawing.Size(70, 50);
            this.button294.TabIndex = 200;
            this.button294.TabStop = false;
            this.button294.Text = "29";
            this.button294.UseCompatibleTextRendering = true;
            this.button294.UseVisualStyleBackColor = true;
            this.button294.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button291
            // 
            this.button291.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button291.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button291.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button291.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button291.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button291.Location = new System.Drawing.Point(207, 196);
            this.button291.Name = "button291";
            this.button291.Size = new System.Drawing.Size(70, 50);
            this.button291.TabIndex = 245;
            this.button291.TabStop = false;
            this.button291.Text = "26";
            this.button291.UseCompatibleTextRendering = true;
            this.button291.UseVisualStyleBackColor = true;
            this.button291.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button286
            // 
            this.button286.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button286.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button286.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button286.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button286.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button286.Location = new System.Drawing.Point(345, 147);
            this.button286.Name = "button286";
            this.button286.Size = new System.Drawing.Size(70, 50);
            this.button286.TabIndex = 199;
            this.button286.TabStop = false;
            this.button286.Text = "21";
            this.button286.UseCompatibleTextRendering = true;
            this.button286.UseVisualStyleBackColor = true;
            this.button286.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button292
            // 
            this.button292.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button292.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button292.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button292.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button292.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button292.Location = new System.Drawing.Point(138, 196);
            this.button292.Name = "button292";
            this.button292.Size = new System.Drawing.Size(70, 50);
            this.button292.TabIndex = 244;
            this.button292.TabStop = false;
            this.button292.Text = "25";
            this.button292.UseCompatibleTextRendering = true;
            this.button292.UseVisualStyleBackColor = true;
            this.button292.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button283
            // 
            this.button283.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button283.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button283.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button283.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button283.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button283.Location = new System.Drawing.Point(276, 147);
            this.button283.Name = "button283";
            this.button283.Size = new System.Drawing.Size(70, 50);
            this.button283.TabIndex = 191;
            this.button283.TabStop = false;
            this.button283.Text = "20";
            this.button283.UseCompatibleTextRendering = true;
            this.button283.UseVisualStyleBackColor = true;
            this.button283.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button289
            // 
            this.button289.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button289.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button289.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button289.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button289.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button289.Location = new System.Drawing.Point(414, 147);
            this.button289.Name = "button289";
            this.button289.Size = new System.Drawing.Size(70, 50);
            this.button289.TabIndex = 196;
            this.button289.TabStop = false;
            this.button289.Text = "22";
            this.button289.UseCompatibleTextRendering = true;
            this.button289.UseVisualStyleBackColor = true;
            this.button289.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button287
            // 
            this.button287.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button287.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button287.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button287.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button287.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button287.Location = new System.Drawing.Point(69, 196);
            this.button287.Name = "button287";
            this.button287.Size = new System.Drawing.Size(70, 50);
            this.button287.TabIndex = 198;
            this.button287.TabStop = false;
            this.button287.Text = "24";
            this.button287.UseCompatibleTextRendering = true;
            this.button287.UseVisualStyleBackColor = true;
            this.button287.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button281
            // 
            this.button281.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button281.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button281.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button281.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button281.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button281.Location = new System.Drawing.Point(69, 147);
            this.button281.Name = "button281";
            this.button281.Size = new System.Drawing.Size(70, 50);
            this.button281.TabIndex = 217;
            this.button281.TabStop = false;
            this.button281.Text = "17";
            this.button281.UseCompatibleTextRendering = true;
            this.button281.UseVisualStyleBackColor = true;
            this.button281.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button288
            // 
            this.button288.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button288.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button288.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button288.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button288.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button288.Location = new System.Drawing.Point(0, 196);
            this.button288.Name = "button288";
            this.button288.Size = new System.Drawing.Size(70, 50);
            this.button288.TabIndex = 197;
            this.button288.TabStop = false;
            this.button288.Text = "23";
            this.button288.UseCompatibleTextRendering = true;
            this.button288.UseVisualStyleBackColor = true;
            this.button288.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button284
            // 
            this.button284.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button284.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button284.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button284.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button284.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button284.Location = new System.Drawing.Point(207, 147);
            this.button284.Name = "button284";
            this.button284.Size = new System.Drawing.Size(70, 50);
            this.button284.TabIndex = 190;
            this.button284.TabStop = false;
            this.button284.Text = "19";
            this.button284.UseCompatibleTextRendering = true;
            this.button284.UseVisualStyleBackColor = true;
            this.button284.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button285
            // 
            this.button285.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button285.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button285.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button285.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button285.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button285.Location = new System.Drawing.Point(138, 147);
            this.button285.Name = "button285";
            this.button285.Size = new System.Drawing.Size(70, 50);
            this.button285.TabIndex = 189;
            this.button285.TabStop = false;
            this.button285.Text = "18";
            this.button285.UseCompatibleTextRendering = true;
            this.button285.UseVisualStyleBackColor = true;
            this.button285.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button282
            // 
            this.button282.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button282.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button282.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button282.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button282.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button282.Location = new System.Drawing.Point(0, 147);
            this.button282.Name = "button282";
            this.button282.Size = new System.Drawing.Size(70, 50);
            this.button282.TabIndex = 216;
            this.button282.TabStop = false;
            this.button282.Text = "16";
            this.button282.UseCompatibleTextRendering = true;
            this.button282.UseVisualStyleBackColor = true;
            this.button282.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button276
            // 
            this.button276.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button276.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button276.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button276.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button276.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button276.Location = new System.Drawing.Point(345, 98);
            this.button276.Name = "button276";
            this.button276.Size = new System.Drawing.Size(70, 50);
            this.button276.TabIndex = 221;
            this.button276.TabStop = false;
            this.button276.Text = "14";
            this.button276.UseCompatibleTextRendering = true;
            this.button276.UseVisualStyleBackColor = true;
            this.button276.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button274
            // 
            this.button274.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button274.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button274.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button274.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button274.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button274.Location = new System.Drawing.Point(69, 98);
            this.button274.Name = "button274";
            this.button274.Size = new System.Drawing.Size(70, 50);
            this.button274.TabIndex = 245;
            this.button274.TabStop = false;
            this.button274.Text = "10";
            this.button274.UseCompatibleTextRendering = true;
            this.button274.UseVisualStyleBackColor = true;
            this.button274.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button277
            // 
            this.button277.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button277.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button277.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button277.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button277.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button277.Location = new System.Drawing.Point(414, 98);
            this.button277.Name = "button277";
            this.button277.Size = new System.Drawing.Size(70, 50);
            this.button277.TabIndex = 220;
            this.button277.TabStop = false;
            this.button277.Text = "15";
            this.button277.UseCompatibleTextRendering = true;
            this.button277.UseVisualStyleBackColor = true;
            this.button277.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button278
            // 
            this.button278.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button278.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button278.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button278.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button278.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button278.Location = new System.Drawing.Point(276, 98);
            this.button278.Name = "button278";
            this.button278.Size = new System.Drawing.Size(70, 50);
            this.button278.TabIndex = 219;
            this.button278.TabStop = false;
            this.button278.Text = "13";
            this.button278.UseCompatibleTextRendering = true;
            this.button278.UseVisualStyleBackColor = true;
            this.button278.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button275
            // 
            this.button275.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button275.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button275.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button275.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button275.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button275.Location = new System.Drawing.Point(0, 98);
            this.button275.Name = "button275";
            this.button275.Size = new System.Drawing.Size(70, 50);
            this.button275.TabIndex = 244;
            this.button275.TabStop = false;
            this.button275.Text = "9";
            this.button275.UseCompatibleTextRendering = true;
            this.button275.UseVisualStyleBackColor = true;
            this.button275.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button279
            // 
            this.button279.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button279.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button279.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button279.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button279.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button279.Location = new System.Drawing.Point(207, 98);
            this.button279.Name = "button279";
            this.button279.Size = new System.Drawing.Size(70, 50);
            this.button279.TabIndex = 218;
            this.button279.TabStop = false;
            this.button279.Text = "12";
            this.button279.UseCompatibleTextRendering = true;
            this.button279.UseVisualStyleBackColor = true;
            this.button279.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button269
            // 
            this.button269.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button269.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button269.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button269.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button269.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button269.Location = new System.Drawing.Point(345, 49);
            this.button269.Name = "button269";
            this.button269.Size = new System.Drawing.Size(70, 50);
            this.button269.TabIndex = 248;
            this.button269.TabStop = false;
            this.button269.Text = "7";
            this.button269.UseCompatibleTextRendering = true;
            this.button269.UseVisualStyleBackColor = true;
            this.button269.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button280
            // 
            this.button280.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button280.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button280.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button280.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button280.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button280.Location = new System.Drawing.Point(138, 98);
            this.button280.Name = "button280";
            this.button280.Size = new System.Drawing.Size(70, 50);
            this.button280.TabIndex = 217;
            this.button280.TabStop = false;
            this.button280.Text = "11";
            this.button280.UseCompatibleTextRendering = true;
            this.button280.UseVisualStyleBackColor = true;
            this.button280.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button267
            // 
            this.button267.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button267.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button267.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button267.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button267.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button267.Location = new System.Drawing.Point(69, 49);
            this.button267.Name = "button267";
            this.button267.Size = new System.Drawing.Size(70, 50);
            this.button267.TabIndex = 245;
            this.button267.TabStop = false;
            this.button267.Text = "3";
            this.button267.UseCompatibleTextRendering = true;
            this.button267.UseVisualStyleBackColor = true;
            this.button267.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button270
            // 
            this.button270.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button270.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button270.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button270.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button270.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button270.Location = new System.Drawing.Point(276, 49);
            this.button270.Name = "button270";
            this.button270.Size = new System.Drawing.Size(70, 50);
            this.button270.TabIndex = 246;
            this.button270.TabStop = false;
            this.button270.Text = "6";
            this.button270.UseCompatibleTextRendering = true;
            this.button270.UseVisualStyleBackColor = true;
            this.button270.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button268
            // 
            this.button268.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button268.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button268.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button268.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button268.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button268.Location = new System.Drawing.Point(0, 49);
            this.button268.Name = "button268";
            this.button268.Size = new System.Drawing.Size(70, 50);
            this.button268.TabIndex = 244;
            this.button268.TabStop = false;
            this.button268.Text = "2";
            this.button268.UseCompatibleTextRendering = true;
            this.button268.UseVisualStyleBackColor = true;
            this.button268.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button271
            // 
            this.button271.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button271.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button271.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button271.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button271.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button271.Location = new System.Drawing.Point(207, 49);
            this.button271.Name = "button271";
            this.button271.Size = new System.Drawing.Size(70, 50);
            this.button271.TabIndex = 245;
            this.button271.TabStop = false;
            this.button271.Text = "5";
            this.button271.UseCompatibleTextRendering = true;
            this.button271.UseVisualStyleBackColor = true;
            this.button271.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button266
            // 
            this.button266.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button266.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button266.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button266.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button266.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button266.Location = new System.Drawing.Point(414, 0);
            this.button266.Name = "button266";
            this.button266.Size = new System.Drawing.Size(70, 50);
            this.button266.TabIndex = 244;
            this.button266.TabStop = false;
            this.button266.Text = "1";
            this.button266.UseCompatibleTextRendering = true;
            this.button266.UseVisualStyleBackColor = true;
            this.button266.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button272
            // 
            this.button272.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button272.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button272.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button272.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button272.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button272.Location = new System.Drawing.Point(414, 49);
            this.button272.Name = "button272";
            this.button272.Size = new System.Drawing.Size(70, 50);
            this.button272.TabIndex = 247;
            this.button272.TabStop = false;
            this.button272.Text = "8";
            this.button272.UseCompatibleTextRendering = true;
            this.button272.UseVisualStyleBackColor = true;
            this.button272.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button273
            // 
            this.button273.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button273.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button273.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button273.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button273.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button273.Location = new System.Drawing.Point(138, 49);
            this.button273.Name = "button273";
            this.button273.Size = new System.Drawing.Size(70, 50);
            this.button273.TabIndex = 244;
            this.button273.TabStop = false;
            this.button273.Text = "4";
            this.button273.UseCompatibleTextRendering = true;
            this.button273.UseVisualStyleBackColor = true;
            this.button273.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label365
            // 
            this.label365.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label365.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label365.ForeColor = System.Drawing.Color.Gray;
            this.label365.Location = new System.Drawing.Point(276, 0);
            this.label365.Name = "label365";
            this.label365.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label365.Size = new System.Drawing.Size(70, 50);
            this.label365.TabIndex = 168;
            this.label365.Text = "30";
            this.label365.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label368
            // 
            this.label368.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label368.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label368.ForeColor = System.Drawing.Color.Black;
            this.label368.Location = new System.Drawing.Point(276, 0);
            this.label368.Name = "label368";
            this.label368.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label368.Size = new System.Drawing.Size(70, 50);
            this.label368.TabIndex = 169;
            this.label368.Text = "30";
            this.label368.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label384
            // 
            this.label384.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label384.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label384.ForeColor = System.Drawing.Color.Gray;
            this.label384.Location = new System.Drawing.Point(345, 0);
            this.label384.Name = "label384";
            this.label384.Size = new System.Drawing.Size(70, 50);
            this.label384.TabIndex = 159;
            this.label384.Text = "31";
            this.label384.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label388
            // 
            this.label388.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label388.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label388.ForeColor = System.Drawing.Color.Gray;
            this.label388.Location = new System.Drawing.Point(207, 0);
            this.label388.Name = "label388";
            this.label388.Size = new System.Drawing.Size(70, 50);
            this.label388.TabIndex = 155;
            this.label388.Text = "29";
            this.label388.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label389
            // 
            this.label389.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label389.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label389.ForeColor = System.Drawing.Color.Gray;
            this.label389.Location = new System.Drawing.Point(138, 0);
            this.label389.Name = "label389";
            this.label389.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label389.Size = new System.Drawing.Size(70, 50);
            this.label389.TabIndex = 158;
            this.label389.Text = "28";
            this.label389.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label391
            // 
            this.label391.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label391.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label391.ForeColor = System.Drawing.Color.Gray;
            this.label391.Location = new System.Drawing.Point(0, 0);
            this.label391.Name = "label391";
            this.label391.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label391.Size = new System.Drawing.Size(70, 50);
            this.label391.TabIndex = 157;
            this.label391.Text = "26";
            this.label391.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label411
            // 
            this.label411.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label411.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label411.ForeColor = System.Drawing.Color.Gray;
            this.label411.Location = new System.Drawing.Point(69, 0);
            this.label411.Name = "label411";
            this.label411.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label411.Size = new System.Drawing.Size(70, 50);
            this.label411.TabIndex = 156;
            this.label411.Text = "27";
            this.label411.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label369
            // 
            this.label369.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label369.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label369.ForeColor = System.Drawing.Color.Gray;
            this.label369.Location = new System.Drawing.Point(207, 245);
            this.label369.Name = "label369";
            this.label369.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label369.Size = new System.Drawing.Size(70, 50);
            this.label369.TabIndex = 153;
            this.label369.Text = "3";
            this.label369.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label375
            // 
            this.label375.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label375.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label375.ForeColor = System.Drawing.Color.Gray;
            this.label375.Location = new System.Drawing.Point(69, 245);
            this.label375.Name = "label375";
            this.label375.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label375.Size = new System.Drawing.Size(70, 50);
            this.label375.TabIndex = 151;
            this.label375.Text = "1";
            this.label375.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label379
            // 
            this.label379.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label379.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label379.ForeColor = System.Drawing.Color.Gray;
            this.label379.Location = new System.Drawing.Point(138, 245);
            this.label379.Name = "label379";
            this.label379.Size = new System.Drawing.Size(70, 50);
            this.label379.TabIndex = 150;
            this.label379.Text = "2";
            this.label379.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label381
            // 
            this.label381.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label381.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label381.ForeColor = System.Drawing.Color.Gray;
            this.label381.Location = new System.Drawing.Point(345, 245);
            this.label381.Name = "label381";
            this.label381.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label381.Size = new System.Drawing.Size(70, 50);
            this.label381.TabIndex = 148;
            this.label381.Text = "5";
            this.label381.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label383
            // 
            this.label383.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label383.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label383.ForeColor = System.Drawing.Color.Gray;
            this.label383.Location = new System.Drawing.Point(276, 245);
            this.label383.Name = "label383";
            this.label383.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label383.Size = new System.Drawing.Size(70, 50);
            this.label383.TabIndex = 147;
            this.label383.Text = "4";
            this.label383.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label385
            // 
            this.label385.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label385.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label385.ForeColor = System.Drawing.Color.Gray;
            this.label385.Location = new System.Drawing.Point(414, 245);
            this.label385.Name = "label385";
            this.label385.Size = new System.Drawing.Size(70, 50);
            this.label385.TabIndex = 149;
            this.label385.Text = "6";
            this.label385.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label408
            // 
            this.label408.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label408.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label408.Location = new System.Drawing.Point(0, 343);
            this.label408.Name = "label408";
            this.label408.Size = new System.Drawing.Size(486, 10);
            this.label408.TabIndex = 113;
            // 
            // heading9
            // 
            this.heading9.Location = new System.Drawing.Point(1, 1);
            this.heading9.Name = "heading9";
            this.heading9.Size = new System.Drawing.Size(484, 58);
            this.heading9.TabIndex = 119;
            // 
            // October
            // 
            this.October.Controls.Add(this.Oct);
            this.October.Controls.Add(this.button42);
            this.October.Controls.Add(this.button45);
            this.October.Controls.Add(this.panel10);
            this.October.Controls.Add(this.heading10);
            this.October.Location = new System.Drawing.Point(1, 70);
            this.October.Name = "October";
            this.October.Size = new System.Drawing.Size(486, 353);
            this.October.TabIndex = 238;
            // 
            // Oct
            // 
            this.Oct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Oct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Oct.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Oct.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Oct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Oct.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Oct.Location = new System.Drawing.Point(139, 0);
            this.Oct.Name = "Oct";
            this.Oct.Size = new System.Drawing.Size(208, 39);
            this.Oct.TabIndex = 161;
            this.Oct.TabStop = false;
            this.Oct.Text = "October";
            this.Oct.UseVisualStyleBackColor = false;
            this.Oct.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button42.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button42.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button42.FlatAppearance.BorderSize = 0;
            this.button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.button42.Location = new System.Drawing.Point(452, 4);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(30, 30);
            this.button42.TabIndex = 122;
            this.button42.TabStop = false;
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button45.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button45.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button45.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button45.FlatAppearance.BorderSize = 0;
            this.button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.White;
            this.button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.ForeColor = System.Drawing.SystemColors.ActiveBorder;
            this.button45.Location = new System.Drawing.Point(5, 4);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(30, 30);
            this.button45.TabIndex = 121;
            this.button45.TabStop = false;
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.button323);
            this.panel10.Controls.Add(this.button316);
            this.panel10.Controls.Add(this.button324);
            this.panel10.Controls.Add(this.button325);
            this.panel10.Controls.Add(this.button317);
            this.panel10.Controls.Add(this.button326);
            this.panel10.Controls.Add(this.button318);
            this.panel10.Controls.Add(this.button319);
            this.panel10.Controls.Add(this.button320);
            this.panel10.Controls.Add(this.button321);
            this.panel10.Controls.Add(this.button322);
            this.panel10.Controls.Add(this.button313);
            this.panel10.Controls.Add(this.button314);
            this.panel10.Controls.Add(this.button315);
            this.panel10.Controls.Add(this.button309);
            this.panel10.Controls.Add(this.button306);
            this.panel10.Controls.Add(this.button310);
            this.panel10.Controls.Add(this.button311);
            this.panel10.Controls.Add(this.button307);
            this.panel10.Controls.Add(this.button312);
            this.panel10.Controls.Add(this.button302);
            this.panel10.Controls.Add(this.button308);
            this.panel10.Controls.Add(this.button299);
            this.panel10.Controls.Add(this.button303);
            this.panel10.Controls.Add(this.button304);
            this.panel10.Controls.Add(this.button300);
            this.panel10.Controls.Add(this.button305);
            this.panel10.Controls.Add(this.button295);
            this.panel10.Controls.Add(this.button301);
            this.panel10.Controls.Add(this.label414);
            this.panel10.Controls.Add(this.button297);
            this.panel10.Controls.Add(this.button298);
            this.panel10.Controls.Add(this.label428);
            this.panel10.Controls.Add(this.label429);
            this.panel10.Controls.Add(this.label430);
            this.panel10.Controls.Add(this.label432);
            this.panel10.Controls.Add(this.label434);
            this.panel10.Controls.Add(this.label435);
            this.panel10.Controls.Add(this.label436);
            this.panel10.Controls.Add(this.label437);
            this.panel10.Controls.Add(this.label438);
            this.panel10.Controls.Add(this.label439);
            this.panel10.Location = new System.Drawing.Point(1, 58);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(484, 295);
            this.panel10.TabIndex = 124;
            // 
            // button323
            // 
            this.button323.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button323.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button323.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button323.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button323.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button323.Location = new System.Drawing.Point(0, 196);
            this.button323.Name = "button323";
            this.button323.Size = new System.Drawing.Size(70, 50);
            this.button323.TabIndex = 247;
            this.button323.TabStop = false;
            this.button323.Text = "28";
            this.button323.UseCompatibleTextRendering = true;
            this.button323.UseVisualStyleBackColor = true;
            this.button323.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button316
            // 
            this.button316.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button316.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button316.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button316.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button316.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button316.Location = new System.Drawing.Point(0, 147);
            this.button316.Name = "button316";
            this.button316.Size = new System.Drawing.Size(70, 50);
            this.button316.TabIndex = 257;
            this.button316.TabStop = false;
            this.button316.Text = "21";
            this.button316.UseCompatibleTextRendering = true;
            this.button316.UseVisualStyleBackColor = true;
            this.button316.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button324
            // 
            this.button324.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button324.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button324.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button324.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button324.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button324.Location = new System.Drawing.Point(207, 196);
            this.button324.Name = "button324";
            this.button324.Size = new System.Drawing.Size(70, 50);
            this.button324.TabIndex = 246;
            this.button324.TabStop = false;
            this.button324.Text = "31";
            this.button324.UseCompatibleTextRendering = true;
            this.button324.UseVisualStyleBackColor = true;
            this.button324.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button325
            // 
            this.button325.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button325.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button325.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button325.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button325.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button325.Location = new System.Drawing.Point(138, 196);
            this.button325.Name = "button325";
            this.button325.Size = new System.Drawing.Size(70, 50);
            this.button325.TabIndex = 245;
            this.button325.TabStop = false;
            this.button325.Text = "30";
            this.button325.UseCompatibleTextRendering = true;
            this.button325.UseVisualStyleBackColor = true;
            this.button325.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button317
            // 
            this.button317.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button317.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button317.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button317.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button317.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button317.Location = new System.Drawing.Point(414, 147);
            this.button317.Name = "button317";
            this.button317.Size = new System.Drawing.Size(70, 50);
            this.button317.TabIndex = 256;
            this.button317.TabStop = false;
            this.button317.Text = "27";
            this.button317.UseCompatibleTextRendering = true;
            this.button317.UseVisualStyleBackColor = true;
            this.button317.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button326
            // 
            this.button326.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button326.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button326.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button326.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button326.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button326.Location = new System.Drawing.Point(69, 196);
            this.button326.Name = "button326";
            this.button326.Size = new System.Drawing.Size(70, 50);
            this.button326.TabIndex = 244;
            this.button326.TabStop = false;
            this.button326.Text = "29";
            this.button326.UseCompatibleTextRendering = true;
            this.button326.UseVisualStyleBackColor = true;
            this.button326.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button318
            // 
            this.button318.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button318.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button318.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button318.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button318.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button318.Location = new System.Drawing.Point(345, 147);
            this.button318.Name = "button318";
            this.button318.Size = new System.Drawing.Size(70, 50);
            this.button318.TabIndex = 255;
            this.button318.TabStop = false;
            this.button318.Text = "26";
            this.button318.UseCompatibleTextRendering = true;
            this.button318.UseVisualStyleBackColor = true;
            this.button318.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button319
            // 
            this.button319.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button319.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button319.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button319.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button319.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button319.Location = new System.Drawing.Point(276, 147);
            this.button319.Name = "button319";
            this.button319.Size = new System.Drawing.Size(70, 50);
            this.button319.TabIndex = 254;
            this.button319.TabStop = false;
            this.button319.Text = "25";
            this.button319.UseCompatibleTextRendering = true;
            this.button319.UseVisualStyleBackColor = true;
            this.button319.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button320
            // 
            this.button320.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button320.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button320.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button320.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button320.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button320.Location = new System.Drawing.Point(207, 147);
            this.button320.Name = "button320";
            this.button320.Size = new System.Drawing.Size(70, 50);
            this.button320.TabIndex = 253;
            this.button320.TabStop = false;
            this.button320.Text = "24";
            this.button320.UseCompatibleTextRendering = true;
            this.button320.UseVisualStyleBackColor = true;
            this.button320.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button321
            // 
            this.button321.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button321.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button321.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button321.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button321.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button321.Location = new System.Drawing.Point(138, 147);
            this.button321.Name = "button321";
            this.button321.Size = new System.Drawing.Size(70, 50);
            this.button321.TabIndex = 252;
            this.button321.TabStop = false;
            this.button321.Text = "23";
            this.button321.UseCompatibleTextRendering = true;
            this.button321.UseVisualStyleBackColor = true;
            this.button321.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button322
            // 
            this.button322.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button322.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button322.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button322.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button322.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button322.Location = new System.Drawing.Point(69, 147);
            this.button322.Name = "button322";
            this.button322.Size = new System.Drawing.Size(70, 50);
            this.button322.TabIndex = 251;
            this.button322.TabStop = false;
            this.button322.Text = "22";
            this.button322.UseCompatibleTextRendering = true;
            this.button322.UseVisualStyleBackColor = true;
            this.button322.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button313
            // 
            this.button313.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button313.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button313.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button313.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button313.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button313.Location = new System.Drawing.Point(414, 98);
            this.button313.Name = "button313";
            this.button313.Size = new System.Drawing.Size(70, 50);
            this.button313.TabIndex = 250;
            this.button313.TabStop = false;
            this.button313.Text = "20";
            this.button313.UseCompatibleTextRendering = true;
            this.button313.UseVisualStyleBackColor = true;
            this.button313.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button314
            // 
            this.button314.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button314.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button314.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button314.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button314.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button314.Location = new System.Drawing.Point(345, 98);
            this.button314.Name = "button314";
            this.button314.Size = new System.Drawing.Size(70, 50);
            this.button314.TabIndex = 249;
            this.button314.TabStop = false;
            this.button314.Text = "19";
            this.button314.UseCompatibleTextRendering = true;
            this.button314.UseVisualStyleBackColor = true;
            this.button314.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button315
            // 
            this.button315.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button315.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button315.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button315.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button315.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button315.Location = new System.Drawing.Point(276, 98);
            this.button315.Name = "button315";
            this.button315.Size = new System.Drawing.Size(70, 50);
            this.button315.TabIndex = 248;
            this.button315.TabStop = false;
            this.button315.Text = "18";
            this.button315.UseCompatibleTextRendering = true;
            this.button315.UseVisualStyleBackColor = true;
            this.button315.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button309
            // 
            this.button309.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button309.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button309.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button309.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button309.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button309.Location = new System.Drawing.Point(0, 98);
            this.button309.Name = "button309";
            this.button309.Size = new System.Drawing.Size(70, 50);
            this.button309.TabIndex = 247;
            this.button309.TabStop = false;
            this.button309.Text = "14";
            this.button309.UseCompatibleTextRendering = true;
            this.button309.UseVisualStyleBackColor = true;
            this.button309.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button306
            // 
            this.button306.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button306.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button306.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button306.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button306.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button306.Location = new System.Drawing.Point(414, 49);
            this.button306.Name = "button306";
            this.button306.Size = new System.Drawing.Size(70, 50);
            this.button306.TabIndex = 246;
            this.button306.TabStop = false;
            this.button306.Text = "13";
            this.button306.UseCompatibleTextRendering = true;
            this.button306.UseVisualStyleBackColor = true;
            this.button306.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button310
            // 
            this.button310.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button310.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button310.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button310.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button310.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button310.Location = new System.Drawing.Point(207, 98);
            this.button310.Name = "button310";
            this.button310.Size = new System.Drawing.Size(70, 50);
            this.button310.TabIndex = 246;
            this.button310.TabStop = false;
            this.button310.Text = "17";
            this.button310.UseCompatibleTextRendering = true;
            this.button310.UseVisualStyleBackColor = true;
            this.button310.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button311
            // 
            this.button311.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button311.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button311.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button311.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button311.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button311.Location = new System.Drawing.Point(138, 98);
            this.button311.Name = "button311";
            this.button311.Size = new System.Drawing.Size(70, 50);
            this.button311.TabIndex = 245;
            this.button311.TabStop = false;
            this.button311.Text = "16";
            this.button311.UseCompatibleTextRendering = true;
            this.button311.UseVisualStyleBackColor = true;
            this.button311.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button307
            // 
            this.button307.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button307.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button307.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button307.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button307.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button307.Location = new System.Drawing.Point(345, 49);
            this.button307.Name = "button307";
            this.button307.Size = new System.Drawing.Size(70, 50);
            this.button307.TabIndex = 245;
            this.button307.TabStop = false;
            this.button307.Text = "12";
            this.button307.UseCompatibleTextRendering = true;
            this.button307.UseVisualStyleBackColor = true;
            this.button307.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button312
            // 
            this.button312.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button312.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button312.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button312.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button312.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button312.Location = new System.Drawing.Point(69, 98);
            this.button312.Name = "button312";
            this.button312.Size = new System.Drawing.Size(70, 50);
            this.button312.TabIndex = 244;
            this.button312.TabStop = false;
            this.button312.Text = "15";
            this.button312.UseCompatibleTextRendering = true;
            this.button312.UseVisualStyleBackColor = true;
            this.button312.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button302
            // 
            this.button302.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button302.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button302.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button302.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button302.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button302.Location = new System.Drawing.Point(0, 49);
            this.button302.Name = "button302";
            this.button302.Size = new System.Drawing.Size(70, 50);
            this.button302.TabIndex = 247;
            this.button302.TabStop = false;
            this.button302.Text = "7";
            this.button302.UseCompatibleTextRendering = true;
            this.button302.UseVisualStyleBackColor = true;
            this.button302.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button308
            // 
            this.button308.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button308.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button308.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button308.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button308.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button308.Location = new System.Drawing.Point(276, 49);
            this.button308.Name = "button308";
            this.button308.Size = new System.Drawing.Size(70, 50);
            this.button308.TabIndex = 244;
            this.button308.TabStop = false;
            this.button308.Text = "11";
            this.button308.UseCompatibleTextRendering = true;
            this.button308.UseVisualStyleBackColor = true;
            this.button308.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button299
            // 
            this.button299.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button299.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button299.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button299.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button299.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button299.Location = new System.Drawing.Point(414, 0);
            this.button299.Name = "button299";
            this.button299.Size = new System.Drawing.Size(70, 50);
            this.button299.TabIndex = 208;
            this.button299.TabStop = false;
            this.button299.Text = "6";
            this.button299.UseCompatibleTextRendering = true;
            this.button299.UseVisualStyleBackColor = true;
            this.button299.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button303
            // 
            this.button303.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button303.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button303.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button303.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button303.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button303.Location = new System.Drawing.Point(207, 49);
            this.button303.Name = "button303";
            this.button303.Size = new System.Drawing.Size(70, 50);
            this.button303.TabIndex = 246;
            this.button303.TabStop = false;
            this.button303.Text = "10";
            this.button303.UseCompatibleTextRendering = true;
            this.button303.UseVisualStyleBackColor = true;
            this.button303.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button304
            // 
            this.button304.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button304.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button304.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button304.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button304.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button304.Location = new System.Drawing.Point(138, 49);
            this.button304.Name = "button304";
            this.button304.Size = new System.Drawing.Size(70, 50);
            this.button304.TabIndex = 245;
            this.button304.TabStop = false;
            this.button304.Text = "9";
            this.button304.UseCompatibleTextRendering = true;
            this.button304.UseVisualStyleBackColor = true;
            this.button304.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button300
            // 
            this.button300.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button300.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button300.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button300.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button300.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button300.Location = new System.Drawing.Point(345, 0);
            this.button300.Name = "button300";
            this.button300.Size = new System.Drawing.Size(70, 50);
            this.button300.TabIndex = 207;
            this.button300.TabStop = false;
            this.button300.Text = "5";
            this.button300.UseCompatibleTextRendering = true;
            this.button300.UseVisualStyleBackColor = true;
            this.button300.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button305
            // 
            this.button305.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button305.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button305.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button305.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button305.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button305.Location = new System.Drawing.Point(69, 49);
            this.button305.Name = "button305";
            this.button305.Size = new System.Drawing.Size(70, 50);
            this.button305.TabIndex = 244;
            this.button305.TabStop = false;
            this.button305.Text = "8";
            this.button305.UseCompatibleTextRendering = true;
            this.button305.UseVisualStyleBackColor = true;
            this.button305.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button295
            // 
            this.button295.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button295.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button295.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button295.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button295.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button295.Location = new System.Drawing.Point(207, 0);
            this.button295.Name = "button295";
            this.button295.Size = new System.Drawing.Size(70, 50);
            this.button295.TabIndex = 205;
            this.button295.TabStop = false;
            this.button295.Text = "3";
            this.button295.UseCompatibleTextRendering = true;
            this.button295.UseVisualStyleBackColor = true;
            this.button295.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button301
            // 
            this.button301.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button301.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button301.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button301.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button301.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button301.Location = new System.Drawing.Point(276, 0);
            this.button301.Name = "button301";
            this.button301.Size = new System.Drawing.Size(70, 50);
            this.button301.TabIndex = 206;
            this.button301.TabStop = false;
            this.button301.Text = "4";
            this.button301.UseCompatibleTextRendering = true;
            this.button301.UseVisualStyleBackColor = true;
            this.button301.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label414
            // 
            this.label414.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label414.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label414.ForeColor = System.Drawing.Color.Gray;
            this.label414.Location = new System.Drawing.Point(0, 0);
            this.label414.Name = "label414";
            this.label414.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label414.Size = new System.Drawing.Size(70, 50);
            this.label414.TabIndex = 173;
            this.label414.Text = "30";
            this.label414.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button297
            // 
            this.button297.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button297.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button297.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button297.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button297.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button297.Location = new System.Drawing.Point(138, 0);
            this.button297.Name = "button297";
            this.button297.Size = new System.Drawing.Size(70, 50);
            this.button297.TabIndex = 204;
            this.button297.TabStop = false;
            this.button297.Text = "2";
            this.button297.UseCompatibleTextRendering = true;
            this.button297.UseVisualStyleBackColor = true;
            this.button297.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button298
            // 
            this.button298.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button298.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button298.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button298.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button298.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button298.Location = new System.Drawing.Point(69, 0);
            this.button298.Name = "button298";
            this.button298.Size = new System.Drawing.Size(70, 50);
            this.button298.TabIndex = 203;
            this.button298.TabStop = false;
            this.button298.Text = "1";
            this.button298.UseCompatibleTextRendering = true;
            this.button298.UseVisualStyleBackColor = true;
            this.button298.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label428
            // 
            this.label428.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label428.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label428.ForeColor = System.Drawing.Color.Gray;
            this.label428.Location = new System.Drawing.Point(276, 196);
            this.label428.Name = "label428";
            this.label428.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label428.Size = new System.Drawing.Size(70, 50);
            this.label428.TabIndex = 154;
            this.label428.Text = "1";
            this.label428.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label429
            // 
            this.label429.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label429.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label429.ForeColor = System.Drawing.Color.Gray;
            this.label429.Location = new System.Drawing.Point(207, 245);
            this.label429.Name = "label429";
            this.label429.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label429.Size = new System.Drawing.Size(70, 50);
            this.label429.TabIndex = 153;
            this.label429.Text = "7";
            this.label429.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label430
            // 
            this.label430.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label430.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label430.ForeColor = System.Drawing.Color.Gray;
            this.label430.Location = new System.Drawing.Point(0, 245);
            this.label430.Name = "label430";
            this.label430.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label430.Size = new System.Drawing.Size(70, 50);
            this.label430.TabIndex = 152;
            this.label430.Text = "4";
            this.label430.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label432
            // 
            this.label432.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label432.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label432.ForeColor = System.Drawing.Color.Gray;
            this.label432.Location = new System.Drawing.Point(69, 245);
            this.label432.Name = "label432";
            this.label432.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label432.Size = new System.Drawing.Size(70, 50);
            this.label432.TabIndex = 151;
            this.label432.Text = "5";
            this.label432.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label434
            // 
            this.label434.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label434.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label434.ForeColor = System.Drawing.Color.Gray;
            this.label434.Location = new System.Drawing.Point(138, 245);
            this.label434.Name = "label434";
            this.label434.Size = new System.Drawing.Size(70, 50);
            this.label434.TabIndex = 150;
            this.label434.Text = "6";
            this.label434.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label435
            // 
            this.label435.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label435.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label435.ForeColor = System.Drawing.Color.Gray;
            this.label435.Location = new System.Drawing.Point(345, 245);
            this.label435.Name = "label435";
            this.label435.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label435.Size = new System.Drawing.Size(70, 50);
            this.label435.TabIndex = 148;
            this.label435.Text = "9";
            this.label435.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label436
            // 
            this.label436.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label436.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label436.ForeColor = System.Drawing.Color.Gray;
            this.label436.Location = new System.Drawing.Point(276, 245);
            this.label436.Name = "label436";
            this.label436.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label436.Size = new System.Drawing.Size(70, 50);
            this.label436.TabIndex = 147;
            this.label436.Text = "8";
            this.label436.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label437
            // 
            this.label437.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label437.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label437.ForeColor = System.Drawing.Color.Gray;
            this.label437.Location = new System.Drawing.Point(414, 245);
            this.label437.Name = "label437";
            this.label437.Size = new System.Drawing.Size(70, 50);
            this.label437.TabIndex = 149;
            this.label437.Text = "10";
            this.label437.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label438
            // 
            this.label438.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label438.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label438.ForeColor = System.Drawing.Color.Gray;
            this.label438.Location = new System.Drawing.Point(345, 196);
            this.label438.Name = "label438";
            this.label438.Size = new System.Drawing.Size(70, 50);
            this.label438.TabIndex = 145;
            this.label438.Text = "2";
            this.label438.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label439
            // 
            this.label439.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label439.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label439.ForeColor = System.Drawing.Color.Gray;
            this.label439.Location = new System.Drawing.Point(414, 196);
            this.label439.Name = "label439";
            this.label439.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label439.Size = new System.Drawing.Size(70, 50);
            this.label439.TabIndex = 146;
            this.label439.Text = "3";
            this.label439.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // heading10
            // 
            this.heading10.Location = new System.Drawing.Point(1, 1);
            this.heading10.Name = "heading10";
            this.heading10.Size = new System.Drawing.Size(484, 58);
            this.heading10.TabIndex = 119;
            // 
            // November
            // 
            this.November.Controls.Add(this.Nov);
            this.November.Controls.Add(this.button47);
            this.November.Controls.Add(this.button50);
            this.November.Controls.Add(this.panel11);
            this.November.Controls.Add(this.heading11);
            this.November.Location = new System.Drawing.Point(1, 70);
            this.November.Name = "November";
            this.November.Size = new System.Drawing.Size(486, 353);
            this.November.TabIndex = 239;
            // 
            // Nov
            // 
            this.Nov.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Nov.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Nov.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Nov.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Nov.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Nov.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Nov.Location = new System.Drawing.Point(139, 0);
            this.Nov.Name = "Nov";
            this.Nov.Size = new System.Drawing.Size(208, 39);
            this.Nov.TabIndex = 162;
            this.Nov.TabStop = false;
            this.Nov.Text = "November";
            this.Nov.UseVisualStyleBackColor = false;
            this.Nov.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button47.BackgroundImage = global::Calendar_App.Properties.Resources.Right;
            this.button47.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button47.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button47.FlatAppearance.BorderSize = 0;
            this.button47.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(452, 4);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(30, 30);
            this.button47.TabIndex = 122;
            this.button47.TabStop = false;
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button50.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button50.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button50.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button50.FlatAppearance.BorderSize = 0;
            this.button50.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(5, 4);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(30, 30);
            this.button50.TabIndex = 121;
            this.button50.TabStop = false;
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.button354);
            this.panel11.Controls.Add(this.button351);
            this.panel11.Controls.Add(this.button355);
            this.panel11.Controls.Add(this.button356);
            this.panel11.Controls.Add(this.button347);
            this.panel11.Controls.Add(this.button352);
            this.panel11.Controls.Add(this.button353);
            this.panel11.Controls.Add(this.button344);
            this.panel11.Controls.Add(this.button348);
            this.panel11.Controls.Add(this.button349);
            this.panel11.Controls.Add(this.button345);
            this.panel11.Controls.Add(this.button350);
            this.panel11.Controls.Add(this.button337);
            this.panel11.Controls.Add(this.button346);
            this.panel11.Controls.Add(this.button338);
            this.panel11.Controls.Add(this.button339);
            this.panel11.Controls.Add(this.button340);
            this.panel11.Controls.Add(this.button341);
            this.panel11.Controls.Add(this.button342);
            this.panel11.Controls.Add(this.button343);
            this.panel11.Controls.Add(this.button330);
            this.panel11.Controls.Add(this.button327);
            this.panel11.Controls.Add(this.button331);
            this.panel11.Controls.Add(this.button328);
            this.panel11.Controls.Add(this.button332);
            this.panel11.Controls.Add(this.button329);
            this.panel11.Controls.Add(this.button333);
            this.panel11.Controls.Add(this.label470);
            this.panel11.Controls.Add(this.button334);
            this.panel11.Controls.Add(this.label471);
            this.panel11.Controls.Add(this.button335);
            this.panel11.Controls.Add(this.button336);
            this.panel11.Controls.Add(this.label472);
            this.panel11.Controls.Add(this.label504);
            this.panel11.Controls.Add(this.label474);
            this.panel11.Controls.Add(this.label475);
            this.panel11.Controls.Add(this.label477);
            this.panel11.Controls.Add(this.label479);
            this.panel11.Controls.Add(this.label480);
            this.panel11.Controls.Add(this.label481);
            this.panel11.Controls.Add(this.label482);
            this.panel11.Controls.Add(this.label484);
            this.panel11.Location = new System.Drawing.Point(1, 58);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(484, 295);
            this.panel11.TabIndex = 124;
            // 
            // button354
            // 
            this.button354.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button354.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button354.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button354.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button354.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button354.Location = new System.Drawing.Point(207, 196);
            this.button354.Name = "button354";
            this.button354.Size = new System.Drawing.Size(70, 50);
            this.button354.TabIndex = 202;
            this.button354.TabStop = false;
            this.button354.Text = "28";
            this.button354.UseCompatibleTextRendering = true;
            this.button354.UseVisualStyleBackColor = true;
            this.button354.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button351
            // 
            this.button351.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button351.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button351.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button351.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button351.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button351.Location = new System.Drawing.Point(138, 196);
            this.button351.Name = "button351";
            this.button351.Size = new System.Drawing.Size(70, 50);
            this.button351.TabIndex = 246;
            this.button351.TabStop = false;
            this.button351.Text = "27";
            this.button351.UseCompatibleTextRendering = true;
            this.button351.UseVisualStyleBackColor = true;
            this.button351.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button355
            // 
            this.button355.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button355.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button355.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button355.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button355.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button355.Location = new System.Drawing.Point(345, 196);
            this.button355.Name = "button355";
            this.button355.Size = new System.Drawing.Size(70, 50);
            this.button355.TabIndex = 201;
            this.button355.TabStop = false;
            this.button355.Text = "30";
            this.button355.UseCompatibleTextRendering = true;
            this.button355.UseVisualStyleBackColor = true;
            this.button355.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button356
            // 
            this.button356.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button356.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button356.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button356.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button356.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button356.Location = new System.Drawing.Point(276, 196);
            this.button356.Name = "button356";
            this.button356.Size = new System.Drawing.Size(70, 50);
            this.button356.TabIndex = 200;
            this.button356.TabStop = false;
            this.button356.Text = "29";
            this.button356.UseCompatibleTextRendering = true;
            this.button356.UseVisualStyleBackColor = true;
            this.button356.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button347
            // 
            this.button347.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button347.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button347.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button347.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button347.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button347.Location = new System.Drawing.Point(207, 147);
            this.button347.Name = "button347";
            this.button347.Size = new System.Drawing.Size(70, 50);
            this.button347.TabIndex = 199;
            this.button347.TabStop = false;
            this.button347.Text = "21";
            this.button347.UseCompatibleTextRendering = true;
            this.button347.UseVisualStyleBackColor = true;
            this.button347.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button352
            // 
            this.button352.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button352.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button352.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button352.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button352.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button352.Location = new System.Drawing.Point(69, 196);
            this.button352.Name = "button352";
            this.button352.Size = new System.Drawing.Size(70, 50);
            this.button352.TabIndex = 245;
            this.button352.TabStop = false;
            this.button352.Text = "26";
            this.button352.UseCompatibleTextRendering = true;
            this.button352.UseVisualStyleBackColor = true;
            this.button352.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button353
            // 
            this.button353.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button353.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button353.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button353.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button353.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button353.Location = new System.Drawing.Point(0, 196);
            this.button353.Name = "button353";
            this.button353.Size = new System.Drawing.Size(70, 50);
            this.button353.TabIndex = 244;
            this.button353.TabStop = false;
            this.button353.Text = "25";
            this.button353.UseCompatibleTextRendering = true;
            this.button353.UseVisualStyleBackColor = true;
            this.button353.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button344
            // 
            this.button344.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button344.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button344.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button344.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button344.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button344.Location = new System.Drawing.Point(138, 147);
            this.button344.Name = "button344";
            this.button344.Size = new System.Drawing.Size(70, 50);
            this.button344.TabIndex = 246;
            this.button344.TabStop = false;
            this.button344.Text = "20";
            this.button344.UseCompatibleTextRendering = true;
            this.button344.UseVisualStyleBackColor = true;
            this.button344.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button348
            // 
            this.button348.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button348.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button348.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button348.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button348.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button348.Location = new System.Drawing.Point(414, 147);
            this.button348.Name = "button348";
            this.button348.Size = new System.Drawing.Size(70, 50);
            this.button348.TabIndex = 198;
            this.button348.TabStop = false;
            this.button348.Text = "24";
            this.button348.UseCompatibleTextRendering = true;
            this.button348.UseVisualStyleBackColor = true;
            this.button348.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button349
            // 
            this.button349.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button349.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button349.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button349.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button349.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button349.Location = new System.Drawing.Point(345, 147);
            this.button349.Name = "button349";
            this.button349.Size = new System.Drawing.Size(70, 50);
            this.button349.TabIndex = 197;
            this.button349.TabStop = false;
            this.button349.Text = "23";
            this.button349.UseCompatibleTextRendering = true;
            this.button349.UseVisualStyleBackColor = true;
            this.button349.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button345
            // 
            this.button345.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button345.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button345.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button345.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button345.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button345.Location = new System.Drawing.Point(69, 147);
            this.button345.Name = "button345";
            this.button345.Size = new System.Drawing.Size(70, 50);
            this.button345.TabIndex = 245;
            this.button345.TabStop = false;
            this.button345.Text = "19";
            this.button345.UseCompatibleTextRendering = true;
            this.button345.UseVisualStyleBackColor = true;
            this.button345.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button350
            // 
            this.button350.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button350.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button350.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button350.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button350.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button350.Location = new System.Drawing.Point(276, 147);
            this.button350.Name = "button350";
            this.button350.Size = new System.Drawing.Size(70, 50);
            this.button350.TabIndex = 196;
            this.button350.TabStop = false;
            this.button350.Text = "22";
            this.button350.UseCompatibleTextRendering = true;
            this.button350.UseVisualStyleBackColor = true;
            this.button350.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button337
            // 
            this.button337.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button337.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button337.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button337.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button337.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button337.Location = new System.Drawing.Point(207, 98);
            this.button337.Name = "button337";
            this.button337.Size = new System.Drawing.Size(70, 50);
            this.button337.TabIndex = 257;
            this.button337.TabStop = false;
            this.button337.Text = "14";
            this.button337.UseCompatibleTextRendering = true;
            this.button337.UseVisualStyleBackColor = true;
            this.button337.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button346
            // 
            this.button346.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button346.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button346.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button346.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button346.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button346.Location = new System.Drawing.Point(0, 147);
            this.button346.Name = "button346";
            this.button346.Size = new System.Drawing.Size(70, 50);
            this.button346.TabIndex = 244;
            this.button346.TabStop = false;
            this.button346.Text = "18";
            this.button346.UseCompatibleTextRendering = true;
            this.button346.UseVisualStyleBackColor = true;
            this.button346.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button338
            // 
            this.button338.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button338.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button338.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button338.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button338.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button338.Location = new System.Drawing.Point(414, 98);
            this.button338.Name = "button338";
            this.button338.Size = new System.Drawing.Size(70, 50);
            this.button338.TabIndex = 256;
            this.button338.TabStop = false;
            this.button338.Text = "17";
            this.button338.UseCompatibleTextRendering = true;
            this.button338.UseVisualStyleBackColor = true;
            this.button338.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button339
            // 
            this.button339.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button339.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button339.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button339.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button339.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button339.Location = new System.Drawing.Point(345, 98);
            this.button339.Name = "button339";
            this.button339.Size = new System.Drawing.Size(70, 50);
            this.button339.TabIndex = 255;
            this.button339.TabStop = false;
            this.button339.Text = "16";
            this.button339.UseCompatibleTextRendering = true;
            this.button339.UseVisualStyleBackColor = true;
            this.button339.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button340
            // 
            this.button340.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button340.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button340.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button340.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button340.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button340.Location = new System.Drawing.Point(276, 98);
            this.button340.Name = "button340";
            this.button340.Size = new System.Drawing.Size(70, 50);
            this.button340.TabIndex = 254;
            this.button340.TabStop = false;
            this.button340.Text = "15";
            this.button340.UseCompatibleTextRendering = true;
            this.button340.UseVisualStyleBackColor = true;
            this.button340.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button341
            // 
            this.button341.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button341.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button341.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button341.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button341.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button341.Location = new System.Drawing.Point(138, 98);
            this.button341.Name = "button341";
            this.button341.Size = new System.Drawing.Size(70, 50);
            this.button341.TabIndex = 253;
            this.button341.TabStop = false;
            this.button341.Text = "13";
            this.button341.UseCompatibleTextRendering = true;
            this.button341.UseVisualStyleBackColor = true;
            this.button341.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button342
            // 
            this.button342.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button342.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button342.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button342.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button342.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button342.Location = new System.Drawing.Point(69, 98);
            this.button342.Name = "button342";
            this.button342.Size = new System.Drawing.Size(70, 50);
            this.button342.TabIndex = 252;
            this.button342.TabStop = false;
            this.button342.Text = "12";
            this.button342.UseCompatibleTextRendering = true;
            this.button342.UseVisualStyleBackColor = true;
            this.button342.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button343
            // 
            this.button343.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button343.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button343.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button343.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button343.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button343.Location = new System.Drawing.Point(0, 98);
            this.button343.Name = "button343";
            this.button343.Size = new System.Drawing.Size(70, 50);
            this.button343.TabIndex = 251;
            this.button343.TabStop = false;
            this.button343.Text = "11";
            this.button343.UseCompatibleTextRendering = true;
            this.button343.UseVisualStyleBackColor = true;
            this.button343.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button330
            // 
            this.button330.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button330.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button330.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button330.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button330.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button330.Location = new System.Drawing.Point(207, 49);
            this.button330.Name = "button330";
            this.button330.Size = new System.Drawing.Size(70, 50);
            this.button330.TabIndex = 250;
            this.button330.TabStop = false;
            this.button330.Text = "7";
            this.button330.UseCompatibleTextRendering = true;
            this.button330.UseVisualStyleBackColor = true;
            this.button330.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button327
            // 
            this.button327.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button327.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button327.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button327.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button327.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button327.Location = new System.Drawing.Point(414, 0);
            this.button327.Name = "button327";
            this.button327.Size = new System.Drawing.Size(70, 50);
            this.button327.TabIndex = 205;
            this.button327.TabStop = false;
            this.button327.Text = "3";
            this.button327.UseCompatibleTextRendering = true;
            this.button327.UseVisualStyleBackColor = true;
            this.button327.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button331
            // 
            this.button331.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button331.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button331.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button331.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button331.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button331.Location = new System.Drawing.Point(138, 49);
            this.button331.Name = "button331";
            this.button331.Size = new System.Drawing.Size(70, 50);
            this.button331.TabIndex = 246;
            this.button331.TabStop = false;
            this.button331.Text = "6";
            this.button331.UseCompatibleTextRendering = true;
            this.button331.UseVisualStyleBackColor = true;
            this.button331.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button328
            // 
            this.button328.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button328.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button328.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button328.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button328.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button328.Location = new System.Drawing.Point(345, 0);
            this.button328.Name = "button328";
            this.button328.Size = new System.Drawing.Size(70, 50);
            this.button328.TabIndex = 204;
            this.button328.TabStop = false;
            this.button328.Text = "2";
            this.button328.UseCompatibleTextRendering = true;
            this.button328.UseVisualStyleBackColor = true;
            this.button328.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button332
            // 
            this.button332.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button332.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button332.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button332.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button332.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button332.Location = new System.Drawing.Point(414, 49);
            this.button332.Name = "button332";
            this.button332.Size = new System.Drawing.Size(70, 50);
            this.button332.TabIndex = 249;
            this.button332.TabStop = false;
            this.button332.Text = "10";
            this.button332.UseCompatibleTextRendering = true;
            this.button332.UseVisualStyleBackColor = true;
            this.button332.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button329
            // 
            this.button329.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button329.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button329.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button329.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button329.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button329.Location = new System.Drawing.Point(276, 0);
            this.button329.Name = "button329";
            this.button329.Size = new System.Drawing.Size(70, 50);
            this.button329.TabIndex = 203;
            this.button329.TabStop = false;
            this.button329.Text = "1";
            this.button329.UseCompatibleTextRendering = true;
            this.button329.UseVisualStyleBackColor = true;
            this.button329.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button333
            // 
            this.button333.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button333.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button333.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button333.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button333.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button333.Location = new System.Drawing.Point(69, 49);
            this.button333.Name = "button333";
            this.button333.Size = new System.Drawing.Size(70, 50);
            this.button333.TabIndex = 245;
            this.button333.TabStop = false;
            this.button333.Text = "5";
            this.button333.UseCompatibleTextRendering = true;
            this.button333.UseVisualStyleBackColor = true;
            this.button333.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label470
            // 
            this.label470.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label470.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label470.ForeColor = System.Drawing.Color.Gray;
            this.label470.Location = new System.Drawing.Point(207, 0);
            this.label470.Name = "label470";
            this.label470.Size = new System.Drawing.Size(70, 50);
            this.label470.TabIndex = 155;
            this.label470.Text = "31";
            this.label470.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button334
            // 
            this.button334.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button334.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button334.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button334.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button334.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button334.Location = new System.Drawing.Point(345, 49);
            this.button334.Name = "button334";
            this.button334.Size = new System.Drawing.Size(70, 50);
            this.button334.TabIndex = 248;
            this.button334.TabStop = false;
            this.button334.Text = "9";
            this.button334.UseCompatibleTextRendering = true;
            this.button334.UseVisualStyleBackColor = true;
            this.button334.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label471
            // 
            this.label471.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label471.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label471.ForeColor = System.Drawing.Color.Gray;
            this.label471.Location = new System.Drawing.Point(138, 0);
            this.label471.Name = "label471";
            this.label471.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label471.Size = new System.Drawing.Size(70, 50);
            this.label471.TabIndex = 158;
            this.label471.Text = "30";
            this.label471.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button335
            // 
            this.button335.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button335.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button335.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button335.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button335.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button335.Location = new System.Drawing.Point(276, 49);
            this.button335.Name = "button335";
            this.button335.Size = new System.Drawing.Size(70, 50);
            this.button335.TabIndex = 247;
            this.button335.TabStop = false;
            this.button335.Text = "8";
            this.button335.UseCompatibleTextRendering = true;
            this.button335.UseVisualStyleBackColor = true;
            this.button335.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button336
            // 
            this.button336.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button336.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button336.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button336.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button336.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button336.Location = new System.Drawing.Point(0, 49);
            this.button336.Name = "button336";
            this.button336.Size = new System.Drawing.Size(70, 50);
            this.button336.TabIndex = 244;
            this.button336.TabStop = false;
            this.button336.Text = "4";
            this.button336.UseCompatibleTextRendering = true;
            this.button336.UseVisualStyleBackColor = true;
            this.button336.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label472
            // 
            this.label472.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label472.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label472.ForeColor = System.Drawing.Color.Gray;
            this.label472.Location = new System.Drawing.Point(0, 0);
            this.label472.Name = "label472";
            this.label472.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label472.Size = new System.Drawing.Size(70, 50);
            this.label472.TabIndex = 157;
            this.label472.Text = "28";
            this.label472.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label504
            // 
            this.label504.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label504.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label504.ForeColor = System.Drawing.Color.Gray;
            this.label504.Location = new System.Drawing.Point(69, 0);
            this.label504.Name = "label504";
            this.label504.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label504.Size = new System.Drawing.Size(70, 50);
            this.label504.TabIndex = 156;
            this.label504.Text = "29";
            this.label504.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label474
            // 
            this.label474.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label474.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label474.ForeColor = System.Drawing.Color.Gray;
            this.label474.Location = new System.Drawing.Point(207, 245);
            this.label474.Name = "label474";
            this.label474.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label474.Size = new System.Drawing.Size(70, 50);
            this.label474.TabIndex = 153;
            this.label474.Text = "5";
            this.label474.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label475
            // 
            this.label475.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label475.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label475.ForeColor = System.Drawing.Color.Gray;
            this.label475.Location = new System.Drawing.Point(0, 245);
            this.label475.Name = "label475";
            this.label475.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label475.Size = new System.Drawing.Size(70, 50);
            this.label475.TabIndex = 152;
            this.label475.Text = "2";
            this.label475.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label477
            // 
            this.label477.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label477.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label477.ForeColor = System.Drawing.Color.Gray;
            this.label477.Location = new System.Drawing.Point(69, 245);
            this.label477.Name = "label477";
            this.label477.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label477.Size = new System.Drawing.Size(70, 50);
            this.label477.TabIndex = 151;
            this.label477.Text = "3";
            this.label477.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label479
            // 
            this.label479.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label479.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label479.ForeColor = System.Drawing.Color.Gray;
            this.label479.Location = new System.Drawing.Point(138, 245);
            this.label479.Name = "label479";
            this.label479.Size = new System.Drawing.Size(70, 50);
            this.label479.TabIndex = 150;
            this.label479.Text = "4";
            this.label479.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label480
            // 
            this.label480.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label480.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label480.ForeColor = System.Drawing.Color.Gray;
            this.label480.Location = new System.Drawing.Point(345, 245);
            this.label480.Name = "label480";
            this.label480.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label480.Size = new System.Drawing.Size(70, 50);
            this.label480.TabIndex = 148;
            this.label480.Text = "7";
            this.label480.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label481
            // 
            this.label481.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label481.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label481.ForeColor = System.Drawing.Color.Gray;
            this.label481.Location = new System.Drawing.Point(276, 245);
            this.label481.Name = "label481";
            this.label481.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label481.Size = new System.Drawing.Size(70, 50);
            this.label481.TabIndex = 147;
            this.label481.Text = "6";
            this.label481.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label482
            // 
            this.label482.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label482.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label482.ForeColor = System.Drawing.Color.Gray;
            this.label482.Location = new System.Drawing.Point(414, 245);
            this.label482.Name = "label482";
            this.label482.Size = new System.Drawing.Size(70, 50);
            this.label482.TabIndex = 149;
            this.label482.Text = "8";
            this.label482.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label484
            // 
            this.label484.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label484.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label484.ForeColor = System.Drawing.Color.Gray;
            this.label484.Location = new System.Drawing.Point(414, 196);
            this.label484.Name = "label484";
            this.label484.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label484.Size = new System.Drawing.Size(70, 50);
            this.label484.TabIndex = 146;
            this.label484.Text = "1";
            this.label484.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // heading11
            // 
            this.heading11.Location = new System.Drawing.Point(1, 1);
            this.heading11.Name = "heading11";
            this.heading11.Size = new System.Drawing.Size(484, 58);
            this.heading11.TabIndex = 119;
            // 
            // December
            // 
            this.December.Controls.Add(this.Dec);
            this.December.Controls.Add(this.button55);
            this.December.Controls.Add(this.panel12);
            this.December.Controls.Add(this.heading12);
            this.December.Location = new System.Drawing.Point(1, 70);
            this.December.Name = "December";
            this.December.Size = new System.Drawing.Size(486, 353);
            this.December.TabIndex = 240;
            // 
            // Dec
            // 
            this.Dec.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Dec.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dec.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.Dec.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.Dec.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dec.Font = new System.Drawing.Font("Impact", 20.25F);
            this.Dec.Location = new System.Drawing.Point(139, 0);
            this.Dec.Name = "Dec";
            this.Dec.Size = new System.Drawing.Size(208, 39);
            this.Dec.TabIndex = 163;
            this.Dec.TabStop = false;
            this.Dec.Text = "December";
            this.Dec.UseVisualStyleBackColor = false;
            this.Dec.Click += new System.EventHandler(this.ShowMonSec_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.button55.BackgroundImage = global::Calendar_App.Properties.Resources.Left;
            this.button55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.FlatAppearance.BorderSize = 0;
            this.button55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(5, 4);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 30);
            this.button55.TabIndex = 121;
            this.button55.TabStop = false;
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.button386);
            this.panel12.Controls.Add(this.button387);
            this.panel12.Controls.Add(this.button382);
            this.panel12.Controls.Add(this.button383);
            this.panel12.Controls.Add(this.button384);
            this.panel12.Controls.Add(this.button385);
            this.panel12.Controls.Add(this.button379);
            this.panel12.Controls.Add(this.button380);
            this.panel12.Controls.Add(this.button375);
            this.panel12.Controls.Add(this.button381);
            this.panel12.Controls.Add(this.button372);
            this.panel12.Controls.Add(this.button376);
            this.panel12.Controls.Add(this.button377);
            this.panel12.Controls.Add(this.button373);
            this.panel12.Controls.Add(this.button378);
            this.panel12.Controls.Add(this.button365);
            this.panel12.Controls.Add(this.button374);
            this.panel12.Controls.Add(this.button366);
            this.panel12.Controls.Add(this.button367);
            this.panel12.Controls.Add(this.button368);
            this.panel12.Controls.Add(this.button369);
            this.panel12.Controls.Add(this.button370);
            this.panel12.Controls.Add(this.button371);
            this.panel12.Controls.Add(this.button360);
            this.panel12.Controls.Add(this.button361);
            this.panel12.Controls.Add(this.button362);
            this.panel12.Controls.Add(this.button363);
            this.panel12.Controls.Add(this.button364);
            this.panel12.Controls.Add(this.button358);
            this.panel12.Controls.Add(this.button357);
            this.panel12.Controls.Add(this.button359);
            this.panel12.Controls.Add(this.label506);
            this.panel12.Controls.Add(this.label514);
            this.panel12.Controls.Add(this.label516);
            this.panel12.Controls.Add(this.label517);
            this.panel12.Controls.Add(this.label518);
            this.panel12.Controls.Add(this.label519);
            this.panel12.Controls.Add(this.label522);
            this.panel12.Controls.Add(this.label527);
            this.panel12.Controls.Add(this.label528);
            this.panel12.Controls.Add(this.label529);
            this.panel12.Controls.Add(this.label530);
            this.panel12.Location = new System.Drawing.Point(1, 58);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(484, 295);
            this.panel12.TabIndex = 124;
            // 
            // button386
            // 
            this.button386.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button386.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button386.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button386.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button386.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button386.Location = new System.Drawing.Point(69, 98);
            this.button386.Name = "button386";
            this.button386.Size = new System.Drawing.Size(70, 50);
            this.button386.TabIndex = 245;
            this.button386.TabStop = false;
            this.button386.Text = "10";
            this.button386.UseCompatibleTextRendering = true;
            this.button386.UseVisualStyleBackColor = true;
            this.button386.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button387
            // 
            this.button387.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button387.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button387.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button387.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button387.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button387.Location = new System.Drawing.Point(0, 98);
            this.button387.Name = "button387";
            this.button387.Size = new System.Drawing.Size(70, 50);
            this.button387.TabIndex = 244;
            this.button387.TabStop = false;
            this.button387.Text = "9";
            this.button387.UseCompatibleTextRendering = true;
            this.button387.UseVisualStyleBackColor = true;
            this.button387.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button382
            // 
            this.button382.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button382.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button382.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button382.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button382.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button382.Location = new System.Drawing.Point(345, 196);
            this.button382.Name = "button382";
            this.button382.Size = new System.Drawing.Size(70, 50);
            this.button382.TabIndex = 260;
            this.button382.TabStop = false;
            this.button382.Text = "28";
            this.button382.UseCompatibleTextRendering = true;
            this.button382.UseVisualStyleBackColor = true;
            this.button382.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button383
            // 
            this.button383.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button383.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button383.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button383.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button383.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button383.Location = new System.Drawing.Point(69, 245);
            this.button383.Name = "button383";
            this.button383.Size = new System.Drawing.Size(70, 50);
            this.button383.TabIndex = 259;
            this.button383.TabStop = false;
            this.button383.Text = "31";
            this.button383.UseCompatibleTextRendering = true;
            this.button383.UseVisualStyleBackColor = true;
            this.button383.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button384
            // 
            this.button384.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button384.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button384.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button384.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button384.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button384.Location = new System.Drawing.Point(0, 245);
            this.button384.Name = "button384";
            this.button384.Size = new System.Drawing.Size(70, 50);
            this.button384.TabIndex = 258;
            this.button384.TabStop = false;
            this.button384.Text = "30";
            this.button384.UseCompatibleTextRendering = true;
            this.button384.UseVisualStyleBackColor = true;
            this.button384.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button385
            // 
            this.button385.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button385.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button385.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button385.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button385.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button385.Location = new System.Drawing.Point(414, 196);
            this.button385.Name = "button385";
            this.button385.Size = new System.Drawing.Size(70, 50);
            this.button385.TabIndex = 257;
            this.button385.TabStop = false;
            this.button385.Text = "29";
            this.button385.UseCompatibleTextRendering = true;
            this.button385.UseVisualStyleBackColor = true;
            this.button385.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button379
            // 
            this.button379.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button379.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button379.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button379.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button379.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button379.Location = new System.Drawing.Point(276, 196);
            this.button379.Name = "button379";
            this.button379.Size = new System.Drawing.Size(70, 50);
            this.button379.TabIndex = 197;
            this.button379.TabStop = false;
            this.button379.Text = "27";
            this.button379.UseCompatibleTextRendering = true;
            this.button379.UseVisualStyleBackColor = true;
            this.button379.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button380
            // 
            this.button380.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button380.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button380.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button380.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button380.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button380.Location = new System.Drawing.Point(207, 196);
            this.button380.Name = "button380";
            this.button380.Size = new System.Drawing.Size(70, 50);
            this.button380.TabIndex = 196;
            this.button380.TabStop = false;
            this.button380.Text = "26";
            this.button380.UseCompatibleTextRendering = true;
            this.button380.UseVisualStyleBackColor = true;
            this.button380.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button375
            // 
            this.button375.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button375.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button375.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button375.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button375.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button375.Location = new System.Drawing.Point(345, 147);
            this.button375.Name = "button375";
            this.button375.Size = new System.Drawing.Size(70, 50);
            this.button375.TabIndex = 247;
            this.button375.TabStop = false;
            this.button375.Text = "21";
            this.button375.UseCompatibleTextRendering = true;
            this.button375.UseVisualStyleBackColor = true;
            this.button375.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button381
            // 
            this.button381.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button381.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button381.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button381.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button381.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button381.Location = new System.Drawing.Point(138, 196);
            this.button381.Name = "button381";
            this.button381.Size = new System.Drawing.Size(70, 50);
            this.button381.TabIndex = 195;
            this.button381.TabStop = false;
            this.button381.Text = "25";
            this.button381.UseCompatibleTextRendering = true;
            this.button381.UseVisualStyleBackColor = true;
            this.button381.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button372
            // 
            this.button372.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button372.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button372.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button372.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button372.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button372.Location = new System.Drawing.Point(276, 147);
            this.button372.Name = "button372";
            this.button372.Size = new System.Drawing.Size(70, 50);
            this.button372.TabIndex = 191;
            this.button372.TabStop = false;
            this.button372.Text = "20";
            this.button372.UseCompatibleTextRendering = true;
            this.button372.UseVisualStyleBackColor = true;
            this.button372.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button376
            // 
            this.button376.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button376.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button376.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button376.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button376.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button376.Location = new System.Drawing.Point(69, 196);
            this.button376.Name = "button376";
            this.button376.Size = new System.Drawing.Size(70, 50);
            this.button376.TabIndex = 246;
            this.button376.TabStop = false;
            this.button376.Text = "24";
            this.button376.UseCompatibleTextRendering = true;
            this.button376.UseVisualStyleBackColor = true;
            this.button376.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button377
            // 
            this.button377.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button377.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button377.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button377.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button377.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button377.Location = new System.Drawing.Point(0, 196);
            this.button377.Name = "button377";
            this.button377.Size = new System.Drawing.Size(70, 50);
            this.button377.TabIndex = 245;
            this.button377.TabStop = false;
            this.button377.Text = "23";
            this.button377.UseCompatibleTextRendering = true;
            this.button377.UseVisualStyleBackColor = true;
            this.button377.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button373
            // 
            this.button373.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button373.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button373.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button373.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button373.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button373.Location = new System.Drawing.Point(207, 147);
            this.button373.Name = "button373";
            this.button373.Size = new System.Drawing.Size(70, 50);
            this.button373.TabIndex = 190;
            this.button373.TabStop = false;
            this.button373.Text = "19";
            this.button373.UseCompatibleTextRendering = true;
            this.button373.UseVisualStyleBackColor = true;
            this.button373.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button378
            // 
            this.button378.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button378.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button378.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button378.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button378.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button378.Location = new System.Drawing.Point(414, 147);
            this.button378.Name = "button378";
            this.button378.Size = new System.Drawing.Size(70, 50);
            this.button378.TabIndex = 244;
            this.button378.TabStop = false;
            this.button378.Text = "22";
            this.button378.UseCompatibleTextRendering = true;
            this.button378.UseVisualStyleBackColor = true;
            this.button378.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button365
            // 
            this.button365.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button365.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button365.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button365.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button365.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button365.Location = new System.Drawing.Point(345, 98);
            this.button365.Name = "button365";
            this.button365.Size = new System.Drawing.Size(70, 50);
            this.button365.TabIndex = 256;
            this.button365.TabStop = false;
            this.button365.Text = "14";
            this.button365.UseCompatibleTextRendering = true;
            this.button365.UseVisualStyleBackColor = true;
            this.button365.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button374
            // 
            this.button374.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button374.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button374.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button374.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button374.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button374.Location = new System.Drawing.Point(138, 147);
            this.button374.Name = "button374";
            this.button374.Size = new System.Drawing.Size(70, 50);
            this.button374.TabIndex = 189;
            this.button374.TabStop = false;
            this.button374.Text = "18";
            this.button374.UseCompatibleTextRendering = true;
            this.button374.UseVisualStyleBackColor = true;
            this.button374.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button366
            // 
            this.button366.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button366.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button366.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button366.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button366.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button366.Location = new System.Drawing.Point(69, 147);
            this.button366.Name = "button366";
            this.button366.Size = new System.Drawing.Size(70, 50);
            this.button366.TabIndex = 255;
            this.button366.TabStop = false;
            this.button366.Text = "17";
            this.button366.UseCompatibleTextRendering = true;
            this.button366.UseVisualStyleBackColor = true;
            this.button366.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button367
            // 
            this.button367.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button367.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button367.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button367.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button367.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button367.Location = new System.Drawing.Point(0, 147);
            this.button367.Name = "button367";
            this.button367.Size = new System.Drawing.Size(70, 50);
            this.button367.TabIndex = 254;
            this.button367.TabStop = false;
            this.button367.Text = "16";
            this.button367.UseCompatibleTextRendering = true;
            this.button367.UseVisualStyleBackColor = true;
            this.button367.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button368
            // 
            this.button368.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button368.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button368.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button368.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button368.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button368.Location = new System.Drawing.Point(414, 98);
            this.button368.Name = "button368";
            this.button368.Size = new System.Drawing.Size(70, 50);
            this.button368.TabIndex = 253;
            this.button368.TabStop = false;
            this.button368.Text = "15";
            this.button368.UseCompatibleTextRendering = true;
            this.button368.UseVisualStyleBackColor = true;
            this.button368.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button369
            // 
            this.button369.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button369.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button369.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button369.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button369.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button369.Location = new System.Drawing.Point(276, 98);
            this.button369.Name = "button369";
            this.button369.Size = new System.Drawing.Size(70, 50);
            this.button369.TabIndex = 252;
            this.button369.TabStop = false;
            this.button369.Text = "13";
            this.button369.UseCompatibleTextRendering = true;
            this.button369.UseVisualStyleBackColor = true;
            this.button369.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button370
            // 
            this.button370.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button370.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button370.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button370.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button370.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button370.Location = new System.Drawing.Point(207, 98);
            this.button370.Name = "button370";
            this.button370.Size = new System.Drawing.Size(70, 50);
            this.button370.TabIndex = 251;
            this.button370.TabStop = false;
            this.button370.Text = "12";
            this.button370.UseCompatibleTextRendering = true;
            this.button370.UseVisualStyleBackColor = true;
            this.button370.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button371
            // 
            this.button371.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button371.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button371.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button371.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button371.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button371.Location = new System.Drawing.Point(138, 98);
            this.button371.Name = "button371";
            this.button371.Size = new System.Drawing.Size(70, 50);
            this.button371.TabIndex = 250;
            this.button371.TabStop = false;
            this.button371.Text = "11";
            this.button371.UseCompatibleTextRendering = true;
            this.button371.UseVisualStyleBackColor = true;
            this.button371.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button360
            // 
            this.button360.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button360.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button360.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button360.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button360.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button360.Location = new System.Drawing.Point(345, 49);
            this.button360.Name = "button360";
            this.button360.Size = new System.Drawing.Size(70, 50);
            this.button360.TabIndex = 249;
            this.button360.TabStop = false;
            this.button360.Text = "7";
            this.button360.UseCompatibleTextRendering = true;
            this.button360.UseVisualStyleBackColor = true;
            this.button360.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button361
            // 
            this.button361.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button361.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button361.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button361.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button361.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button361.Location = new System.Drawing.Point(276, 49);
            this.button361.Name = "button361";
            this.button361.Size = new System.Drawing.Size(70, 50);
            this.button361.TabIndex = 247;
            this.button361.TabStop = false;
            this.button361.Text = "6";
            this.button361.UseCompatibleTextRendering = true;
            this.button361.UseVisualStyleBackColor = true;
            this.button361.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button362
            // 
            this.button362.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button362.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button362.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button362.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button362.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button362.Location = new System.Drawing.Point(207, 49);
            this.button362.Name = "button362";
            this.button362.Size = new System.Drawing.Size(70, 50);
            this.button362.TabIndex = 246;
            this.button362.TabStop = false;
            this.button362.Text = "5";
            this.button362.UseCompatibleTextRendering = true;
            this.button362.UseVisualStyleBackColor = true;
            this.button362.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button363
            // 
            this.button363.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button363.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button363.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button363.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button363.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button363.Location = new System.Drawing.Point(414, 49);
            this.button363.Name = "button363";
            this.button363.Size = new System.Drawing.Size(70, 50);
            this.button363.TabIndex = 248;
            this.button363.TabStop = false;
            this.button363.Text = "8";
            this.button363.UseCompatibleTextRendering = true;
            this.button363.UseVisualStyleBackColor = true;
            this.button363.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button364
            // 
            this.button364.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button364.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button364.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button364.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button364.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button364.Location = new System.Drawing.Point(138, 49);
            this.button364.Name = "button364";
            this.button364.Size = new System.Drawing.Size(70, 50);
            this.button364.TabIndex = 245;
            this.button364.TabStop = false;
            this.button364.Text = "4";
            this.button364.UseCompatibleTextRendering = true;
            this.button364.UseVisualStyleBackColor = true;
            this.button364.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button358
            // 
            this.button358.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button358.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button358.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button358.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button358.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button358.Location = new System.Drawing.Point(69, 49);
            this.button358.Name = "button358";
            this.button358.Size = new System.Drawing.Size(70, 50);
            this.button358.TabIndex = 204;
            this.button358.TabStop = false;
            this.button358.Text = "3";
            this.button358.UseCompatibleTextRendering = true;
            this.button358.UseVisualStyleBackColor = true;
            this.button358.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button357
            // 
            this.button357.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button357.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button357.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button357.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button357.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button357.Location = new System.Drawing.Point(414, 0);
            this.button357.Name = "button357";
            this.button357.Size = new System.Drawing.Size(70, 50);
            this.button357.TabIndex = 244;
            this.button357.TabStop = false;
            this.button357.Text = "1";
            this.button357.UseCompatibleTextRendering = true;
            this.button357.UseVisualStyleBackColor = true;
            this.button357.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // button359
            // 
            this.button359.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button359.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button359.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver;
            this.button359.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button359.Font = new System.Drawing.Font("Showcard Gothic", 11.25F);
            this.button359.Location = new System.Drawing.Point(0, 49);
            this.button359.Name = "button359";
            this.button359.Size = new System.Drawing.Size(70, 50);
            this.button359.TabIndex = 203;
            this.button359.TabStop = false;
            this.button359.Text = "2";
            this.button359.UseCompatibleTextRendering = true;
            this.button359.UseVisualStyleBackColor = true;
            this.button359.Click += new System.EventHandler(this.EventPage_Click);
            // 
            // label506
            // 
            this.label506.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label506.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label506.ForeColor = System.Drawing.Color.Gray;
            this.label506.Location = new System.Drawing.Point(276, 0);
            this.label506.Name = "label506";
            this.label506.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label506.Size = new System.Drawing.Size(70, 50);
            this.label506.TabIndex = 168;
            this.label506.Text = "29";
            this.label506.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label514
            // 
            this.label514.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label514.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label514.ForeColor = System.Drawing.Color.Gray;
            this.label514.Location = new System.Drawing.Point(345, 0);
            this.label514.Name = "label514";
            this.label514.Size = new System.Drawing.Size(70, 50);
            this.label514.TabIndex = 159;
            this.label514.Text = "30";
            this.label514.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label516
            // 
            this.label516.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label516.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label516.ForeColor = System.Drawing.Color.Gray;
            this.label516.Location = new System.Drawing.Point(207, 0);
            this.label516.Name = "label516";
            this.label516.Size = new System.Drawing.Size(70, 50);
            this.label516.TabIndex = 155;
            this.label516.Text = "28";
            this.label516.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label517
            // 
            this.label517.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label517.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label517.ForeColor = System.Drawing.Color.Gray;
            this.label517.Location = new System.Drawing.Point(138, 0);
            this.label517.Name = "label517";
            this.label517.Size = new System.Drawing.Size(70, 50);
            this.label517.TabIndex = 158;
            this.label517.Text = "27";
            this.label517.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label518
            // 
            this.label518.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label518.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label518.ForeColor = System.Drawing.Color.Gray;
            this.label518.Location = new System.Drawing.Point(0, 0);
            this.label518.Name = "label518";
            this.label518.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label518.Size = new System.Drawing.Size(70, 50);
            this.label518.TabIndex = 157;
            this.label518.Text = "25";
            this.label518.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label519
            // 
            this.label519.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label519.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label519.ForeColor = System.Drawing.Color.Gray;
            this.label519.Location = new System.Drawing.Point(69, 0);
            this.label519.Name = "label519";
            this.label519.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label519.Size = new System.Drawing.Size(70, 50);
            this.label519.TabIndex = 156;
            this.label519.Text = "26";
            this.label519.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label522
            // 
            this.label522.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label522.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label522.ForeColor = System.Drawing.Color.Gray;
            this.label522.Location = new System.Drawing.Point(207, 245);
            this.label522.Name = "label522";
            this.label522.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label522.Size = new System.Drawing.Size(70, 50);
            this.label522.TabIndex = 153;
            this.label522.Text = "2";
            this.label522.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label527
            // 
            this.label527.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label527.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label527.ForeColor = System.Drawing.Color.Gray;
            this.label527.Location = new System.Drawing.Point(138, 245);
            this.label527.Name = "label527";
            this.label527.Size = new System.Drawing.Size(70, 50);
            this.label527.TabIndex = 150;
            this.label527.Text = "1";
            this.label527.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label528
            // 
            this.label528.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label528.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label528.ForeColor = System.Drawing.Color.Gray;
            this.label528.Location = new System.Drawing.Point(345, 245);
            this.label528.Name = "label528";
            this.label528.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label528.Size = new System.Drawing.Size(70, 50);
            this.label528.TabIndex = 148;
            this.label528.Text = "4";
            this.label528.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label529
            // 
            this.label529.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label529.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label529.ForeColor = System.Drawing.Color.Gray;
            this.label529.Location = new System.Drawing.Point(276, 245);
            this.label529.Name = "label529";
            this.label529.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label529.Size = new System.Drawing.Size(70, 50);
            this.label529.TabIndex = 147;
            this.label529.Text = "3";
            this.label529.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label530
            // 
            this.label530.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label530.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label530.ForeColor = System.Drawing.Color.Gray;
            this.label530.Location = new System.Drawing.Point(414, 245);
            this.label530.Name = "label530";
            this.label530.Size = new System.Drawing.Size(70, 50);
            this.label530.TabIndex = 149;
            this.label530.Text = "5";
            this.label530.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // heading12
            // 
            this.heading12.Location = new System.Drawing.Point(1, 1);
            this.heading12.Name = "heading12";
            this.heading12.Size = new System.Drawing.Size(484, 58);
            this.heading12.TabIndex = 119;
            // 
            // Monsec
            // 
            this.Monsec.BackColor = System.Drawing.Color.DarkGray;
            this.Monsec.Controls.Add(this.mon1);
            this.Monsec.Controls.Add(this.mon12);
            this.Monsec.Controls.Add(this.mon11);
            this.Monsec.Controls.Add(this.mon10);
            this.Monsec.Controls.Add(this.mon9);
            this.Monsec.Controls.Add(this.mon8);
            this.Monsec.Controls.Add(this.mon7);
            this.Monsec.Controls.Add(this.mon6);
            this.Monsec.Controls.Add(this.mon5);
            this.Monsec.Controls.Add(this.label3);
            this.Monsec.Controls.Add(this.label134);
            this.Monsec.Controls.Add(this.label87);
            this.Monsec.Controls.Add(this.label90);
            this.Monsec.Controls.Add(this.mon2);
            this.Monsec.Controls.Add(this.mon3);
            this.Monsec.Controls.Add(this.mon4);
            this.Monsec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Monsec.Location = new System.Drawing.Point(43, 110);
            this.Monsec.Name = "Monsec";
            this.Monsec.Size = new System.Drawing.Size(403, 0);
            this.Monsec.TabIndex = 242;
            // 
            // mon1
            // 
            this.mon1.BackColor = System.Drawing.Color.Gainsboro;
            this.mon1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon1.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon1.Location = new System.Drawing.Point(3, 5);
            this.mon1.Name = "mon1";
            this.mon1.Size = new System.Drawing.Size(100, 100);
            this.mon1.TabIndex = 267;
            this.mon1.TabStop = false;
            this.mon1.Text = "January";
            this.mon1.UseVisualStyleBackColor = false;
            this.mon1.Click += new System.EventHandler(this.mon1_Click);
            // 
            // mon12
            // 
            this.mon12.BackColor = System.Drawing.Color.Gainsboro;
            this.mon12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon12.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon12.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon12.Location = new System.Drawing.Point(300, 203);
            this.mon12.Name = "mon12";
            this.mon12.Size = new System.Drawing.Size(100, 100);
            this.mon12.TabIndex = 266;
            this.mon12.TabStop = false;
            this.mon12.Text = "December";
            this.mon12.UseVisualStyleBackColor = false;
            this.mon12.Click += new System.EventHandler(this.mon12_Click);
            // 
            // mon11
            // 
            this.mon11.BackColor = System.Drawing.Color.Gainsboro;
            this.mon11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon11.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon11.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon11.Location = new System.Drawing.Point(201, 203);
            this.mon11.Name = "mon11";
            this.mon11.Size = new System.Drawing.Size(100, 100);
            this.mon11.TabIndex = 265;
            this.mon11.TabStop = false;
            this.mon11.Text = "November";
            this.mon11.UseVisualStyleBackColor = false;
            this.mon11.Click += new System.EventHandler(this.mon11_Click);
            // 
            // mon10
            // 
            this.mon10.BackColor = System.Drawing.Color.Gainsboro;
            this.mon10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon10.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon10.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon10.Location = new System.Drawing.Point(102, 203);
            this.mon10.Name = "mon10";
            this.mon10.Size = new System.Drawing.Size(100, 100);
            this.mon10.TabIndex = 264;
            this.mon10.TabStop = false;
            this.mon10.Text = "October";
            this.mon10.UseVisualStyleBackColor = false;
            this.mon10.Click += new System.EventHandler(this.mon10_Click);
            // 
            // mon9
            // 
            this.mon9.BackColor = System.Drawing.Color.Gainsboro;
            this.mon9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon9.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon9.Location = new System.Drawing.Point(3, 203);
            this.mon9.Name = "mon9";
            this.mon9.Size = new System.Drawing.Size(100, 100);
            this.mon9.TabIndex = 263;
            this.mon9.TabStop = false;
            this.mon9.Text = "September";
            this.mon9.UseVisualStyleBackColor = false;
            this.mon9.Click += new System.EventHandler(this.mon9_Click);
            // 
            // mon8
            // 
            this.mon8.BackColor = System.Drawing.Color.Gainsboro;
            this.mon8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon8.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon8.Location = new System.Drawing.Point(300, 104);
            this.mon8.Name = "mon8";
            this.mon8.Size = new System.Drawing.Size(100, 100);
            this.mon8.TabIndex = 262;
            this.mon8.TabStop = false;
            this.mon8.Text = "August";
            this.mon8.UseVisualStyleBackColor = false;
            this.mon8.Click += new System.EventHandler(this.mon8_Click);
            // 
            // mon7
            // 
            this.mon7.BackColor = System.Drawing.Color.Gainsboro;
            this.mon7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon7.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon7.Location = new System.Drawing.Point(201, 104);
            this.mon7.Name = "mon7";
            this.mon7.Size = new System.Drawing.Size(100, 100);
            this.mon7.TabIndex = 261;
            this.mon7.TabStop = false;
            this.mon7.Text = "July";
            this.mon7.UseVisualStyleBackColor = false;
            this.mon7.Click += new System.EventHandler(this.mon7_Click);
            // 
            // mon6
            // 
            this.mon6.BackColor = System.Drawing.Color.Gainsboro;
            this.mon6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon6.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon6.Location = new System.Drawing.Point(102, 104);
            this.mon6.Name = "mon6";
            this.mon6.Size = new System.Drawing.Size(100, 100);
            this.mon6.TabIndex = 260;
            this.mon6.TabStop = false;
            this.mon6.Text = "June";
            this.mon6.UseVisualStyleBackColor = false;
            this.mon6.Click += new System.EventHandler(this.mon6_Click);
            // 
            // mon5
            // 
            this.mon5.BackColor = System.Drawing.Color.Gainsboro;
            this.mon5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon5.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon5.Location = new System.Drawing.Point(3, 104);
            this.mon5.Name = "mon5";
            this.mon5.Size = new System.Drawing.Size(100, 100);
            this.mon5.TabIndex = 259;
            this.mon5.TabStop = false;
            this.mon5.Text = "May";
            this.mon5.UseVisualStyleBackColor = false;
            this.mon5.Click += new System.EventHandler(this.mon5_Click);
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Location = new System.Drawing.Point(400, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(3, 0);
            this.label3.TabIndex = 129;
            // 
            // label134
            // 
            this.label134.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label134.Dock = System.Windows.Forms.DockStyle.Top;
            this.label134.Location = new System.Drawing.Point(3, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(400, 5);
            this.label134.TabIndex = 130;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label87.Dock = System.Windows.Forms.DockStyle.Left;
            this.label87.Location = new System.Drawing.Point(0, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(3, 0);
            this.label87.TabIndex = 128;
            this.label87.Text = "label4";
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label90.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label90.Location = new System.Drawing.Point(0, -5);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(403, 5);
            this.label90.TabIndex = 127;
            // 
            // mon2
            // 
            this.mon2.BackColor = System.Drawing.Color.Gainsboro;
            this.mon2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon2.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon2.Location = new System.Drawing.Point(102, 5);
            this.mon2.Name = "mon2";
            this.mon2.Size = new System.Drawing.Size(100, 100);
            this.mon2.TabIndex = 268;
            this.mon2.TabStop = false;
            this.mon2.Text = "February";
            this.mon2.UseVisualStyleBackColor = false;
            this.mon2.Click += new System.EventHandler(this.mon2_Click);
            // 
            // mon3
            // 
            this.mon3.BackColor = System.Drawing.Color.Gainsboro;
            this.mon3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon3.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon3.Location = new System.Drawing.Point(201, 5);
            this.mon3.Name = "mon3";
            this.mon3.Size = new System.Drawing.Size(100, 100);
            this.mon3.TabIndex = 257;
            this.mon3.TabStop = false;
            this.mon3.Text = "March";
            this.mon3.UseVisualStyleBackColor = false;
            this.mon3.Click += new System.EventHandler(this.mon3_Click);
            // 
            // mon4
            // 
            this.mon4.BackColor = System.Drawing.Color.Gainsboro;
            this.mon4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon4.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon4.Location = new System.Drawing.Point(300, 5);
            this.mon4.Name = "mon4";
            this.mon4.Size = new System.Drawing.Size(100, 100);
            this.mon4.TabIndex = 258;
            this.mon4.TabStop = false;
            this.mon4.Text = "April";
            this.mon4.UseVisualStyleBackColor = false;
            this.mon4.Click += new System.EventHandler(this.mon4_Click);
            // 
            // EventPanel
            // 
            this.EventPanel.BackColor = System.Drawing.Color.Gainsboro;
            this.EventPanel.Controls.Add(this.checkBox3);
            this.EventPanel.Controls.Add(this.checkBox2);
            this.EventPanel.Controls.Add(this.checkBox1);
            this.EventPanel.Controls.Add(this.label21);
            this.EventPanel.Controls.Add(this.label22);
            this.EventPanel.Controls.Add(this.label19);
            this.EventPanel.Controls.Add(this.label20);
            this.EventPanel.Controls.Add(this.label18);
            this.EventPanel.Controls.Add(this.label17);
            this.EventPanel.Controls.Add(this.label16);
            this.EventPanel.Controls.Add(this.label13);
            this.EventPanel.Controls.Add(this.label7);
            this.EventPanel.Controls.Add(this.label2);
            this.EventPanel.Controls.Add(this.buttonEnd);
            this.EventPanel.Controls.Add(this.label135);
            this.EventPanel.Location = new System.Drawing.Point(140, 70);
            this.EventPanel.Name = "EventPanel";
            this.EventPanel.Size = new System.Drawing.Size(209, 354);
            this.EventPanel.TabIndex = 243;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(162, 212);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 253;
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(162, 151);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 252;
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(162, 87);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 251;
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(33, 243);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 18);
            this.label21.TabIndex = 250;
            this.label21.Text = "Details - Time";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(32, 209);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(119, 23);
            this.label22.TabIndex = 249;
            this.label22.Text = "Reminder 3";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(33, 176);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(98, 18);
            this.label19.TabIndex = 248;
            this.label19.Text = "Details - Time";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(32, 144);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(119, 23);
            this.label20.TabIndex = 247;
            this.label20.Text = "Reminder 2";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(33, 111);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(98, 18);
            this.label18.TabIndex = 246;
            this.label18.Text = "Details - Time";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Impact", 20.25F);
            this.label17.Location = new System.Drawing.Point(35, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(139, 34);
            this.label17.TabIndex = 245;
            this.label17.Text = "MM . DD . YY";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(32, 81);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(118, 23);
            this.label16.TabIndex = 244;
            this.label16.Text = "Reminder 1";
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label13.ForeColor = System.Drawing.Color.Transparent;
            this.label13.Location = new System.Drawing.Point(205, 5);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(4, 348);
            this.label13.TabIndex = 166;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label7.ForeColor = System.Drawing.Color.Transparent;
            this.label7.Location = new System.Drawing.Point(0, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(4, 348);
            this.label7.TabIndex = 165;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.ForeColor = System.Drawing.Color.Transparent;
            this.label2.Location = new System.Drawing.Point(0, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 164;
            // 
            // buttonEnd
            // 
            this.buttonEnd.BackColor = System.Drawing.Color.DarkGray;
            this.buttonEnd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEnd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonEnd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.buttonEnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEnd.Location = new System.Drawing.Point(42, 303);
            this.buttonEnd.Name = "buttonEnd";
            this.buttonEnd.Size = new System.Drawing.Size(135, 25);
            this.buttonEnd.TabIndex = 163;
            this.buttonEnd.TabStop = false;
            this.buttonEnd.Text = "OK";
            this.buttonEnd.UseVisualStyleBackColor = false;
            this.buttonEnd.Click += new System.EventHandler(this.buttonEnd_Click);
            // 
            // label135
            // 
            this.label135.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label135.Dock = System.Windows.Forms.DockStyle.Top;
            this.label135.ForeColor = System.Drawing.Color.Transparent;
            this.label135.Location = new System.Drawing.Point(0, 0);
            this.label135.Name = "label135";
            this.label135.Size = new System.Drawing.Size(209, 5);
            this.label135.TabIndex = 125;
            // 
            // dashbordgrow
            // 
            this.dashbordgrow.Interval = 1;
            this.dashbordgrow.Tick += new System.EventHandler(this.dashbordgrow_Tick);
            // 
            // dashbordshrink
            // 
            this.dashbordshrink.Interval = 1;
            this.dashbordshrink.Tick += new System.EventHandler(this.dashbordshrink_Tick);
            // 
            // Monsecgrow
            // 
            this.Monsecgrow.Interval = 1;
            this.Monsecgrow.Tick += new System.EventHandler(this.Monsecgrow_Tick);
            // 
            // Monsecshrink
            // 
            this.Monsecshrink.Interval = 1;
            this.Monsecshrink.Tick += new System.EventHandler(this.Monsecshrink_Tick);
            // 
            // JanuaryGrow
            // 
            this.JanuaryGrow.Interval = 1;
            this.JanuaryGrow.Tick += new System.EventHandler(this.JanuaryGrow_Tick);
            // 
            // JanuaryShrink
            // 
            this.JanuaryShrink.Interval = 1;
            this.JanuaryShrink.Tick += new System.EventHandler(this.JanuaryShrink_Tick);
            // 
            // FebruaryGrow
            // 
            this.FebruaryGrow.Interval = 1;
            this.FebruaryGrow.Tick += new System.EventHandler(this.FebruaryGrow_Tick);
            // 
            // FebruaryShrink
            // 
            this.FebruaryShrink.Interval = 1;
            this.FebruaryShrink.Tick += new System.EventHandler(this.FebruaryShrink_Tick);
            // 
            // MarchGrow
            // 
            this.MarchGrow.Interval = 1;
            this.MarchGrow.Tick += new System.EventHandler(this.MarchGrow_Tick);
            // 
            // MarchShrink
            // 
            this.MarchShrink.Interval = 1;
            this.MarchShrink.Tick += new System.EventHandler(this.MarchShrink_Tick);
            // 
            // AprilGrow
            // 
            this.AprilGrow.Interval = 1;
            this.AprilGrow.Tick += new System.EventHandler(this.AprilGrow_Tick);
            // 
            // AprilShrink
            // 
            this.AprilShrink.Interval = 1;
            this.AprilShrink.Tick += new System.EventHandler(this.AprilShrink_Tick);
            // 
            // MayGrow
            // 
            this.MayGrow.Interval = 1;
            this.MayGrow.Tick += new System.EventHandler(this.MayGrow_Tick);
            // 
            // MayShrink
            // 
            this.MayShrink.Interval = 1;
            this.MayShrink.Tick += new System.EventHandler(this.MayShrink_Tick);
            // 
            // JuneGrow
            // 
            this.JuneGrow.Interval = 1;
            this.JuneGrow.Tick += new System.EventHandler(this.JuneGrow_Tick);
            // 
            // JuneShrink
            // 
            this.JuneShrink.Interval = 1;
            this.JuneShrink.Tick += new System.EventHandler(this.JuneShrink_Tick);
            // 
            // JulyGrow
            // 
            this.JulyGrow.Interval = 1;
            this.JulyGrow.Tick += new System.EventHandler(this.JulyGrow_Tick);
            // 
            // JulyShrink
            // 
            this.JulyShrink.Interval = 1;
            this.JulyShrink.Tick += new System.EventHandler(this.JulyShrink_Tick);
            // 
            // OctoberShrink
            // 
            this.OctoberShrink.Interval = 1;
            this.OctoberShrink.Tick += new System.EventHandler(this.OctoberShrink_Tick);
            // 
            // AugustGrow
            // 
            this.AugustGrow.Interval = 1;
            this.AugustGrow.Tick += new System.EventHandler(this.AugustGrow_Tick);
            // 
            // AugustShrink
            // 
            this.AugustShrink.Interval = 1;
            this.AugustShrink.Tick += new System.EventHandler(this.AugustShrink_Tick);
            // 
            // SeptemberGrow
            // 
            this.SeptemberGrow.Interval = 1;
            this.SeptemberGrow.Tick += new System.EventHandler(this.SeptemberGrow_Tick);
            // 
            // SeptemberShrink
            // 
            this.SeptemberShrink.Interval = 1;
            this.SeptemberShrink.Tick += new System.EventHandler(this.SeptemberShrink_Tick);
            // 
            // OctoberGrow
            // 
            this.OctoberGrow.Interval = 1;
            this.OctoberGrow.Tick += new System.EventHandler(this.OctoberGrow_Tick);
            // 
            // NovemberGrow
            // 
            this.NovemberGrow.Interval = 1;
            this.NovemberGrow.Tick += new System.EventHandler(this.NovemberGrow_Tick);
            // 
            // NovemberShrink
            // 
            this.NovemberShrink.Interval = 1;
            this.NovemberShrink.Tick += new System.EventHandler(this.NovemberShrink_Tick);
            // 
            // Minimize
            // 
            this.Minimize.BackColor = System.Drawing.Color.Black;
            this.Minimize.BackgroundImage = global::Calendar_App.Properties.Resources.Minimize2;
            this.Minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minimize.ForeColor = System.Drawing.Color.Transparent;
            this.Minimize.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Minimize.Location = new System.Drawing.Point(435, 5);
            this.Minimize.Margin = new System.Windows.Forms.Padding(0);
            this.Minimize.Name = "Minimize";
            this.Minimize.Size = new System.Drawing.Size(20, 20);
            this.Minimize.TabIndex = 128;
            this.Minimize.TabStop = false;
            this.Minimize.UseVisualStyleBackColor = false;
            this.Minimize.Click += new System.EventHandler(this.Minimize_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Black;
            this.Close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Close.BackgroundImage")));
            this.Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Close.ForeColor = System.Drawing.Color.Transparent;
            this.Close.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Close.Location = new System.Drawing.Point(459, 5);
            this.Close.Margin = new System.Windows.Forms.Padding(0);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(20, 20);
            this.Close.TabIndex = 127;
            this.Close.TabStop = false;
            this.Close.UseVisualStyleBackColor = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // dashbord1
            // 
            this.dashbord1.BackColor = System.Drawing.Color.Silver;
            this.dashbord1.Location = new System.Drawing.Point(3, 32);
            this.dashbord1.Name = "dashbord1";
            this.dashbord1.Size = new System.Drawing.Size(0, 392);
            this.dashbord1.TabIndex = 241;
            // 
            // Calendar2018
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(488, 433);
            this.Controls.Add(this.bottomborder);
            this.Controls.Add(this.BorderRight);
            this.Controls.Add(this.BorderLeft);
            this.Controls.Add(this.EventPanel);
            this.Controls.Add(this.dashbord1);
            this.Controls.Add(this.Monsec);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.January);
            this.Controls.Add(this.February);
            this.Controls.Add(this.March);
            this.Controls.Add(this.April);
            this.Controls.Add(this.May);
            this.Controls.Add(this.June);
            this.Controls.Add(this.July);
            this.Controls.Add(this.August);
            this.Controls.Add(this.September);
            this.Controls.Add(this.October);
            this.Controls.Add(this.November);
            this.Controls.Add(this.December);
            this.Controls.Add(this.Minimize);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.topborder);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Calendar2018";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Calendar2018_Load);
            this.Click += new System.EventHandler(this.Calendar2018_Click);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.January.ResumeLayout(false);
            this.datepanel.ResumeLayout(false);
            this.February.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.March.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.April.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.May.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.June.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.July.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.August.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.September.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.October.ResumeLayout(false);
            this.panel10.ResumeLayout(false);
            this.November.ResumeLayout(false);
            this.panel11.ResumeLayout(false);
            this.December.ResumeLayout(false);
            this.panel12.ResumeLayout(false);
            this.Monsec.ResumeLayout(false);
            this.EventPanel.ResumeLayout(false);
            this.EventPanel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label bottomborder;
        private System.Windows.Forms.Label topborder;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Button Minimize;
        private System.Windows.Forms.Button Dashbord;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label BorderRight;
        private System.Windows.Forms.Label BorderLeft;
        private System.Windows.Forms.Panel January;
        private System.Windows.Forms.Panel datepanel;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button RightButton;
        private System.Windows.Forms.Panel February;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Panel March;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Panel April;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Panel May;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button20;
        private Heading heading5;
        private System.Windows.Forms.Panel June;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.Label label270;
        private Heading heading6;
        private System.Windows.Forms.Panel July;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.Label label283;
        private System.Windows.Forms.Label label285;
        private System.Windows.Forms.Label label287;
        private System.Windows.Forms.Label label289;
        private System.Windows.Forms.Label label292;
        private System.Windows.Forms.Label label300;
        private Heading heading7;
        private System.Windows.Forms.Panel August;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label321;
        private System.Windows.Forms.Label label323;
        private System.Windows.Forms.Label label325;
        private System.Windows.Forms.Label label327;
        private System.Windows.Forms.Label label329;
        private System.Windows.Forms.Label label331;
        private System.Windows.Forms.Label label333;
        private System.Windows.Forms.Label label343;
        private System.Windows.Forms.Label label344;
        private System.Windows.Forms.Label label338;
        private System.Windows.Forms.Label label361;
        private System.Windows.Forms.Label label362;
        private Heading heading8;
        private System.Windows.Forms.Panel September;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label365;
        private System.Windows.Forms.Label label368;
        private System.Windows.Forms.Label label384;
        private System.Windows.Forms.Label label388;
        private System.Windows.Forms.Label label389;
        private System.Windows.Forms.Label label391;
        private System.Windows.Forms.Label label411;
        private System.Windows.Forms.Label label369;
        private System.Windows.Forms.Label label375;
        private System.Windows.Forms.Label label379;
        private System.Windows.Forms.Label label381;
        private System.Windows.Forms.Label label383;
        private System.Windows.Forms.Label label385;
        private System.Windows.Forms.Label label408;
        private Heading heading9;
        private System.Windows.Forms.Panel October;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label414;
        private System.Windows.Forms.Label label428;
        private System.Windows.Forms.Label label429;
        private System.Windows.Forms.Label label430;
        private System.Windows.Forms.Label label432;
        private System.Windows.Forms.Label label434;
        private System.Windows.Forms.Label label435;
        private System.Windows.Forms.Label label436;
        private System.Windows.Forms.Label label437;
        private System.Windows.Forms.Label label438;
        private System.Windows.Forms.Label label439;
        private Heading heading10;
        private System.Windows.Forms.Panel November;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label470;
        private System.Windows.Forms.Label label471;
        private System.Windows.Forms.Label label472;
        private System.Windows.Forms.Label label504;
        private System.Windows.Forms.Label label474;
        private System.Windows.Forms.Label label475;
        private System.Windows.Forms.Label label477;
        private System.Windows.Forms.Label label479;
        private System.Windows.Forms.Label label480;
        private System.Windows.Forms.Label label481;
        private System.Windows.Forms.Label label482;
        private System.Windows.Forms.Label label484;
        private Heading heading11;
        private System.Windows.Forms.Panel December;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label506;
        private System.Windows.Forms.Label label514;
        private System.Windows.Forms.Label label516;
        private System.Windows.Forms.Label label517;
        private System.Windows.Forms.Label label518;
        private System.Windows.Forms.Label label519;
        private System.Windows.Forms.Label label522;
        private System.Windows.Forms.Label label527;
        private System.Windows.Forms.Label label528;
        private System.Windows.Forms.Label label529;
        private System.Windows.Forms.Label label530;
        private Heading heading12;
        private Dashbord dashbord1;
        private System.Windows.Forms.Panel Monsec;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Button mon12;
        private System.Windows.Forms.Button mon11;
        private System.Windows.Forms.Button mon10;
        private System.Windows.Forms.Button mon9;
        private System.Windows.Forms.Button mon8;
        private System.Windows.Forms.Button mon7;
        private System.Windows.Forms.Button mon6;
        private System.Windows.Forms.Button mon5;
        private System.Windows.Forms.Button mon4;
        private System.Windows.Forms.Button mon3;
        private System.Windows.Forms.Button mon1;
        private System.Windows.Forms.Button mon2;
        private System.Windows.Forms.Panel EventPanel;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Button buttonEnd;
        private System.Windows.Forms.Button jan;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button Feb;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private Heading heading1;
        private Heading heading2;
        private Heading heading3;
        private Heading heading4;
        private System.Windows.Forms.Button Ma;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Button button133;
        private System.Windows.Forms.Button button134;
        private System.Windows.Forms.Button button135;
        private System.Windows.Forms.Button button136;
        private System.Windows.Forms.Button button137;
        private System.Windows.Forms.Button button138;
        private System.Windows.Forms.Button button139;
        private System.Windows.Forms.Button button140;
        private System.Windows.Forms.Button button141;
        private System.Windows.Forms.Button button142;
        private System.Windows.Forms.Button Mar;
        private System.Windows.Forms.Button Apr;
        private System.Windows.Forms.Button button144;
        private System.Windows.Forms.Button button145;
        private System.Windows.Forms.Button button146;
        private System.Windows.Forms.Button button147;
        private System.Windows.Forms.Button button148;
        private System.Windows.Forms.Button button149;
        private System.Windows.Forms.Button button150;
        private System.Windows.Forms.Button button151;
        private System.Windows.Forms.Button button152;
        private System.Windows.Forms.Button button153;
        private System.Windows.Forms.Button button154;
        private System.Windows.Forms.Button button155;
        private System.Windows.Forms.Button button156;
        private System.Windows.Forms.Button button157;
        private System.Windows.Forms.Button button158;
        private System.Windows.Forms.Button button159;
        private System.Windows.Forms.Button button160;
        private System.Windows.Forms.Button button161;
        private System.Windows.Forms.Button button162;
        private System.Windows.Forms.Button button163;
        private System.Windows.Forms.Button button164;
        private System.Windows.Forms.Button button165;
        private System.Windows.Forms.Button button166;
        private System.Windows.Forms.Button button167;
        private System.Windows.Forms.Button button168;
        private System.Windows.Forms.Button button169;
        private System.Windows.Forms.Button button170;
        private System.Windows.Forms.Button button171;
        private System.Windows.Forms.Button button172;
        private System.Windows.Forms.Button button173;
        private System.Windows.Forms.Button Jun;
        private System.Windows.Forms.Button button174;
        private System.Windows.Forms.Button button175;
        private System.Windows.Forms.Button button176;
        private System.Windows.Forms.Button button177;
        private System.Windows.Forms.Button button178;
        private System.Windows.Forms.Button button179;
        private System.Windows.Forms.Button button180;
        private System.Windows.Forms.Button button181;
        private System.Windows.Forms.Button button182;
        private System.Windows.Forms.Button button183;
        private System.Windows.Forms.Button button184;
        private System.Windows.Forms.Button button185;
        private System.Windows.Forms.Button button186;
        private System.Windows.Forms.Button button187;
        private System.Windows.Forms.Button button188;
        private System.Windows.Forms.Button button189;
        private System.Windows.Forms.Button button190;
        private System.Windows.Forms.Button button191;
        private System.Windows.Forms.Button button192;
        private System.Windows.Forms.Button button193;
        private System.Windows.Forms.Button button194;
        private System.Windows.Forms.Button button196;
        private System.Windows.Forms.Button button197;
        private System.Windows.Forms.Button button195;
        private System.Windows.Forms.Button button198;
        private System.Windows.Forms.Button button199;
        private System.Windows.Forms.Button button200;
        private System.Windows.Forms.Button button201;
        private System.Windows.Forms.Button button202;
        private System.Windows.Forms.Button button203;
        private System.Windows.Forms.Button Jul;
        private System.Windows.Forms.Button button204;
        private System.Windows.Forms.Button button205;
        private System.Windows.Forms.Button button206;
        private System.Windows.Forms.Button button207;
        private System.Windows.Forms.Button button208;
        private System.Windows.Forms.Button button209;
        private System.Windows.Forms.Button button210;
        private System.Windows.Forms.Button button211;
        private System.Windows.Forms.Button button212;
        private System.Windows.Forms.Button button213;
        private System.Windows.Forms.Button button214;
        private System.Windows.Forms.Button button215;
        private System.Windows.Forms.Button button216;
        private System.Windows.Forms.Button button217;
        private System.Windows.Forms.Button button218;
        private System.Windows.Forms.Button button219;
        private System.Windows.Forms.Button button220;
        private System.Windows.Forms.Button button221;
        private System.Windows.Forms.Button button222;
        private System.Windows.Forms.Button button223;
        private System.Windows.Forms.Button button224;
        private System.Windows.Forms.Button button225;
        private System.Windows.Forms.Button button226;
        private System.Windows.Forms.Button button227;
        private System.Windows.Forms.Button button228;
        private System.Windows.Forms.Button button229;
        private System.Windows.Forms.Button button230;
        private System.Windows.Forms.Button button231;
        private System.Windows.Forms.Button button232;
        private System.Windows.Forms.Button button233;
        private System.Windows.Forms.Button button234;
        private System.Windows.Forms.Button Aug;
        private System.Windows.Forms.Button button235;
        private System.Windows.Forms.Button button236;
        private System.Windows.Forms.Button button237;
        private System.Windows.Forms.Button button238;
        private System.Windows.Forms.Button button239;
        private System.Windows.Forms.Button button240;
        private System.Windows.Forms.Button button241;
        private System.Windows.Forms.Button button242;
        private System.Windows.Forms.Button button243;
        private System.Windows.Forms.Button button244;
        private System.Windows.Forms.Button button245;
        private System.Windows.Forms.Button button246;
        private System.Windows.Forms.Button button247;
        private System.Windows.Forms.Button button248;
        private System.Windows.Forms.Button button249;
        private System.Windows.Forms.Button button250;
        private System.Windows.Forms.Button button251;
        private System.Windows.Forms.Button button252;
        private System.Windows.Forms.Button button253;
        private System.Windows.Forms.Button button254;
        private System.Windows.Forms.Button button255;
        private System.Windows.Forms.Button button256;
        private System.Windows.Forms.Button button257;
        private System.Windows.Forms.Button button258;
        private System.Windows.Forms.Button button259;
        private System.Windows.Forms.Button button260;
        private System.Windows.Forms.Button button261;
        private System.Windows.Forms.Button button262;
        private System.Windows.Forms.Button button263;
        private System.Windows.Forms.Button button264;
        private System.Windows.Forms.Button button265;
        private System.Windows.Forms.Button Sep;
        private System.Windows.Forms.Button button266;
        private System.Windows.Forms.Button button267;
        private System.Windows.Forms.Button button268;
        private System.Windows.Forms.Button button269;
        private System.Windows.Forms.Button button270;
        private System.Windows.Forms.Button button271;
        private System.Windows.Forms.Button button272;
        private System.Windows.Forms.Button button273;
        private System.Windows.Forms.Button button274;
        private System.Windows.Forms.Button button275;
        private System.Windows.Forms.Button button276;
        private System.Windows.Forms.Button button277;
        private System.Windows.Forms.Button button278;
        private System.Windows.Forms.Button button279;
        private System.Windows.Forms.Button button280;
        private System.Windows.Forms.Button button281;
        private System.Windows.Forms.Button button282;
        private System.Windows.Forms.Button button283;
        private System.Windows.Forms.Button button284;
        private System.Windows.Forms.Button button285;
        private System.Windows.Forms.Button button286;
        private System.Windows.Forms.Button button289;
        private System.Windows.Forms.Button button287;
        private System.Windows.Forms.Button button288;
        private System.Windows.Forms.Button button290;
        private System.Windows.Forms.Button button291;
        private System.Windows.Forms.Button button292;
        private System.Windows.Forms.Button button293;
        private System.Windows.Forms.Button button294;
        private System.Windows.Forms.Button button296;
        private System.Windows.Forms.Button Oct;
        private System.Windows.Forms.Button button295;
        private System.Windows.Forms.Button button297;
        private System.Windows.Forms.Button button298;
        private System.Windows.Forms.Button button299;
        private System.Windows.Forms.Button button300;
        private System.Windows.Forms.Button button301;
        private System.Windows.Forms.Button button302;
        private System.Windows.Forms.Button button303;
        private System.Windows.Forms.Button button304;
        private System.Windows.Forms.Button button305;
        private System.Windows.Forms.Button button306;
        private System.Windows.Forms.Button button307;
        private System.Windows.Forms.Button button308;
        private System.Windows.Forms.Button button309;
        private System.Windows.Forms.Button button310;
        private System.Windows.Forms.Button button311;
        private System.Windows.Forms.Button button312;
        private System.Windows.Forms.Button button313;
        private System.Windows.Forms.Button button314;
        private System.Windows.Forms.Button button315;
        private System.Windows.Forms.Button button316;
        private System.Windows.Forms.Button button317;
        private System.Windows.Forms.Button button318;
        private System.Windows.Forms.Button button319;
        private System.Windows.Forms.Button button320;
        private System.Windows.Forms.Button button321;
        private System.Windows.Forms.Button button322;
        private System.Windows.Forms.Button button323;
        private System.Windows.Forms.Button button324;
        private System.Windows.Forms.Button button325;
        private System.Windows.Forms.Button button326;
        private System.Windows.Forms.Button Nov;
        private System.Windows.Forms.Button button327;
        private System.Windows.Forms.Button button328;
        private System.Windows.Forms.Button button329;
        private System.Windows.Forms.Button button330;
        private System.Windows.Forms.Button button331;
        private System.Windows.Forms.Button button332;
        private System.Windows.Forms.Button button333;
        private System.Windows.Forms.Button button334;
        private System.Windows.Forms.Button button335;
        private System.Windows.Forms.Button button336;
        private System.Windows.Forms.Button button337;
        private System.Windows.Forms.Button button338;
        private System.Windows.Forms.Button button339;
        private System.Windows.Forms.Button button340;
        private System.Windows.Forms.Button button341;
        private System.Windows.Forms.Button button342;
        private System.Windows.Forms.Button button343;
        private System.Windows.Forms.Button button344;
        private System.Windows.Forms.Button button345;
        private System.Windows.Forms.Button button346;
        private System.Windows.Forms.Button button347;
        private System.Windows.Forms.Button button348;
        private System.Windows.Forms.Button button349;
        private System.Windows.Forms.Button button350;
        private System.Windows.Forms.Button button351;
        private System.Windows.Forms.Button button352;
        private System.Windows.Forms.Button button353;
        private System.Windows.Forms.Button button354;
        private System.Windows.Forms.Button button355;
        private System.Windows.Forms.Button button356;
        private System.Windows.Forms.Button Dec;
        private System.Windows.Forms.Button button357;
        private System.Windows.Forms.Button button358;
        private System.Windows.Forms.Button button359;
        private System.Windows.Forms.Button button360;
        private System.Windows.Forms.Button button361;
        private System.Windows.Forms.Button button362;
        private System.Windows.Forms.Button button363;
        private System.Windows.Forms.Button button364;
        private System.Windows.Forms.Button button365;
        private System.Windows.Forms.Button button366;
        private System.Windows.Forms.Button button367;
        private System.Windows.Forms.Button button368;
        private System.Windows.Forms.Button button369;
        private System.Windows.Forms.Button button370;
        private System.Windows.Forms.Button button371;
        private System.Windows.Forms.Button button372;
        private System.Windows.Forms.Button button373;
        private System.Windows.Forms.Button button374;
        private System.Windows.Forms.Button button375;
        private System.Windows.Forms.Button button376;
        private System.Windows.Forms.Button button377;
        private System.Windows.Forms.Button button378;
        private System.Windows.Forms.Button button379;
        private System.Windows.Forms.Button button380;
        private System.Windows.Forms.Button button381;
        private System.Windows.Forms.Button button382;
        private System.Windows.Forms.Button button383;
        private System.Windows.Forms.Button button384;
        private System.Windows.Forms.Button button385;
        private System.Windows.Forms.Button button386;
        private System.Windows.Forms.Button button387;
        private System.Windows.Forms.Timer dashbordgrow;
        private System.Windows.Forms.Timer dashbordshrink;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Timer Monsecgrow;
        private System.Windows.Forms.Timer Monsecshrink;
        private System.Windows.Forms.Timer JanuaryGrow;
        private System.Windows.Forms.Timer JanuaryShrink;
        private System.Windows.Forms.Timer FebruaryGrow;
        private System.Windows.Forms.Timer FebruaryShrink;
        private System.Windows.Forms.Timer MarchGrow;
        private System.Windows.Forms.Timer MarchShrink;
        private System.Windows.Forms.Timer AprilGrow;
        private System.Windows.Forms.Timer AprilShrink;
        private System.Windows.Forms.Timer MayGrow;
        private System.Windows.Forms.Timer MayShrink;
        private System.Windows.Forms.Timer JuneGrow;
        private System.Windows.Forms.Timer JuneShrink;
        private System.Windows.Forms.Timer JulyGrow;
        private System.Windows.Forms.Timer JulyShrink;
        private System.Windows.Forms.Timer OctoberShrink;
        private System.Windows.Forms.Timer AugustGrow;
        private System.Windows.Forms.Timer AugustShrink;
        private System.Windows.Forms.Timer SeptemberGrow;
        private System.Windows.Forms.Timer SeptemberShrink;
        private System.Windows.Forms.Timer OctoberGrow;
        private System.Windows.Forms.Timer NovemberGrow;
        private System.Windows.Forms.Timer NovemberShrink;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
    }
}