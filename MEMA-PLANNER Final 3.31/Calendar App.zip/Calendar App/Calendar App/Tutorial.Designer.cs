﻿namespace Calendar_App
{
    partial class Tutorial
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tutorial));
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label42 = new System.Windows.Forms.Label();
            this.TutorialStart = new System.Windows.Forms.Panel();
            this.label53 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.Tutorial1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.label44 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Tutorial2 = new System.Windows.Forms.Panel();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.Tutorial4 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.BorderLeft = new System.Windows.Forms.Label();
            this.BorderRight = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.Dashbord = new System.Windows.Forms.Button();
            this.Minimize = new System.Windows.Forms.Button();
            this.Close = new System.Windows.Forms.Button();
            this.topborder = new System.Windows.Forms.Label();
            this.bottomborder = new System.Windows.Forms.Label();
            this.January = new System.Windows.Forms.Panel();
            this.jan = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.RightButton = new System.Windows.Forms.Button();
            this.heading2 = new Calendar_App.Heading();
            this.datepanel = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.Tutorial3 = new System.Windows.Forms.Panel();
            this.label70 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.Monsec = new System.Windows.Forms.Panel();
            this.mon1 = new System.Windows.Forms.Button();
            this.mon12 = new System.Windows.Forms.Button();
            this.mon11 = new System.Windows.Forms.Button();
            this.mon10 = new System.Windows.Forms.Button();
            this.mon9 = new System.Windows.Forms.Button();
            this.mon8 = new System.Windows.Forms.Button();
            this.mon7 = new System.Windows.Forms.Button();
            this.mon6 = new System.Windows.Forms.Button();
            this.mon5 = new System.Windows.Forms.Button();
            this.mon4 = new System.Windows.Forms.Button();
            this.mon3 = new System.Windows.Forms.Button();
            this.label71 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.mon2 = new System.Windows.Forms.Button();
            this.Tutorial5 = new System.Windows.Forms.Panel();
            this.button17 = new System.Windows.Forms.Button();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.button13 = new System.Windows.Forms.Button();
            this.label76 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.TutorialEnd = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.buttonEnd = new System.Windows.Forms.Button();
            this.dashbord1 = new Calendar_App.Dashbord();
            this.TutorialStart.SuspendLayout();
            this.Tutorial1.SuspendLayout();
            this.Tutorial2.SuspendLayout();
            this.Tutorial4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.January.SuspendLayout();
            this.datepanel.SuspendLayout();
            this.Tutorial3.SuspendLayout();
            this.Monsec.SuspendLayout();
            this.Tutorial5.SuspendLayout();
            this.TutorialEnd.SuspendLayout();
            this.SuspendLayout();
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(19, 108);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(135, 25);
            this.button2.TabIndex = 160;
            this.button2.TabStop = false;
            this.button2.Text = "Yes";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(192, 108);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(135, 25);
            this.button3.TabIndex = 161;
            this.button3.TabStop = false;
            this.button3.Text = "No";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label42
            // 
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label42.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(40, 31);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(266, 47);
            this.label42.TabIndex = 159;
            this.label42.Text = "Before using the App\r\nWould You like a quick tutorial";
            this.label42.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // TutorialStart
            // 
            this.TutorialStart.BackColor = System.Drawing.Color.Gray;
            this.TutorialStart.Controls.Add(this.label53);
            this.TutorialStart.Controls.Add(this.label63);
            this.TutorialStart.Controls.Add(this.label9);
            this.TutorialStart.Controls.Add(this.label51);
            this.TutorialStart.Controls.Add(this.label42);
            this.TutorialStart.Controls.Add(this.button3);
            this.TutorialStart.Controls.Add(this.button2);
            this.TutorialStart.Location = new System.Drawing.Point(71, 136);
            this.TutorialStart.Name = "TutorialStart";
            this.TutorialStart.Size = new System.Drawing.Size(346, 161);
            this.TutorialStart.TabIndex = 265;
            // 
            // label53
            // 
            this.label53.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label53.Dock = System.Windows.Forms.DockStyle.Right;
            this.label53.Location = new System.Drawing.Point(343, 5);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(3, 151);
            this.label53.TabIndex = 246;
            // 
            // label63
            // 
            this.label63.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label63.Dock = System.Windows.Forms.DockStyle.Left;
            this.label63.Location = new System.Drawing.Point(0, 5);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(3, 151);
            this.label63.TabIndex = 245;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label9.Dock = System.Windows.Forms.DockStyle.Top;
            this.label9.Location = new System.Drawing.Point(0, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(346, 5);
            this.label9.TabIndex = 244;
            // 
            // label51
            // 
            this.label51.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label51.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label51.Location = new System.Drawing.Point(0, 156);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(346, 5);
            this.label51.TabIndex = 243;
            // 
            // Tutorial1
            // 
            this.Tutorial1.BackColor = System.Drawing.Color.Gray;
            this.Tutorial1.Controls.Add(this.label4);
            this.Tutorial1.Controls.Add(this.label1);
            this.Tutorial1.Controls.Add(this.label3);
            this.Tutorial1.Controls.Add(this.button5);
            this.Tutorial1.Controls.Add(this.label44);
            this.Tutorial1.Controls.Add(this.label43);
            this.Tutorial1.Controls.Add(this.button1);
            this.Tutorial1.Location = new System.Drawing.Point(2, 32);
            this.Tutorial1.Name = "Tutorial1";
            this.Tutorial1.Size = new System.Drawing.Size(441, 148);
            this.Tutorial1.TabIndex = 266;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Location = new System.Drawing.Point(0, 143);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(437, 5);
            this.label4.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label1.Dock = System.Windows.Forms.DockStyle.Right;
            this.label1.Location = new System.Drawing.Point(437, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(2, 148);
            this.label1.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label3.Dock = System.Windows.Forms.DockStyle.Right;
            this.label3.Location = new System.Drawing.Point(439, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(2, 148);
            this.label3.TabIndex = 16;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.DarkGray;
            this.button5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(153, 108);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(135, 25);
            this.button5.TabIndex = 15;
            this.button5.Text = "Next";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label44
            // 
            this.label44.AllowDrop = true;
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(43, 43);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(388, 57);
            this.label44.TabIndex = 14;
            this.label44.Text = "This will make the dashbord appear where in you can\r\nsee your account, change the" +
    " theme of the planner,\r\nand log out";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(41, 5);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(176, 29);
            this.label43.TabIndex = 13;
            this.label43.Text = "Dashbord Button";
            // 
            // button1
            // 
            this.button1.BackgroundImage = global::Calendar_App.Properties.Resources.Button;
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(8, 5);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(29, 29);
            this.button1.TabIndex = 12;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Tutorial2
            // 
            this.Tutorial2.BackColor = System.Drawing.Color.Gray;
            this.Tutorial2.Controls.Add(this.button10);
            this.Tutorial2.Controls.Add(this.button9);
            this.Tutorial2.Controls.Add(this.label6);
            this.Tutorial2.Controls.Add(this.button11);
            this.Tutorial2.Controls.Add(this.button8);
            this.Tutorial2.Controls.Add(this.label48);
            this.Tutorial2.Controls.Add(this.label47);
            this.Tutorial2.Location = new System.Drawing.Point(3, 31);
            this.Tutorial2.Name = "Tutorial2";
            this.Tutorial2.Size = new System.Drawing.Size(484, 148);
            this.Tutorial2.TabIndex = 267;
            // 
            // button10
            // 
            this.button10.BackgroundImage = global::Calendar_App.Properties.Resources.Left2;
            this.button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button10.FlatAppearance.BorderSize = 0;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(4, 43);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(30, 30);
            this.button10.TabIndex = 17;
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.BackgroundImage = global::Calendar_App.Properties.Resources.Right2;
            this.button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button9.FlatAppearance.BorderSize = 0;
            this.button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(451, 43);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(30, 30);
            this.button9.TabIndex = 273;
            this.button9.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label6.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label6.Location = new System.Drawing.Point(0, 143);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(484, 5);
            this.label6.TabIndex = 274;
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.Color.DarkGray;
            this.button11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button11.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(245, 101);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 18;
            this.button11.Text = "Next";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.DarkGray;
            this.button8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(164, 101);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 15;
            this.button8.Text = "Back";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(122, 8);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(241, 29);
            this.label48.TabIndex = 13;
            this.label48.Text = "Month Selector Buttons";
            // 
            // label47
            // 
            this.label47.AllowDrop = true;
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(53, 43);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(379, 38);
            this.label47.TabIndex = 14;
            this.label47.Text = "This buttons will allow you scroll thru the months of\r\nthis calender";
            // 
            // Tutorial4
            // 
            this.Tutorial4.BackColor = System.Drawing.Color.Gray;
            this.Tutorial4.Controls.Add(this.label7);
            this.Tutorial4.Controls.Add(this.label8);
            this.Tutorial4.Controls.Add(this.button7);
            this.Tutorial4.Controls.Add(this.label49);
            this.Tutorial4.Controls.Add(this.label50);
            this.Tutorial4.Controls.Add(this.label62);
            this.Tutorial4.Controls.Add(this.button6);
            this.Tutorial4.Controls.Add(this.label46);
            this.Tutorial4.Controls.Add(this.label45);
            this.Tutorial4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Tutorial4.Location = new System.Drawing.Point(2, 128);
            this.Tutorial4.Name = "Tutorial4";
            this.Tutorial4.Size = new System.Drawing.Size(485, 165);
            this.Tutorial4.TabIndex = 267;
            // 
            // label7
            // 
            this.label7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label7.Dock = System.Windows.Forms.DockStyle.Top;
            this.label7.Location = new System.Drawing.Point(0, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(485, 5);
            this.label7.TabIndex = 242;
            // 
            // label8
            // 
            this.label8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label8.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label8.Location = new System.Drawing.Point(0, 160);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(485, 5);
            this.label8.TabIndex = 241;
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.DarkGray;
            this.button7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(246, 126);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 240;
            this.button7.Text = "Next";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // label49
            // 
            this.label49.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label49.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(346, 49);
            this.label49.Name = "label49";
            this.label49.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label49.Size = new System.Drawing.Size(70, 50);
            this.label49.TabIndex = 238;
            this.label49.Text = "5";
            this.label49.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label50
            // 
            this.label50.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label50.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(277, 49);
            this.label50.Name = "label50";
            this.label50.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label50.Size = new System.Drawing.Size(70, 50);
            this.label50.TabIndex = 237;
            this.label50.Text = "4";
            this.label50.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label62
            // 
            this.label62.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label62.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label62.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label62.Location = new System.Drawing.Point(415, 49);
            this.label62.Name = "label62";
            this.label62.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label62.Size = new System.Drawing.Size(70, 50);
            this.label62.TabIndex = 239;
            this.label62.Text = "6";
            this.label62.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.DarkGray;
            this.button6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(165, 126);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 15;
            this.button6.Text = "Back";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(4, 6);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(137, 29);
            this.label46.TabIndex = 13;
            this.label46.Text = "Date Buttons";
            // 
            // label45
            // 
            this.label45.AllowDrop = true;
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(5, 41);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(257, 76);
            this.label45.TabIndex = 14;
            this.label45.Text = "Clicking the dates like this one will \r\ntake you to the Events page where\r\nyou ca" +
    "n see the events you set or\r\ncreate you ones for that date";
            // 
            // BorderLeft
            // 
            this.BorderLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.BorderLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.BorderLeft.Location = new System.Drawing.Point(0, 32);
            this.BorderLeft.Name = "BorderLeft";
            this.BorderLeft.Size = new System.Drawing.Size(3, 391);
            this.BorderLeft.TabIndex = 273;
            this.BorderLeft.Text = "label4";
            // 
            // BorderRight
            // 
            this.BorderRight.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.BorderRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.BorderRight.Location = new System.Drawing.Point(485, 32);
            this.BorderRight.Name = "BorderRight";
            this.BorderRight.Size = new System.Drawing.Size(3, 391);
            this.BorderRight.TabIndex = 274;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Gray;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.Dashbord);
            this.panel2.Location = new System.Drawing.Point(2, 32);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(484, 40);
            this.panel2.TabIndex = 277;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(413, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 34);
            this.label2.TabIndex = 10;
            this.label2.Text = "2018";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Dashbord
            // 
            this.Dashbord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Dashbord.BackgroundImage")));
            this.Dashbord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Dashbord.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Dashbord.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Dashbord.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.Dashbord.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Dashbord.Location = new System.Drawing.Point(8, 5);
            this.Dashbord.Name = "Dashbord";
            this.Dashbord.Size = new System.Drawing.Size(29, 29);
            this.Dashbord.TabIndex = 134;
            this.Dashbord.UseVisualStyleBackColor = true;
            // 
            // Minimize
            // 
            this.Minimize.BackColor = System.Drawing.Color.Black;
            this.Minimize.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Minimize.BackgroundImage")));
            this.Minimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Minimize.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Minimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Minimize.ForeColor = System.Drawing.Color.Transparent;
            this.Minimize.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Minimize.Location = new System.Drawing.Point(435, 5);
            this.Minimize.Margin = new System.Windows.Forms.Padding(0);
            this.Minimize.Name = "Minimize";
            this.Minimize.Size = new System.Drawing.Size(20, 20);
            this.Minimize.TabIndex = 276;
            this.Minimize.TabStop = false;
            this.Minimize.UseVisualStyleBackColor = false;
            this.Minimize.Click += new System.EventHandler(this.Minimize_Click);
            // 
            // Close
            // 
            this.Close.BackColor = System.Drawing.Color.Black;
            this.Close.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Close.BackgroundImage")));
            this.Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Close.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Close.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Close.ForeColor = System.Drawing.Color.Transparent;
            this.Close.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.Close.Location = new System.Drawing.Point(459, 5);
            this.Close.Margin = new System.Windows.Forms.Padding(0);
            this.Close.Name = "Close";
            this.Close.Size = new System.Drawing.Size(20, 20);
            this.Close.TabIndex = 275;
            this.Close.TabStop = false;
            this.Close.UseVisualStyleBackColor = false;
            this.Close.Click += new System.EventHandler(this.Close_Click);
            // 
            // topborder
            // 
            this.topborder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.topborder.Dock = System.Windows.Forms.DockStyle.Top;
            this.topborder.ForeColor = System.Drawing.Color.Transparent;
            this.topborder.Location = new System.Drawing.Point(0, 0);
            this.topborder.Name = "topborder";
            this.topborder.Size = new System.Drawing.Size(488, 32);
            this.topborder.TabIndex = 271;
            // 
            // bottomborder
            // 
            this.bottomborder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.bottomborder.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.bottomborder.Location = new System.Drawing.Point(0, 423);
            this.bottomborder.Name = "bottomborder";
            this.bottomborder.Size = new System.Drawing.Size(488, 10);
            this.bottomborder.TabIndex = 272;
            // 
            // January
            // 
            this.January.Controls.Add(this.jan);
            this.January.Controls.Add(this.button55);
            this.January.Controls.Add(this.RightButton);
            this.January.Controls.Add(this.heading2);
            this.January.Controls.Add(this.datepanel);
            this.January.Location = new System.Drawing.Point(2, 70);
            this.January.Name = "January";
            this.January.Size = new System.Drawing.Size(486, 353);
            this.January.TabIndex = 278;
            // 
            // jan
            // 
            this.jan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.jan.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.jan.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.jan.Font = new System.Drawing.Font("Impact", 20.25F);
            this.jan.Location = new System.Drawing.Point(139, 0);
            this.jan.Name = "jan";
            this.jan.Size = new System.Drawing.Size(208, 39);
            this.jan.TabIndex = 280;
            this.jan.Text = "January";
            this.jan.UseVisualStyleBackColor = false;
            // 
            // button55
            // 
            this.button55.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button55.BackgroundImage")));
            this.button55.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button55.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button55.FlatAppearance.BorderSize = 0;
            this.button55.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(5, 4);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(30, 30);
            this.button55.TabIndex = 279;
            this.button55.UseVisualStyleBackColor = true;
            // 
            // RightButton
            // 
            this.RightButton.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("RightButton.BackgroundImage")));
            this.RightButton.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.RightButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.RightButton.FlatAppearance.BorderSize = 0;
            this.RightButton.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.RightButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.RightButton.Location = new System.Drawing.Point(452, 4);
            this.RightButton.Name = "RightButton";
            this.RightButton.Size = new System.Drawing.Size(30, 30);
            this.RightButton.TabIndex = 133;
            this.RightButton.UseVisualStyleBackColor = true;
            // 
            // heading2
            // 
            this.heading2.BackColor = System.Drawing.Color.WhiteSmoke;
            this.heading2.Location = new System.Drawing.Point(1, 1);
            this.heading2.Name = "heading2";
            this.heading2.Size = new System.Drawing.Size(484, 58);
            this.heading2.TabIndex = 137;
            // 
            // datepanel
            // 
            this.datepanel.Controls.Add(this.label5);
            this.datepanel.Controls.Add(this.label61);
            this.datepanel.Controls.Add(this.label36);
            this.datepanel.Controls.Add(this.label60);
            this.datepanel.Controls.Add(this.label34);
            this.datepanel.Controls.Add(this.label59);
            this.datepanel.Controls.Add(this.label27);
            this.datepanel.Controls.Add(this.label58);
            this.datepanel.Controls.Add(this.label20);
            this.datepanel.Controls.Add(this.label55);
            this.datepanel.Controls.Add(this.label12);
            this.datepanel.Controls.Add(this.label56);
            this.datepanel.Controls.Add(this.label10);
            this.datepanel.Controls.Add(this.label57);
            this.datepanel.Controls.Add(this.label11);
            this.datepanel.Controls.Add(this.label52);
            this.datepanel.Controls.Add(this.label13);
            this.datepanel.Controls.Add(this.label15);
            this.datepanel.Controls.Add(this.label54);
            this.datepanel.Controls.Add(this.label16);
            this.datepanel.Controls.Add(this.label17);
            this.datepanel.Controls.Add(this.label18);
            this.datepanel.Controls.Add(this.label35);
            this.datepanel.Controls.Add(this.label19);
            this.datepanel.Controls.Add(this.label14);
            this.datepanel.Controls.Add(this.label26);
            this.datepanel.Controls.Add(this.label37);
            this.datepanel.Controls.Add(this.label25);
            this.datepanel.Controls.Add(this.label38);
            this.datepanel.Controls.Add(this.label24);
            this.datepanel.Controls.Add(this.label39);
            this.datepanel.Controls.Add(this.label23);
            this.datepanel.Controls.Add(this.label40);
            this.datepanel.Controls.Add(this.label22);
            this.datepanel.Controls.Add(this.label28);
            this.datepanel.Controls.Add(this.label21);
            this.datepanel.Controls.Add(this.label29);
            this.datepanel.Controls.Add(this.label33);
            this.datepanel.Controls.Add(this.label30);
            this.datepanel.Controls.Add(this.label32);
            this.datepanel.Controls.Add(this.label31);
            this.datepanel.Controls.Add(this.label41);
            this.datepanel.Location = new System.Drawing.Point(1, 58);
            this.datepanel.Name = "datepanel";
            this.datepanel.Size = new System.Drawing.Size(484, 295);
            this.datepanel.TabIndex = 135;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label5.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(276, 196);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label5.Size = new System.Drawing.Size(70, 50);
            this.label5.TabIndex = 154;
            this.label5.Text = "25";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label61
            // 
            this.label61.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label61.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label61.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.ForeColor = System.Drawing.Color.Black;
            this.label61.Location = new System.Drawing.Point(207, 245);
            this.label61.Name = "label61";
            this.label61.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label61.Size = new System.Drawing.Size(70, 50);
            this.label61.TabIndex = 153;
            this.label61.Text = "31";
            this.label61.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.Gray;
            this.label36.Location = new System.Drawing.Point(69, 0);
            this.label36.Name = "label36";
            this.label36.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label36.Size = new System.Drawing.Size(70, 50);
            this.label36.TabIndex = 142;
            this.label36.Text = "25";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label60
            // 
            this.label60.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label60.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label60.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.ForeColor = System.Drawing.Color.Black;
            this.label60.Location = new System.Drawing.Point(0, 245);
            this.label60.Name = "label60";
            this.label60.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label60.Size = new System.Drawing.Size(70, 50);
            this.label60.TabIndex = 152;
            this.label60.Text = "28";
            this.label60.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(414, 147);
            this.label34.Name = "label34";
            this.label34.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label34.Size = new System.Drawing.Size(70, 50);
            this.label34.TabIndex = 136;
            this.label34.Text = "20";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label59
            // 
            this.label59.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label59.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label59.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.ForeColor = System.Drawing.Color.Black;
            this.label59.Location = new System.Drawing.Point(69, 245);
            this.label59.Name = "label59";
            this.label59.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label59.Size = new System.Drawing.Size(70, 50);
            this.label59.TabIndex = 151;
            this.label59.Text = "29";
            this.label59.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label27
            // 
            this.label27.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(414, 98);
            this.label27.Name = "label27";
            this.label27.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label27.Size = new System.Drawing.Size(70, 50);
            this.label27.TabIndex = 129;
            this.label27.Text = "13";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label58
            // 
            this.label58.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label58.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label58.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.ForeColor = System.Drawing.Color.Black;
            this.label58.Location = new System.Drawing.Point(138, 245);
            this.label58.Name = "label58";
            this.label58.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label58.Size = new System.Drawing.Size(70, 50);
            this.label58.TabIndex = 150;
            this.label58.Text = "30";
            this.label58.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label20.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(414, 49);
            this.label20.Name = "label20";
            this.label20.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label20.Size = new System.Drawing.Size(70, 50);
            this.label20.TabIndex = 122;
            this.label20.Text = "6";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label55
            // 
            this.label55.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label55.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.ForeColor = System.Drawing.Color.Gray;
            this.label55.Location = new System.Drawing.Point(345, 245);
            this.label55.Name = "label55";
            this.label55.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label55.Size = new System.Drawing.Size(70, 50);
            this.label55.TabIndex = 148;
            this.label55.Text = "2";
            this.label55.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.Gray;
            this.label12.Location = new System.Drawing.Point(414, 0);
            this.label12.Name = "label12";
            this.label12.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label12.Size = new System.Drawing.Size(70, 50);
            this.label12.TabIndex = 115;
            this.label12.Text = "30";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label56
            // 
            this.label56.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label56.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.ForeColor = System.Drawing.Color.Gray;
            this.label56.Location = new System.Drawing.Point(276, 245);
            this.label56.Name = "label56";
            this.label56.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label56.Size = new System.Drawing.Size(70, 50);
            this.label56.TabIndex = 147;
            this.label56.Text = "1";
            this.label56.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label10.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Gray;
            this.label10.Location = new System.Drawing.Point(276, 0);
            this.label10.Name = "label10";
            this.label10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label10.Size = new System.Drawing.Size(70, 50);
            this.label10.TabIndex = 113;
            this.label10.Text = "28";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label57
            // 
            this.label57.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label57.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label57.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.ForeColor = System.Drawing.Color.Gray;
            this.label57.Location = new System.Drawing.Point(414, 245);
            this.label57.Name = "label57";
            this.label57.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label57.Size = new System.Drawing.Size(70, 50);
            this.label57.TabIndex = 149;
            this.label57.Text = "3";
            this.label57.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label11.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gray;
            this.label11.Location = new System.Drawing.Point(345, 0);
            this.label11.Name = "label11";
            this.label11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label11.Size = new System.Drawing.Size(70, 50);
            this.label11.TabIndex = 114;
            this.label11.Text = "29";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label52
            // 
            this.label52.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label52.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label52.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.ForeColor = System.Drawing.Color.Black;
            this.label52.Location = new System.Drawing.Point(345, 196);
            this.label52.Name = "label52";
            this.label52.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label52.Size = new System.Drawing.Size(70, 50);
            this.label52.TabIndex = 145;
            this.label52.Text = "26";
            this.label52.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(69, 49);
            this.label13.Name = "label13";
            this.label13.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label13.Size = new System.Drawing.Size(70, 50);
            this.label13.TabIndex = 116;
            this.label13.Text = "1";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Gray;
            this.label15.Location = new System.Drawing.Point(0, 49);
            this.label15.Name = "label15";
            this.label15.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label15.Size = new System.Drawing.Size(70, 50);
            this.label15.TabIndex = 117;
            this.label15.Text = "31";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label54
            // 
            this.label54.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label54.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.ForeColor = System.Drawing.Color.Black;
            this.label54.Location = new System.Drawing.Point(414, 196);
            this.label54.Name = "label54";
            this.label54.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label54.Size = new System.Drawing.Size(70, 50);
            this.label54.TabIndex = 146;
            this.label54.Text = "27";
            this.label54.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label16.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(138, 49);
            this.label16.Name = "label16";
            this.label16.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label16.Size = new System.Drawing.Size(70, 50);
            this.label16.TabIndex = 118;
            this.label16.Text = "2";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label17
            // 
            this.label17.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(207, 49);
            this.label17.Name = "label17";
            this.label17.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label17.Size = new System.Drawing.Size(70, 50);
            this.label17.TabIndex = 119;
            this.label17.Text = "3";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(276, 49);
            this.label18.Name = "label18";
            this.label18.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label18.Size = new System.Drawing.Size(70, 50);
            this.label18.TabIndex = 120;
            this.label18.Text = "4";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label35.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label35.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Gray;
            this.label35.Location = new System.Drawing.Point(138, 0);
            this.label35.Name = "label35";
            this.label35.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label35.Size = new System.Drawing.Size(70, 50);
            this.label35.TabIndex = 141;
            this.label35.Text = "26";
            this.label35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label19.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(345, 49);
            this.label19.Name = "label19";
            this.label19.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label19.Size = new System.Drawing.Size(70, 50);
            this.label19.TabIndex = 121;
            this.label19.Text = "5";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Gray;
            this.label14.Location = new System.Drawing.Point(207, 0);
            this.label14.Name = "label14";
            this.label14.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label14.Size = new System.Drawing.Size(70, 50);
            this.label14.TabIndex = 140;
            this.label14.Text = "27";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label26.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(69, 98);
            this.label26.Name = "label26";
            this.label26.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label26.Size = new System.Drawing.Size(70, 50);
            this.label26.TabIndex = 123;
            this.label26.Text = "8";
            this.label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(207, 196);
            this.label37.Name = "label37";
            this.label37.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label37.Size = new System.Drawing.Size(70, 50);
            this.label37.TabIndex = 112;
            this.label37.Text = "24";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(0, 98);
            this.label25.Name = "label25";
            this.label25.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label25.Size = new System.Drawing.Size(70, 50);
            this.label25.TabIndex = 124;
            this.label25.Text = "7";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label38.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label38.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(138, 196);
            this.label38.Name = "label38";
            this.label38.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label38.Size = new System.Drawing.Size(70, 50);
            this.label38.TabIndex = 139;
            this.label38.Text = "23";
            this.label38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label24
            // 
            this.label24.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(138, 98);
            this.label24.Name = "label24";
            this.label24.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label24.Size = new System.Drawing.Size(70, 50);
            this.label24.TabIndex = 125;
            this.label24.Text = "9";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label39
            // 
            this.label39.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(0, 196);
            this.label39.Name = "label39";
            this.label39.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label39.Size = new System.Drawing.Size(70, 50);
            this.label39.TabIndex = 138;
            this.label39.Text = "21";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label23.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(207, 98);
            this.label23.Name = "label23";
            this.label23.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label23.Size = new System.Drawing.Size(70, 50);
            this.label23.TabIndex = 126;
            this.label23.Text = "10";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label40
            // 
            this.label40.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(69, 196);
            this.label40.Name = "label40";
            this.label40.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label40.Size = new System.Drawing.Size(70, 50);
            this.label40.TabIndex = 137;
            this.label40.Text = "22";
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(276, 98);
            this.label22.Name = "label22";
            this.label22.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label22.Size = new System.Drawing.Size(70, 50);
            this.label22.TabIndex = 127;
            this.label22.Text = "11";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(345, 147);
            this.label28.Name = "label28";
            this.label28.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label28.Size = new System.Drawing.Size(70, 50);
            this.label28.TabIndex = 135;
            this.label28.Text = "19";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(345, 98);
            this.label21.Name = "label21";
            this.label21.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label21.Size = new System.Drawing.Size(70, 50);
            this.label21.TabIndex = 128;
            this.label21.Text = "12";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label29.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(276, 147);
            this.label29.Name = "label29";
            this.label29.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label29.Size = new System.Drawing.Size(70, 50);
            this.label29.TabIndex = 134;
            this.label29.Text = "18";
            this.label29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label33
            // 
            this.label33.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(69, 147);
            this.label33.Name = "label33";
            this.label33.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label33.Size = new System.Drawing.Size(70, 50);
            this.label33.TabIndex = 130;
            this.label33.Text = "15";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label30
            // 
            this.label30.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(207, 147);
            this.label30.Name = "label30";
            this.label30.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label30.Size = new System.Drawing.Size(70, 50);
            this.label30.TabIndex = 133;
            this.label30.Text = "17";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label32.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(0, 147);
            this.label32.Name = "label32";
            this.label32.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label32.Size = new System.Drawing.Size(70, 50);
            this.label32.TabIndex = 131;
            this.label32.Text = "14";
            this.label32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(138, 147);
            this.label31.Name = "label31";
            this.label31.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label31.Size = new System.Drawing.Size(70, 50);
            this.label31.TabIndex = 132;
            this.label31.Text = "16";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label41.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label41.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.Gray;
            this.label41.Location = new System.Drawing.Point(0, 0);
            this.label41.Name = "label41";
            this.label41.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label41.Size = new System.Drawing.Size(70, 50);
            this.label41.TabIndex = 143;
            this.label41.Text = "24";
            this.label41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Tutorial3
            // 
            this.Tutorial3.BackColor = System.Drawing.Color.Gray;
            this.Tutorial3.Controls.Add(this.label70);
            this.Tutorial3.Controls.Add(this.label66);
            this.Tutorial3.Controls.Add(this.label67);
            this.Tutorial3.Controls.Add(this.label68);
            this.Tutorial3.Controls.Add(this.label69);
            this.Tutorial3.Controls.Add(this.button4);
            this.Tutorial3.Controls.Add(this.button12);
            this.Tutorial3.Controls.Add(this.label64);
            this.Tutorial3.Controls.Add(this.label65);
            this.Tutorial3.Location = new System.Drawing.Point(1, 59);
            this.Tutorial3.Name = "Tutorial3";
            this.Tutorial3.Size = new System.Drawing.Size(302, 213);
            this.Tutorial3.TabIndex = 279;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(161)))), ((int)(((byte)(161)))), ((int)(((byte)(161)))));
            this.label70.Font = new System.Drawing.Font("Impact", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label70.Location = new System.Drawing.Point(193, 16);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(102, 34);
            this.label70.TabIndex = 251;
            this.label70.Text = "January";
            this.label70.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label66
            // 
            this.label66.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label66.Dock = System.Windows.Forms.DockStyle.Right;
            this.label66.Location = new System.Drawing.Point(299, 5);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(3, 203);
            this.label66.TabIndex = 250;
            // 
            // label67
            // 
            this.label67.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label67.Dock = System.Windows.Forms.DockStyle.Left;
            this.label67.Location = new System.Drawing.Point(0, 5);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(3, 203);
            this.label67.TabIndex = 249;
            // 
            // label68
            // 
            this.label68.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label68.Dock = System.Windows.Forms.DockStyle.Top;
            this.label68.Location = new System.Drawing.Point(0, 0);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(302, 5);
            this.label68.TabIndex = 248;
            // 
            // label69
            // 
            this.label69.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label69.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label69.Location = new System.Drawing.Point(0, 208);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(302, 5);
            this.label69.TabIndex = 247;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.DarkGray;
            this.button4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(165, 169);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 244;
            this.button4.Text = "Next";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.Color.DarkGray;
            this.button12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button12.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(78, 169);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(75, 23);
            this.button12.TabIndex = 243;
            this.button12.Text = "Back";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label64.Location = new System.Drawing.Point(14, 19);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(155, 29);
            this.label64.TabIndex = 241;
            this.label64.Text = "Month Buttons";
            // 
            // label65
            // 
            this.label65.AllowDrop = true;
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(11, 69);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(279, 76);
            this.label65.TabIndex = 242;
            this.label65.Text = "Clicking the month like this one will \r\ntake you to the Month Selection page \r\nwh" +
    "ere you can automatically go to the\r\nmonth you selected";
            // 
            // Monsec
            // 
            this.Monsec.BackColor = System.Drawing.Color.DarkGray;
            this.Monsec.Controls.Add(this.mon1);
            this.Monsec.Controls.Add(this.mon12);
            this.Monsec.Controls.Add(this.mon11);
            this.Monsec.Controls.Add(this.mon10);
            this.Monsec.Controls.Add(this.mon9);
            this.Monsec.Controls.Add(this.mon8);
            this.Monsec.Controls.Add(this.mon7);
            this.Monsec.Controls.Add(this.mon6);
            this.Monsec.Controls.Add(this.mon5);
            this.Monsec.Controls.Add(this.mon4);
            this.Monsec.Controls.Add(this.mon3);
            this.Monsec.Controls.Add(this.label71);
            this.Monsec.Controls.Add(this.label134);
            this.Monsec.Controls.Add(this.label87);
            this.Monsec.Controls.Add(this.label90);
            this.Monsec.Controls.Add(this.mon2);
            this.Monsec.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Monsec.Location = new System.Drawing.Point(43, 112);
            this.Monsec.Name = "Monsec";
            this.Monsec.Size = new System.Drawing.Size(403, 308);
            this.Monsec.TabIndex = 281;
            // 
            // mon1
            // 
            this.mon1.BackColor = System.Drawing.Color.Gainsboro;
            this.mon1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon1.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon1.Location = new System.Drawing.Point(3, 5);
            this.mon1.Name = "mon1";
            this.mon1.Size = new System.Drawing.Size(100, 100);
            this.mon1.TabIndex = 267;
            this.mon1.TabStop = false;
            this.mon1.Text = "January";
            this.mon1.UseVisualStyleBackColor = false;
            // 
            // mon12
            // 
            this.mon12.BackColor = System.Drawing.Color.Gainsboro;
            this.mon12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon12.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon12.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon12.Location = new System.Drawing.Point(300, 203);
            this.mon12.Name = "mon12";
            this.mon12.Size = new System.Drawing.Size(100, 100);
            this.mon12.TabIndex = 266;
            this.mon12.TabStop = false;
            this.mon12.Text = "December";
            this.mon12.UseVisualStyleBackColor = false;
            // 
            // mon11
            // 
            this.mon11.BackColor = System.Drawing.Color.Gainsboro;
            this.mon11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon11.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon11.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon11.Location = new System.Drawing.Point(201, 203);
            this.mon11.Name = "mon11";
            this.mon11.Size = new System.Drawing.Size(100, 100);
            this.mon11.TabIndex = 265;
            this.mon11.TabStop = false;
            this.mon11.Text = "November";
            this.mon11.UseVisualStyleBackColor = false;
            // 
            // mon10
            // 
            this.mon10.BackColor = System.Drawing.Color.Gainsboro;
            this.mon10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon10.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon10.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon10.Location = new System.Drawing.Point(102, 203);
            this.mon10.Name = "mon10";
            this.mon10.Size = new System.Drawing.Size(100, 100);
            this.mon10.TabIndex = 264;
            this.mon10.TabStop = false;
            this.mon10.Text = "October";
            this.mon10.UseVisualStyleBackColor = false;
            // 
            // mon9
            // 
            this.mon9.BackColor = System.Drawing.Color.Gainsboro;
            this.mon9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon9.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon9.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon9.Location = new System.Drawing.Point(3, 203);
            this.mon9.Name = "mon9";
            this.mon9.Size = new System.Drawing.Size(100, 100);
            this.mon9.TabIndex = 263;
            this.mon9.TabStop = false;
            this.mon9.Text = "September";
            this.mon9.UseVisualStyleBackColor = false;
            // 
            // mon8
            // 
            this.mon8.BackColor = System.Drawing.Color.Gainsboro;
            this.mon8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon8.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon8.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon8.Location = new System.Drawing.Point(300, 104);
            this.mon8.Name = "mon8";
            this.mon8.Size = new System.Drawing.Size(100, 100);
            this.mon8.TabIndex = 262;
            this.mon8.TabStop = false;
            this.mon8.Text = "August";
            this.mon8.UseVisualStyleBackColor = false;
            // 
            // mon7
            // 
            this.mon7.BackColor = System.Drawing.Color.Gainsboro;
            this.mon7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon7.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon7.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon7.Location = new System.Drawing.Point(201, 104);
            this.mon7.Name = "mon7";
            this.mon7.Size = new System.Drawing.Size(100, 100);
            this.mon7.TabIndex = 261;
            this.mon7.TabStop = false;
            this.mon7.Text = "July";
            this.mon7.UseVisualStyleBackColor = false;
            // 
            // mon6
            // 
            this.mon6.BackColor = System.Drawing.Color.Gainsboro;
            this.mon6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon6.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon6.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon6.Location = new System.Drawing.Point(102, 104);
            this.mon6.Name = "mon6";
            this.mon6.Size = new System.Drawing.Size(100, 100);
            this.mon6.TabIndex = 260;
            this.mon6.TabStop = false;
            this.mon6.Text = "June";
            this.mon6.UseVisualStyleBackColor = false;
            // 
            // mon5
            // 
            this.mon5.BackColor = System.Drawing.Color.Gainsboro;
            this.mon5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon5.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon5.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon5.Location = new System.Drawing.Point(3, 104);
            this.mon5.Name = "mon5";
            this.mon5.Size = new System.Drawing.Size(100, 100);
            this.mon5.TabIndex = 259;
            this.mon5.TabStop = false;
            this.mon5.Text = "May";
            this.mon5.UseVisualStyleBackColor = false;
            // 
            // mon4
            // 
            this.mon4.BackColor = System.Drawing.Color.Gainsboro;
            this.mon4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon4.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon4.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon4.Location = new System.Drawing.Point(300, 5);
            this.mon4.Name = "mon4";
            this.mon4.Size = new System.Drawing.Size(100, 100);
            this.mon4.TabIndex = 258;
            this.mon4.TabStop = false;
            this.mon4.Text = "April";
            this.mon4.UseVisualStyleBackColor = false;
            // 
            // mon3
            // 
            this.mon3.BackColor = System.Drawing.Color.Gainsboro;
            this.mon3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon3.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon3.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon3.Location = new System.Drawing.Point(201, 5);
            this.mon3.Name = "mon3";
            this.mon3.Size = new System.Drawing.Size(100, 100);
            this.mon3.TabIndex = 257;
            this.mon3.TabStop = false;
            this.mon3.Text = "March";
            this.mon3.UseVisualStyleBackColor = false;
            // 
            // label71
            // 
            this.label71.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label71.Dock = System.Windows.Forms.DockStyle.Right;
            this.label71.Location = new System.Drawing.Point(400, 5);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(3, 298);
            this.label71.TabIndex = 129;
            // 
            // label134
            // 
            this.label134.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label134.Dock = System.Windows.Forms.DockStyle.Top;
            this.label134.Location = new System.Drawing.Point(3, 0);
            this.label134.Name = "label134";
            this.label134.Size = new System.Drawing.Size(400, 5);
            this.label134.TabIndex = 130;
            // 
            // label87
            // 
            this.label87.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label87.Dock = System.Windows.Forms.DockStyle.Left;
            this.label87.Location = new System.Drawing.Point(0, 0);
            this.label87.Name = "label87";
            this.label87.Size = new System.Drawing.Size(3, 303);
            this.label87.TabIndex = 128;
            this.label87.Text = "label4";
            // 
            // label90
            // 
            this.label90.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label90.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label90.Location = new System.Drawing.Point(0, 303);
            this.label90.Name = "label90";
            this.label90.Size = new System.Drawing.Size(403, 5);
            this.label90.TabIndex = 127;
            // 
            // mon2
            // 
            this.mon2.BackColor = System.Drawing.Color.Gainsboro;
            this.mon2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.mon2.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.mon2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.mon2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.mon2.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mon2.Location = new System.Drawing.Point(102, 5);
            this.mon2.Name = "mon2";
            this.mon2.Size = new System.Drawing.Size(100, 100);
            this.mon2.TabIndex = 268;
            this.mon2.TabStop = false;
            this.mon2.Text = "February";
            this.mon2.UseVisualStyleBackColor = false;
            // 
            // Tutorial5
            // 
            this.Tutorial5.BackColor = System.Drawing.Color.Gray;
            this.Tutorial5.Controls.Add(this.button17);
            this.Tutorial5.Controls.Add(this.label79);
            this.Tutorial5.Controls.Add(this.label80);
            this.Tutorial5.Controls.Add(this.label72);
            this.Tutorial5.Controls.Add(this.label73);
            this.Tutorial5.Controls.Add(this.button13);
            this.Tutorial5.Controls.Add(this.label76);
            this.Tutorial5.Controls.Add(this.button14);
            this.Tutorial5.Controls.Add(this.label77);
            this.Tutorial5.Controls.Add(this.label78);
            this.Tutorial5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Tutorial5.Location = new System.Drawing.Point(43, 112);
            this.Tutorial5.Name = "Tutorial5";
            this.Tutorial5.Size = new System.Drawing.Size(403, 139);
            this.Tutorial5.TabIndex = 282;
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.Color.Gainsboro;
            this.button17.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button17.Enabled = false;
            this.button17.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("Impact", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(300, 5);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(100, 100);
            this.button17.TabIndex = 264;
            this.button17.TabStop = false;
            this.button17.Text = "April";
            this.button17.UseVisualStyleBackColor = false;
            // 
            // label79
            // 
            this.label79.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label79.Dock = System.Windows.Forms.DockStyle.Right;
            this.label79.Location = new System.Drawing.Point(400, 5);
            this.label79.Name = "label79";
            this.label79.Size = new System.Drawing.Size(3, 129);
            this.label79.TabIndex = 248;
            // 
            // label80
            // 
            this.label80.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label80.Dock = System.Windows.Forms.DockStyle.Left;
            this.label80.Location = new System.Drawing.Point(0, 5);
            this.label80.Name = "label80";
            this.label80.Size = new System.Drawing.Size(3, 129);
            this.label80.TabIndex = 247;
            // 
            // label72
            // 
            this.label72.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label72.Dock = System.Windows.Forms.DockStyle.Top;
            this.label72.Location = new System.Drawing.Point(0, 0);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(403, 5);
            this.label72.TabIndex = 242;
            // 
            // label73
            // 
            this.label73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label73.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label73.Location = new System.Drawing.Point(0, 134);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(403, 5);
            this.label73.TabIndex = 241;
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.Color.DarkGray;
            this.button13.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(199, 105);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(75, 23);
            this.button13.TabIndex = 240;
            this.button13.Text = "Next";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // label76
            // 
            this.label76.BackColor = System.Drawing.Color.WhiteSmoke;
            this.label76.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label76.Font = new System.Drawing.Font("Showcard Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label76.Location = new System.Drawing.Point(415, 49);
            this.label76.Name = "label76";
            this.label76.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.label76.Size = new System.Drawing.Size(70, 50);
            this.label76.TabIndex = 239;
            this.label76.Text = "6";
            this.label76.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.Color.DarkGray;
            this.button14.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(102, 105);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(75, 23);
            this.button14.TabIndex = 15;
            this.button14.Text = "Back";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // label77
            // 
            this.label77.AutoSize = true;
            this.label77.Font = new System.Drawing.Font("Impact", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label77.Location = new System.Drawing.Point(4, 6);
            this.label77.Name = "label77";
            this.label77.Size = new System.Drawing.Size(251, 29);
            this.label77.TabIndex = 13;
            this.label77.Text = "Month Selection Buttons";
            // 
            // label78
            // 
            this.label78.AllowDrop = true;
            this.label78.AutoSize = true;
            this.label78.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label78.Location = new System.Drawing.Point(5, 41);
            this.label78.Name = "label78";
            this.label78.Size = new System.Drawing.Size(269, 57);
            this.label78.TabIndex = 14;
            this.label78.Text = "Clicking on this months will \r\nautomatically take you to the month \r\nyou selected" +
    "";
            // 
            // TutorialEnd
            // 
            this.TutorialEnd.BackColor = System.Drawing.Color.Gray;
            this.TutorialEnd.Controls.Add(this.label74);
            this.TutorialEnd.Controls.Add(this.label75);
            this.TutorialEnd.Controls.Add(this.label81);
            this.TutorialEnd.Controls.Add(this.label82);
            this.TutorialEnd.Controls.Add(this.label83);
            this.TutorialEnd.Controls.Add(this.buttonEnd);
            this.TutorialEnd.Location = new System.Drawing.Point(71, 136);
            this.TutorialEnd.Name = "TutorialEnd";
            this.TutorialEnd.Size = new System.Drawing.Size(346, 161);
            this.TutorialEnd.TabIndex = 283;
            // 
            // label74
            // 
            this.label74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label74.Dock = System.Windows.Forms.DockStyle.Right;
            this.label74.Location = new System.Drawing.Point(343, 5);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(3, 151);
            this.label74.TabIndex = 246;
            // 
            // label75
            // 
            this.label75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label75.Dock = System.Windows.Forms.DockStyle.Left;
            this.label75.Location = new System.Drawing.Point(0, 5);
            this.label75.Name = "label75";
            this.label75.Size = new System.Drawing.Size(3, 151);
            this.label75.TabIndex = 245;
            // 
            // label81
            // 
            this.label81.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label81.Dock = System.Windows.Forms.DockStyle.Top;
            this.label81.Location = new System.Drawing.Point(0, 0);
            this.label81.Name = "label81";
            this.label81.Size = new System.Drawing.Size(346, 5);
            this.label81.TabIndex = 244;
            // 
            // label82
            // 
            this.label82.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.label82.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label82.Location = new System.Drawing.Point(0, 156);
            this.label82.Name = "label82";
            this.label82.Size = new System.Drawing.Size(346, 5);
            this.label82.TabIndex = 243;
            // 
            // label83
            // 
            this.label83.BackColor = System.Drawing.Color.Transparent;
            this.label83.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label83.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label83.Location = new System.Drawing.Point(40, 31);
            this.label83.Name = "label83";
            this.label83.Size = new System.Drawing.Size(266, 60);
            this.label83.TabIndex = 159;
            this.label83.Text = "That Concludes this Tutorial\r\nYou may now proceed to use the App";
            this.label83.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // buttonEnd
            // 
            this.buttonEnd.BackColor = System.Drawing.Color.DarkGray;
            this.buttonEnd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonEnd.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.buttonEnd.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Gray;
            this.buttonEnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonEnd.Location = new System.Drawing.Point(106, 108);
            this.buttonEnd.Name = "buttonEnd";
            this.buttonEnd.Size = new System.Drawing.Size(135, 25);
            this.buttonEnd.TabIndex = 160;
            this.buttonEnd.TabStop = false;
            this.buttonEnd.Text = "Ok";
            this.buttonEnd.UseVisualStyleBackColor = false;
            this.buttonEnd.Click += new System.EventHandler(this.buttonEnd_Click);
            // 
            // dashbord1
            // 
            this.dashbord1.BackColor = System.Drawing.Color.Silver;
            this.dashbord1.Location = new System.Drawing.Point(4, 32);
            this.dashbord1.Name = "dashbord1";
            this.dashbord1.Size = new System.Drawing.Size(207, 392);
            this.dashbord1.TabIndex = 280;
            // 
            // Tutorial
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Silver;
            this.ClientSize = new System.Drawing.Size(488, 433);
            this.Controls.Add(this.TutorialEnd);
            this.Controls.Add(this.dashbord1);
            this.Controls.Add(this.Tutorial5);
            this.Controls.Add(this.Monsec);
            this.Controls.Add(this.Tutorial4);
            this.Controls.Add(this.Tutorial3);
            this.Controls.Add(this.Tutorial2);
            this.Controls.Add(this.Tutorial1);
            this.Controls.Add(this.TutorialStart);
            this.Controls.Add(this.BorderLeft);
            this.Controls.Add(this.BorderRight);
            this.Controls.Add(this.Minimize);
            this.Controls.Add(this.Close);
            this.Controls.Add(this.topborder);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.January);
            this.Controls.Add(this.bottomborder);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Tutorial";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.Tutorial_Load);
            this.TutorialStart.ResumeLayout(false);
            this.Tutorial1.ResumeLayout(false);
            this.Tutorial1.PerformLayout();
            this.Tutorial2.ResumeLayout(false);
            this.Tutorial2.PerformLayout();
            this.Tutorial4.ResumeLayout(false);
            this.Tutorial4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.January.ResumeLayout(false);
            this.datepanel.ResumeLayout(false);
            this.Tutorial3.ResumeLayout(false);
            this.Tutorial3.PerformLayout();
            this.Monsec.ResumeLayout(false);
            this.Tutorial5.ResumeLayout(false);
            this.Tutorial5.PerformLayout();
            this.TutorialEnd.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Panel TutorialStart;
        private System.Windows.Forms.Panel Tutorial1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel Tutorial4;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label BorderLeft;
        private System.Windows.Forms.Label BorderRight;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Dashbord;
        private System.Windows.Forms.Button Minimize;
        private System.Windows.Forms.Button Close;
        private System.Windows.Forms.Label topborder;
        private System.Windows.Forms.Label bottomborder;
        private System.Windows.Forms.Panel January;
        private System.Windows.Forms.Panel datepanel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Button RightButton;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Panel Tutorial3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Panel Tutorial2;
        private Dashbord dashbord1;
        private System.Windows.Forms.Panel Monsec;
        private System.Windows.Forms.Button mon1;
        private System.Windows.Forms.Button mon12;
        private System.Windows.Forms.Button mon11;
        private System.Windows.Forms.Button mon10;
        private System.Windows.Forms.Button mon9;
        private System.Windows.Forms.Button mon8;
        private System.Windows.Forms.Button mon7;
        private System.Windows.Forms.Button mon6;
        private System.Windows.Forms.Button mon5;
        private System.Windows.Forms.Button mon4;
        private System.Windows.Forms.Button mon3;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Button mon2;
        private System.Windows.Forms.Panel Tutorial5;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Panel TutorialEnd;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Button buttonEnd;
        private Heading heading2;
        private System.Windows.Forms.Button jan;
    }
}