﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Calendar_App
{
    public partial class LoginPage : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public LoginPage()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\zay\Desktop\MEMA-PLANNER\Calendar App\memaPlanner.accdb;
Persist Security Info=False;";
        }

        private void LoginPage_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            RegisterPage openForm = new RegisterPage();
            openForm.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            StartPage openForm = new StartPage();
            openForm.Show();
            Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                command.CommandText = "select * from mainTable where userName = '" + textBox1.Text + "' and passWord = '" + textBox2.Text + "' ";

                OleDbDataReader reader = command.ExecuteReader();
                int count = 0;
                while (reader.Read())
                {
                    count = count + 1;
                }
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    Tutorial openForm = new Tutorial();
                    openForm.Show();
                    Hide();
                }
                else if (count > 1)
                {
                    MessageBox.Show("User Duplicated!");
                }
                else
                {
                    MessageBox.Show("Incorrect Username or Password!");
                }

                connection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Incorrect Username or Password!");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
