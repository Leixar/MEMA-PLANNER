﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Calendar_App
{
    public partial class StartPage : Form
    {
        private OleDbConnection connection = new OleDbConnection();
        public StartPage()
        {
            InitializeComponent();
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\zay\Desktop\MEMA-PLANNER\Calendar App\memaPlanner.accdb;
Persist Security Info=False;";

            try
            {
                connection.Open();
                dbconnect.Text = "Database Connected";
                connection.Close();
            }
            catch (Exception ex)
            {
                dbconnect.Text = "Connection Unavailable";
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            RegisterPage openForm = new RegisterPage();
            openForm.Show();
            Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void boarder1_Load(object sender, EventArgs e)
        {

        }
    }
}
