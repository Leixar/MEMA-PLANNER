﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Calendar_App
{
    public partial class Calendar2018 : Form
    {
        OleDbConnection connection = new OleDbConnection();
        public Calendar2018()
        {
            connection.ConnectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\zay\Desktop\MEMA-PLANNER\Calendar App\memaPlanner.accdb;
Persist Security Info=False;";
            InitializeComponent();
        }

        private void Calendar2018_Load(object sender, EventArgs e)
        {
            EventPanel.Visible = false;
        }

        Point lastPoint;

        private void topborder_MouseDown(object sender, MouseEventArgs e)
        {
            lastPoint = new Point(e.X, e.Y);
        }

        private void topborder_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                this.Left += e.X - lastPoint.X;
                this.Top += e.Y - lastPoint.Y;
            }
        }

        private void Minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Close_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Dashbord_Click(object sender, EventArgs e)
        {
            dashbordgrow.Enabled = true;
            January.Enabled = false;
            February.Enabled = false;
            March.Enabled = false;
            April.Enabled = false;
            May.Enabled = false;
            June.Enabled = false;
            July.Enabled = false;
            August.Enabled = false;
            September.Enabled = false;
            October.Enabled = false;
            November.Enabled = false;
            December.Enabled = false;
            heading1.Enabled = false;
            heading2.Enabled = false;
            heading3.Enabled = false;
            heading4.Enabled = false;
            heading5.Enabled = false;
            heading6.Enabled = false;
            heading7.Enabled = false;
            heading8.Enabled = false;
            heading9.Enabled = false;
            heading10.Enabled = false;
            heading11.Enabled = false;
            heading12.Enabled = false;
        }

        private void Calendar2018_Click(object sender, EventArgs e)
        {
            if (dashbord1.Width >= 207)
            {
                dashbordshrink.Enabled = true;
                January.Enabled = true;
                February.Enabled = true;
                March.Enabled = true;
                April.Enabled = true;
                May.Enabled = true;
                June.Enabled = true;
                July.Enabled = true;
                August.Enabled = true;
                September.Enabled = true;
                October.Enabled = true;
                November.Enabled = true;
                December.Enabled = true;
                heading1.Enabled = true;
                heading2.Enabled = true;
                heading3.Enabled = true;
                heading4.Enabled = true;
                heading5.Enabled = true;
                heading6.Enabled = true;
                heading7.Enabled = true;
                heading8.Enabled = true;
                heading9.Enabled = true;
                heading10.Enabled = true;
                heading11.Enabled = true;
                heading12.Enabled = true;
            }
            else
            {
                this.Enabled = true;
            }
        }

        private void RightButton_Click(object sender, EventArgs e)
        {
            JanuaryShrink.Enabled = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            JanuaryGrow.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            FebruaryShrink.Enabled = true;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            FebruaryGrow.Enabled = true;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            MarchShrink.Enabled = true;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            MarchGrow.Enabled = true;
        }

        private void button12_Click(object sender, EventArgs e)
        {
            AprilShrink.Enabled = true;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            AprilGrow.Enabled = true;
        }

        private void button17_Click(object sender, EventArgs e)
        {
            MayShrink.Enabled = true;
        }

        private void button25_Click(object sender, EventArgs e)
        {
            MayGrow.Enabled = true;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            JuneShrink.Enabled = true;
        }

        private void button30_Click(object sender, EventArgs e)
        {
            JuneGrow.Enabled = true;
        }

        private void button27_Click(object sender, EventArgs e)
        {
            JulyShrink.Enabled = true;
        }

        private void button35_Click(object sender, EventArgs e)
        {
            JulyGrow.Enabled = true;
        }

        private void button32_Click(object sender, EventArgs e)
        {
            AugustShrink.Enabled = true;
        }

        private void button40_Click(object sender, EventArgs e)
        {
            AugustGrow.Enabled = true;
        }

        private void button37_Click(object sender, EventArgs e)
        {
            SeptemberShrink.Enabled = true;
        }

        private void button45_Click(object sender, EventArgs e)
        {
            SeptemberGrow.Enabled = true;
        }

        private void button42_Click(object sender, EventArgs e)
        {
            OctoberShrink.Enabled = true;
        }

        private void button50_Click(object sender, EventArgs e)
        {
            OctoberGrow.Enabled = true;
        }

        private void button47_Click(object sender, EventArgs e)
        {
            NovemberShrink.Enabled = true;
        }

        private void button55_Click(object sender, EventArgs e)
        {
            NovemberGrow.Enabled = true;
        }

        private void mon1_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 486;
            February.Width = 486;
            March.Width = 486;
            April.Width = 486;
            May.Width = 486;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon2_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 486;
            March.Width = 486;
            April.Width = 486;
            May.Width = 486;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon3_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 486;
            April.Width = 486;
            May.Width = 486;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon4_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 486;
            May.Width = 486;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon5_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 486;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon6_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 486;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon7_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 486;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon8_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 0;
            August.Width = 486;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon9_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 0;
            August.Width = 0;
            September.Width = 486;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon10_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 0;
            August.Width = 0;
            September.Width = 0;
            October.Width = 486;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon11_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 0;
            August.Width = 0;
            September.Width = 0;
            October.Width = 0;
            November.Width = 486;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void mon12_Click(object sender, EventArgs e)
        {
            Monsecshrink.Enabled = true;
            January.Width = 0;
            February.Width = 0;
            March.Width = 0;
            April.Width = 0;
            May.Width = 0;
            June.Width = 0;
            July.Width = 0;
            August.Width = 0;
            September.Width = 0;
            October.Width = 0;
            November.Width = 0;
            December.Width = 486;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;
            Dashbord.Enabled = true;
        }

        private void ShowMonSec_Click(object sender, EventArgs e)
        {
            Monsecgrow.Enabled = true;
            Dashbord.Enabled = false;
            January.Enabled = false;
            February.Enabled = false;
            March.Enabled = false;
            April.Enabled = false;
            May.Enabled = false;
            June.Enabled = false;
            July.Enabled = false;
            August.Enabled = false;
            September.Enabled = false;
            October.Enabled = false;
            November.Enabled = false;
            December.Enabled = false;
            heading1.Enabled = false;
            heading2.Enabled = false;
            heading3.Enabled = false;
            heading4.Enabled = false;
            heading5.Enabled = false;
            heading6.Enabled = false;
            heading7.Enabled = false;
            heading8.Enabled = false;
            heading9.Enabled = false;
            heading10.Enabled = false;
            heading11.Enabled = false;
            heading12.Enabled = false;
        }

        private void EventPage_Click(object sender, EventArgs e)
        {
            //
            //save query
            string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=test;";
            string query;
            
            var btn = (Button)sender;
            switch (btn.Name)
            {
                //january
                case "button1"://jan1
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 1";
                    break;

                case "button3"://jan2
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 2";
                    break;

                case "button4"://jan3
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 3";
                    break;

                case "button13"://jan4
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 4";
                    break;

                case "button11"://jan5
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 5";
                    break;

                case "button6"://jan6
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 6";
                    break;

                case "button24"://jan7
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 7";
                    break;

                case "button23"://jan8
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 8";
                    break;

                case "button21"://jan9
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 9";
                    break;

                case "button19"://jan10
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 10";
                    break;

                case "button18"://jan11
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 11";
                    break;

                case "button16"://jan12
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 12";
                    break;

                case "button14"://jan13
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 13";
                    break;

                case "button26"://jan14
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 14";
                    break;

                case "button36"://jan15
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 15";
                    break;

                case "button34"://jan16
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 16";
                    break;

                case "button33"://jan17
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 17";
                    break;

                case "button31"://jan18
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 18";
                    break;

                case "button29"://jan19
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 19";
                    break;

                case "button28"://jan20
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 20";
                    break;

                case "button38"://jan21
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 21";
                    break;

                case "button48"://jan22
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 22";
                    break;

                case "button46"://jan23
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 23";
                    break;

                case "button44"://jan24
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 24";
                    break;

                case "button43"://jan25
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 25";
                    break;

                case "button41"://jan26
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 26";
                    break;

                case "button39"://jan27
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 27";
                    break;

                case "button49"://jan28
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 28";
                    break;

                case "button53"://jan29
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 29";
                    break;

                case "button52"://jan30
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 30";
                    break;

                case "button51"://jan31
                    EventPanel.Visible = true;
                    query = "update jan2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 31";
                    break;

                //february
                case "button59"://feb1
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 1";
                    break;

                case "button58"://feb2
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 2";
                    break;

                case "button57"://feb3
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 3";
                    break;

                case "button61"://feb4
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 4";
                    break;

                case "button60"://feb5
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 5";
                    break;

                case "button56"://feb6
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 6";
                    break;

                case "button62"://feb7
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 7";
                    break;

                case "button65"://feb8
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 8";
                    break;

                case "button64"://feb9
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 9";
                    break;

                case "button63"://feb10
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 10";
                    break;

                case "button72"://feb11
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 11";
                    break;

                case "button71"://feb12
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 12";
                    break;

                case "button70"://feb13
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 13";
                    break;

                case "button66"://feb14
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 14";
                    break;

                case "button69"://feb15
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 15";
                    break;

                case "button68"://feb16
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 16";
                    break;

                case "button67"://feb17
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 17";
                    break;

                case "button75"://feb18
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 18";
                    break;

                case "button74"://feb19
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 19";
                    break;

                case "button73"://feb20
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 20";
                    break;

                case "button76"://feb21
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 21";
                    break;

                case "button79"://feb22
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 22";
                    break;

                case "button78"://feb23
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 23";
                    break;

                case "button77"://feb24
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 24";
                    break;

                case "button82"://feb25
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 25";
                    break;

                case "button81"://feb26
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 26";
                    break;

                case "button80"://feb27
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 27";
                    break;

                case "button83"://feb28
                    EventPanel.Visible = true;
                    query = "update feb2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 28";
                    break;

                //march
                case "button85"://mar1
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 1";
                    break;

                case "button84"://mar2
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 2";
                    break;

                case "button54"://mar3
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 3";
                    break;

                case "button99"://mar4
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 4";
                    break;

                case "button96"://mar5
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 5";
                    break;

                case "button94"://mar6
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 6";
                    break;

                case "button93"://mar7
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 7";
                    break;

                case "button98"://mar8
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 8";
                    break;

                case "button97"://mar9
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 9";
                    break;

                case "button95"://mar10
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 10";
                    break;

                case "button92"://mar11
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 11";
                    break;

                case "button91"://mar12
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 12";
                    break;

                case "button90"://mar13
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 13";
                    break;

                case "button86"://mar14
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 14";
                    break;

                case "button89"://mar15
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 15";
                    break;

                case "button88"://mar16
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 16";
                    break;

                case "button87"://mar17
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 17";
                    break;

                case "button102"://mar18
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 18";
                    break;

                case "button101"://mar19
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 19";
                    break;

                case "button100"://mar20
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 20";
                    break;

                case "button103"://mar21
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 21";
                    break;

                case "button106"://mar22
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 22";
                    break;

                case "button105"://mar23
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 23";
                    break;

                case "button104"://mar24
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 24";
                    break;

                case "button109"://mar25
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 25";
                    break;

                case "button108"://mar26
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 26";
                    break;

                case "button107"://mar27
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 27";
                    break;

                case "button110"://mar28
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 28";
                    break;

                case "button113"://mar29
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 29";
                    break;

                case "button112"://mar30
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 30";
                    break;

                case "button111"://mar31
                    EventPanel.Visible = true;
                    query = "update mar2018 set noteOne = '" + textBox1.Text + "', noteTwo = '" + textBox2.Text + "', noteThree = '" + textBox3.Text + "', noteFour = '" + textBox4.Text + "', noteFive = '" + textBox5.Text + "' where ID = 31";
                    break;

                //april
                case "button146"://apr1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button145"://apr2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button144"://apr3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button150"://apr4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button149"://apr5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button148"://apr6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button147"://apr7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button153"://apr8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button152"://apr9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button151"://apr10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button157"://apr11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button156"://apr12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button155"://apr13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button154"://apr14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button160"://apr15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button159"://apr16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button158"://apr17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button163"://apr18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button162"://apr19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button161"://apr20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button164"://apr21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button170"://apr22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button169"://apr23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button168"://apr24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button167"://apr25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button166"://apr26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button165"://apr27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button171"://apr28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button173"://apr29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button172"://apr30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_april` SET `apr_note_one`='" + textBox1.Text + "', `apr_note_two`='" + textBox2.Text + "', `apr_note_three`='" + textBox3.Text + "', `apr_note_four`='" + textBox4.Text + "', `apr_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;

                //may
                case "button114"://may1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button9"://may2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button8"://may3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button116"://may4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button115"://may5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button118"://may6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button117"://may7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button121"://may8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button120"://may9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button119"://may10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button123"://may11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button122"://may12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button128"://may13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button124"://may14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button127"://may15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button126"://may16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button125"://may17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button130"://may18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button129"://may19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button131"://may20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button132"://may21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button137"://may22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button136"://may23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button135"://may24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button134"://may25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button133"://may26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button138"://may27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button139"://may28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button142"://may29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button141"://may30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;
                case "button140"://may31
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_may` SET `may_note_one`='" + textBox1.Text + "', `may_note_two`='" + textBox2.Text + "', `may_note_three`='" + textBox3.Text + "', `may_note_four`='" + textBox4.Text + "', `may_note_five`='" + textBox5.Text + "' WHERE ID = 31";
                    break;

                //june
                case "button175"://jun1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button174"://jun2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button176"://jun3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button182"://jun4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button179"://jun5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button178"://jun6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button177"://jun7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button181"://jun8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button180"://jun9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button183"://jun10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button189"://jun11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button188"://jun12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button187"://jun13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button184"://jun14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button186"://jun15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button185"://jun16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button190"://jun17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button193"://jun18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button192"://jun19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button191"://jun20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button194"://jun21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button197"://jun22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button196"://jun23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button199"://jun24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button198"://jun25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button195"://jun26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button200"://jun27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button203"://jun28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button202"://jun29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button201"://jun30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_june` SET `jun_note_one`='" + textBox1.Text + "', `jun_note_two`='" + textBox2.Text + "', `jun_note_three`='" + textBox3.Text + "', `jun_note_four`='" + textBox4.Text + "', `jun_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;

                //july
                case "button206"://jul1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button205"://jul2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button204"://jul3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button210"://jul4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button209"://jul5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button208"://jul6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button207"://jul7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button213"://jul8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button212"://jul9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button211"://jul10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button217"://jul11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button216"://jul12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button215"://jul13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button214"://jul14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button220"://jul15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button219"://jul16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button218"://jul17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button223"://jul18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button222"://jul19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button221"://jul20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button224"://jul21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button230"://jul22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button229"://jul23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button228"://jul24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button227"://jul25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button226"://jul26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button225"://jul27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button231"://jul28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button234"://jul29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button233"://jul30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;
                case "button232"://jul31
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_july` SET `jul_note_one`='" + textBox1.Text + "', `jul_note_two`='" + textBox2.Text + "', `jul_note_three`='" + textBox3.Text + "', `jul_note_four`='" + textBox4.Text + "', `jul_note_five`='" + textBox5.Text + "' WHERE ID = 31";
                    break;

                //august
                case "button237"://aug1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button236"://aug2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button235"://aug3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button238"://aug4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button242"://aug5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button240"://aug6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button239"://aug7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button244"://aug8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button243"://aug9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button241"://aug10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button245"://aug11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button251"://aug12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button250"://aug13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button246"://aug14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button249"://aug15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button248"://aug16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button247"://aug17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button252"://aug18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button254"://aug19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button253"://aug20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button255"://aug21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button259"://aug22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button258"://aug23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button257"://aug24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button256"://aug25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button261"://aug26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button260"://aug27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button262"://aug28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button265"://aug29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button264"://aug30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;
                case "button263"://aug31
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_august` SET `aug_note_one`='" + textBox1.Text + "', `aug_note_two`='" + textBox2.Text + "', `aug_note_three`='" + textBox3.Text + "', `aug_note_four`='" + textBox4.Text + "', `aug_note_five`='" + textBox5.Text + "' WHERE ID = 31";
                    break;

                //september
                case "button266"://sep1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button268"://sep2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button267"://sep3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button273"://sep4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button271"://sep5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button270"://sep6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button269"://sep7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button272"://sep8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button275"://sep9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button274"://sep10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button280"://sep11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button279"://sep12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button278"://sep13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button276"://sep14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button277"://sep15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button282"://sep16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button281"://sep17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button285"://sep18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button284"://sep19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button283"://sep20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button286"://sep21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button289"://sep22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button288"://sep23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button287"://sep24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button292"://sep25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button291"://sep26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button290"://sep27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button293"://sep28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button294"://sep29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button296"://sep30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_september` SET `sep_note_one`='" + textBox1.Text + "', `sep_note_two`='" + textBox2.Text + "', `sep_note_three`='" + textBox3.Text + "', `sep_note_four`='" + textBox4.Text + "', `sep_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;

                //october
                case "button298"://oct1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button297"://oct2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button295"://oct3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button301"://oct4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button300"://oct5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button299"://oct6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button302"://oct7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button305"://oct8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button304"://oct9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button303"://oct10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button308"://oct11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button307"://oct12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button306"://oct13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button309"://oct14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button312"://oct15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button311"://oct16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button310"://oct17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button315"://oct18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button314"://oct19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button313"://oct20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button316"://oct21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button322"://oct22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button321"://oct23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button320"://oct24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button319"://oct25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button318"://oct26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button317"://oct27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button323"://oct28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button326"://oct29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button325"://oct30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;
                case "button324"://oct31
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_october` SET `oct_note_one`='" + textBox1.Text + "', `oct_note_two`='" + textBox2.Text + "', `oct_note_three`='" + textBox3.Text + "', `oct_note_four`='" + textBox4.Text + "', `oct_note_five`='" + textBox5.Text + "' WHERE ID = 31";
                    break;

                //november
                case "button329"://nov1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button328"://nov2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button327"://nov3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button336"://nov4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button333"://nov5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button331"://nov6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button330"://nov7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button335"://nov8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button334"://nov9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button332"://nov10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button343"://nov11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button342"://nov12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button341"://nov13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button337"://nov14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button340"://nov15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button339"://nov16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button338"://nov17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button346"://nov18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button345"://nov19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button344"://nov20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button347"://nov21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button350"://nov22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button349"://nov23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button348"://nov24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button353"://nov25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button352"://nov26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button351"://nov27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button354"://nov28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button356"://nov29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button355"://nov30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_november` SET `nov_note_one`='" + textBox1.Text + "', `nov_note_two`='" + textBox2.Text + "', `nov_note_three`='" + textBox3.Text + "', `nov_note_four`='" + textBox4.Text + "', `nov_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;

                //december
                case "button357"://dec1
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 1";
                    break;
                case "button359"://dec2
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 2";
                    break;
                case "button358"://dec3
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 3";
                    break;
                case "button364"://dec4
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 4";
                    break;
                case "button362"://dec5
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 5";
                    break;
                case "button361"://dec6
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 6";
                    break;
                case "button360"://dec7
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 7";
                    break;
                case "button363"://dec8
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 8";
                    break;
                case "button387"://dec9
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 9";
                    break;
                case "button386"://dec10
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 10";
                    break;
                case "button371"://dec11
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 11";
                    break;
                case "button370"://dec12
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 12";
                    break;
                case "button369"://dec13
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 13";
                    break;
                case "button365"://dec14
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 14";
                    break;
                case "button368"://dec15
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 15";
                    break;
                case "button367"://dec16
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 16";
                    break;
                case "button366"://dec17
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 17";
                    break;
                case "button374"://dec18
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 18";
                    break;
                case "button373"://dec19
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 19";
                    break;
                case "button372"://dec20
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 20";
                    break;
                case "button375"://dec21
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 21";
                    break;
                case "button378"://dec22
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 22";
                    break;
                case "button377"://dec23
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 23";
                    break;
                case "button376"://dec24
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 24";
                    break;
                case "button381"://dec25
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 25";
                    break;
                case "button380"://dec26
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 26";
                    break;
                case "button379"://dec27
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 27";
                    break;
                case "button382"://dec28
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 28";
                    break;
                case "button385"://dec29
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 29";
                    break;
                case "button384"://dec30
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 30";
                    break;
                case "button383"://dec31
                    EventPanel.Visible = true;
                    query = "UPDATE `2018_december` SET `dec_note_one`='" + textBox1.Text + "', `dec_note_two`='" + textBox2.Text + "', `dec_note_three`='" + textBox3.Text + "', `dec_note_four`='" + textBox4.Text + "', `dec_note_five`='" + textBox5.Text + "' WHERE ID = 31";
                    break;
                default:
                    break;             
            }

            //EventPanel.Visible = true;
            Dashbord.Enabled = false;
            January.Enabled = false;
            February.Enabled = false;
            March.Enabled = false;
            April.Enabled = false;
            May.Enabled = false;
            June.Enabled = false;
            July.Enabled = false;
            August.Enabled = false;
            September.Enabled = false;
            October.Enabled = false;
            November.Enabled = false;
            December.Enabled = false;
            heading1.Enabled = false;
            heading2.Enabled = false;
            heading3.Enabled = false;
            heading4.Enabled = false;
            heading5.Enabled = false;
            heading6.Enabled = false;
            heading7.Enabled = false;
            heading8.Enabled = false;
            heading9.Enabled = false;
            heading10.Enabled = false;
            heading11.Enabled = false;
            heading12.Enabled = false;
        }

        private void buttonEnd_Click(object sender, EventArgs e)
        {
            EventPanel.Visible = false;
            Dashbord.Enabled = true;
            January.Enabled = true;
            February.Enabled = true;
            March.Enabled = true;
            April.Enabled = true;
            May.Enabled = true;
            June.Enabled = true;
            July.Enabled = true;
            August.Enabled = true;
            September.Enabled = true;
            October.Enabled = true;
            November.Enabled = true;
            December.Enabled = true;
            heading1.Enabled = true;
            heading2.Enabled = true;
            heading3.Enabled = true;
            heading4.Enabled = true;
            heading5.Enabled = true;
            heading6.Enabled = true;
            heading7.Enabled = true;
            heading8.Enabled = true;
            heading9.Enabled = true;
            heading10.Enabled = true;
            heading11.Enabled = true;
            heading12.Enabled = true;

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            Add.Visible = true;
            Save.Visible = false;
        }

        private void dashbordgrow_Tick(object sender, EventArgs e)
        {
            if (dashbord1.Width >= 207)
            {
                dashbordgrow.Enabled = false;
                this.Enabled = true;
            }
            else
            {
                dashbord1.Width += 23;
                this.Enabled = false;
            }
        }

        private void dashbordshrink_Tick(object sender, EventArgs e)
        {
            if (dashbord1.Width <= 0)
            {
                dashbordshrink.Enabled = false;
            }
            else
            {
                dashbord1.Width -= 23;
            }
        }

        private void Monsecgrow_Tick(object sender, EventArgs e)
        {
            if (Monsec.Height >= 308)
            {
                Monsecgrow.Enabled = false;
            }
            else
            {
                Monsec.Height += 28;
            }
        }

        private void Monsecshrink_Tick(object sender, EventArgs e)
        {
            if (Monsec.Height <= 0)
            {
                Monsecshrink.Enabled = false;
            }
            else
            {
                Monsec.Height -= 28;
            }
        }

        private void JanuaryGrow_Tick(object sender, EventArgs e)
        {
            if (January.Width >= 486)
            {
                JanuaryGrow.Enabled = false;
            }
            else
            {
                January.Width += 27;
            }
        }

        private void JanuaryShrink_Tick(object sender, EventArgs e)
        {
            if (January.Width <= 0)
            {
                JanuaryShrink.Enabled = false;
            }
            else
            {
                January.Width -= 27;
            }
        }

        private void FebruaryGrow_Tick(object sender, EventArgs e)
        {
            if (February.Width >= 486)
            {
                FebruaryGrow.Enabled = false;
            }
            else
            {
                February.Width += 27;
            }
        }

        private void FebruaryShrink_Tick(object sender, EventArgs e)
        {
            if (February.Width <= 0)
            {
                FebruaryShrink.Enabled = false;
            }
            else
            {
                February.Width -= 27;
            }
        }

        private void MarchGrow_Tick(object sender, EventArgs e)
        {
            if (March.Width >= 486)
            {
                MarchGrow.Enabled = false;
            }
            else
            {
                March.Width += 27;
            }
        }

        private void MarchShrink_Tick(object sender, EventArgs e)
        {
            if (March.Width <= 0)
            {
                MarchShrink.Enabled = false;
            }
            else
            {
                March.Width -= 27;
            }
        }

        private void AprilGrow_Tick(object sender, EventArgs e)
        {
            if (April.Width >= 486)
            {
                AprilGrow.Enabled = false;
            }
            else
            {
                April.Width += 27;
            }
        }

        private void AprilShrink_Tick(object sender, EventArgs e)
        {
            if (April.Width <= 0)
            {
                AprilShrink.Enabled = false;
            }
            else
            {
                April.Width -= 27;
            }
        }

        private void MayGrow_Tick(object sender, EventArgs e)
        {
            if (May.Width >= 486)
            {
                MayGrow.Enabled = false;
            }
            else
            {
                May.Width += 27;
            }
        }

        private void MayShrink_Tick(object sender, EventArgs e)
        {
            if (May.Width <= 0)
            {
               MayShrink.Enabled = false;
            }
            else
            {
                May.Width -= 27;
            }
        }

        private void JuneGrow_Tick(object sender, EventArgs e)
        {
            if (June.Width >= 486)
            {
                JuneGrow.Enabled = false;
            }
            else
            {
                June.Width += 27;
            }
        }

        private void JuneShrink_Tick(object sender, EventArgs e)
        {
            if (June.Width <= 0)
            {
                JuneShrink.Enabled = false;
            }
            else
            {
                June.Width -= 27;
            }
        }

        private void JulyGrow_Tick(object sender, EventArgs e)
        {
            if (July.Width >= 486)
            {
                JulyGrow.Enabled = false;
            }
            else
            {
                July.Width += 27;
            }
        }

        private void JulyShrink_Tick(object sender, EventArgs e)
        {
            if (July.Width <= 0)
            {
                JulyShrink.Enabled = false;
            }
            else
            {
                July.Width -= 27;
            }
        }

        private void AugustGrow_Tick(object sender, EventArgs e)
        {
            if (August.Width >= 486)
            {
                AugustGrow.Enabled = false;
            }
            else
            {
                August.Width += 27;
            }
        }

        private void AugustShrink_Tick(object sender, EventArgs e)
        {
            if (August.Width <= 0)
            {
                AugustShrink.Enabled = false;
            }
            else
            {
                August.Width -= 27;
            }
        }

        private void SeptemberGrow_Tick(object sender, EventArgs e)
        {
            if (September.Width >= 486)
            {
                SeptemberGrow.Enabled = false;
            }
            else
            {
                September.Width += 27;
            }
        }

        private void SeptemberShrink_Tick(object sender, EventArgs e)
        {
            if (September.Width <= 0)
            {
                SeptemberShrink.Enabled = false;
            }
            else
            {
                September.Width -= 27;
            }
        }

        private void OctoberGrow_Tick(object sender, EventArgs e)
        {
            if (October.Width >= 486)
            {
                OctoberGrow.Enabled = false;
            }
            else
            {
                October.Width += 27;
            }
        }

        private void OctoberShrink_Tick(object sender, EventArgs e)
        {
            if (October.Width <= 0)
            {
                OctoberShrink.Enabled = false;
            }
            else
            {
                October.Width -= 27;
            }
        }

        private void NovemberGrow_Tick(object sender, EventArgs e)
        {
            if (November.Width >= 486)
            {
                NovemberGrow.Enabled = false;
            }
            else
            {
                November.Width += 27;
            }
        }

        private void NovemberShrink_Tick(object sender, EventArgs e)
        {
            if (November.Width <= 0)
            {
                NovemberShrink.Enabled = false;
            }
            else
            {
                November.Width -= 27;
            }
        }

        //
        private void Add_Click(object sender, EventArgs e)
        {
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            Add.Visible = false;
            Save.Visible = true;
        }
        
        private void Save_Click(object sender, EventArgs e)
        {
            //-----------------------------------------
            try
            {
                connection.Open();
                OleDbCommand command = new OleDbCommand();
                command.Connection = connection;
                string query = "";
                command.CommandText = query;
                MessageBox.Show("Saved!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Saving Failed!");
            }
            //-----------------------------------------

            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            Add.Visible = true;
            Save.Visible = false;            
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label17_Click(object sender, EventArgs e)
        {

        }
    }
}
